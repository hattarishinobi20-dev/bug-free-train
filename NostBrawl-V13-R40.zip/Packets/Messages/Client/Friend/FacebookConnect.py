from Logic.FriendService import FriendError, FriendService
from Packets.Messages.Server.Friend.Events.FacebookBindOKMessage import FacebookBindOKMessage
from Utils.Reader import BSMessageReader


class FacebookConnect(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.facebook_id = ""
        self.facebook_token = ""

    def decode(self):
        self.read_Vint()
        self.facebook_id = self.read_string()
        self.facebook_token = self.read_string()

    def process(self):
        try:
            progression = FriendService.set_facebook(
                self.player, self.facebook_id, self.facebook_token, True
            )
        except (FriendError, TypeError, ValueError) as error:
            return {"linked": False, "error": str(error)}
        FacebookBindOKMessage(self.client, self.player).send()
        return {"linked": True, "progression": progression}
