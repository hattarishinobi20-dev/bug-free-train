from Logic.FriendService import FriendError, FriendService
from Packets.Messages.Server.Friend.Events.FBAccountDisconnectedOKMessage import FBAccountDisconnectedOKMessage
from Utils.Reader import BSMessageReader


class UnlinkFacebookAcount(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.facebook_id = ""
        self.facebook_token = ""

    def decode(self):
        self.read_Vint()
        self.facebook_id = self.read_string()
        self.facebook_token = self.read_string()

    def process(self):
        try:
            progression = FriendService.set_facebook(self.player, linked=False)
        except (FriendError, TypeError, ValueError) as error:
            return {"linked": False, "error": str(error)}
        FBAccountDisconnectedOKMessage(self.client, self.player).send()
        return {"linked": False, "progression": progression}
