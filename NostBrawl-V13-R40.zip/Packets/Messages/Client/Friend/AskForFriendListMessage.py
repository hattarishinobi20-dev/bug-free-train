from Logic.FriendService import FriendService
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Utils.Reader import BSMessageReader


class AskForFriendListMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        FriendListMessage(self.client, self.player).send()
        return FriendService.friends(self.player)
