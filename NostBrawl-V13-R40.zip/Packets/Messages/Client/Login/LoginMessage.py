import json
import logging

from Database.DatabaseManager import DataBase
from Logic.NotificationFactory import NotificationFactory
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from Utils.Config import Config
from Utils.Helpers import Helpers
from Utils.Reader import BSMessageReader


LOGGER = logging.getLogger(__name__)


class LoginMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.banned = {"banned_low_id": []}

    def decode(self):
        self.player.high_id = self.read_int()
        self.player.low_id = self.read_int()
        self.player.token = self.read_string()

        self.major = self.read_int()
        self.minor = self.read_int()
        self.build = self.read_int()
        self.fingerprint_sha = self.read_string()

        self.read_int()
        self.player.device.OpenUDID = self.read_string()
        self.player.device.AndroidID = self.read_string()
        self.player.device.OSVersion = self.read_string()

        try:
            with open("JSON/banned.json", "r", encoding="utf-8") as banned_file:
                self.banned = json.load(banned_file)
        except (OSError, ValueError):
            LOGGER.warning("Could not read JSON/banned.json; assuming no bans")

    def _fail(self, error_code, message=""):
        self.player.err_code = error_code
        self.player.logged_in = False
        LoginFailedMessage(self.client, self.player, message).send()
        return False

    def _send_success(self):
        try:
            NotificationFactory.ensure_star_shelly(self.player)
            NotificationFactory.ensure_wizard_barley(self.player)
        except Exception:
            LOGGER.exception("Could not create the login skin notifications")
        self.player.online = 1
        DataBase.replaceValue(self, "online", 1)
        LoginOkMessage(self.client, self.player).send()
        OwnHomeDataMessage(self.client, self.player).send()
        club_low_id = getattr(self.player, "club_low_id", 0) or 0
        if club_low_id:
            MyAllianceMessage(self.client, self.player, club_low_id).send()
            AllianceStreamMessage(self.client, self.player, club_low_id, 0).send()
        self.player.logged_in = True
        return True

    def process(self):
        settings = Config.GetValue()

        if self.major != settings["ClientMajor"]:
            return self._fail(
                8,
                "Your client is outdated. This server requires Brawl Stars "
                f"{settings['ClientMajor']}.{settings['ClientMinor']}.{settings['ClientBuild']}.",
            )

        if self.player.low_id in self.banned.get("banned_low_id", []):
            return self._fail(11, "This account is banned from the server.")

        if self.player.maintenance:
            return self._fail(10)

        if self.player.patch and self.fingerprint_sha != self.player.patch_sha:
            return self._fail(7)

        requested_low_id = self.player.low_id

        try:
            if requested_low_id == 0:
                                                                            
                self.player.low_id = Helpers.randomID(self)
                self.player.high_id = 0
                self.player.token = Helpers.randomStringDigits(self)
                DataBase.createAccount(self)
            else:
                if not self.player.token:
                    return self._fail(9, "Invalid account credentials.")

                                                                              
                                                                          
                                                                           
                found = DataBase.loadAccount(self)
                if found is False or self.player.low_id != requested_low_id:
                    return self._fail(9, "Invalid account credentials.")
        except Exception:
            LOGGER.exception("Database failure while processing login")
            return self._fail(9, "Could not access the account database.")

        return self._send_success()
