from Logic.BillingService import BillingService
from Logic.RewardDelivery import RewardDelivery
from Logic.Rewards import RewardError
from Packets.Messages.Server.Billing.BillingRequestFailedMessage import BillingRequestFailedMessage
from Packets.Messages.Server.Billing.BuyBundleBillingPackResponseMessage import BuyBundleBillingPackResponseMessage
from Packets.Messages.Server.Billing.GoogleBillingProcessedByServerMessage import GoogleBillingProcessedByServerMessage
from Utils.Reader import BSMessageReader


class GoogleBillingRequestMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player
        self.values = []

    def decode(self):
        self.values = [self.read_string() for _ in range(6)]

    def process(self):
        try:
            result = BillingService.purchase(self.player, self.values)
        except (RewardError, TypeError, ValueError) as error:
            BillingRequestFailedMessage(self.client, self.player, str(error)).send()
            return {"accepted": False, "error": str(error)}
        package = result["package"]
        if result["isBundle"]:
            BuyBundleBillingPackResponseMessage(
                self.client, self.player,
                package["type"], package["starterPackNumber"],
            ).send()
        else:
            GoogleBillingProcessedByServerMessage(
                self.client, self.player,
                package["name"], result["transactionId"], 0,
            ).send()
        RewardDelivery.send_many(self.client, self.player, result["responses"])
        return {"accepted": True, "product": package["name"]}
