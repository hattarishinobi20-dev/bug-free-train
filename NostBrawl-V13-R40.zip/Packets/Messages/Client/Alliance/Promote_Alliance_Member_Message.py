from Logic.ClubService import ClubError, ClubService
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Alliance.Events.AllianceRoleChangedOKMessage import AllianceRoleChangedOKMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Utils.Reader import BSMessageReader


class Promote_Alliance_Member_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.TargetHighID = self.read_int()
        self.TargetLowID = self.read_int()
        self.TargetedRole = self.read_Vint()

    def process(self):
        try:
            club, _ = ClubService.promote(
                self.player, self.TargetLowID, self.TargetedRole
            )
        except ClubError as error:
            return str(error)
        response_type = 0 if self.TargetedRole > 1 else 1
        AllianceRoleChangedOKMessage(self.client, self.player, response_type).send()
        MyAllianceMessage(self.client, self.player, club["id"]).send()
        for member_id in club["member_ids"]:
            if member_id != self.player.low_id:
                AllianceDataMessage(
                    self.client, self.player, 0, club["id"], member_override=True
                ).sendWithLowID(member_id)
        return club
