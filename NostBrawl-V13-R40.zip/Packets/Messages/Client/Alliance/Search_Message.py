from Logic.ClubService import ClubService
from Packets.Messages.Server.Alliance.AllianceSearchResultMessage import AllianceSearchResultMessage
from Utils.Reader import BSMessageReader


class Search_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.RequestedName = self.read_string()

    def process(self):
        clubs = ClubService.list_clubs(1, 100, 2, 30, self.RequestedName)
        AllianceSearchResultMessage(
            self.client, self.player, self.RequestedName, len(clubs), clubs
        ).send()
        return clubs
