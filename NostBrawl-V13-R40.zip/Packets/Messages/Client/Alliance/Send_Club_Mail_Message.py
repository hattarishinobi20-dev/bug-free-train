from Logic.ClubService import ClubError, ClubService
from Packets.Messages.Server.Alliance.Events.Mail import AllianceMailWindow
from Packets.Messages.Server.NotifAdd import LogicAddNotificationCommand
from Utils.Reader import BSMessageReader


class SendClubMail(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_int()
        self.msg = self.read_string()

    def process(self):
        try:
            club, notification = ClubService.mail(self.player, self.msg)
        except ClubError as error:
            if not self.msg:
                AllianceMailWindow(self.client, self.player, 114).send()
            return str(error)
        AllianceMailWindow(self.client, self.player, 113).send()
        for member_id in club["member_ids"]:
            LogicAddNotificationCommand(
                self.client, self.player, self.msg, notification=notification
            ).sendWithLowID(member_id)
        return notification
