import time

from Logic.BattleEnd import BattleEndError, BattleEndService
from Packets.Messages.Server.Battle.BattleResultBigGameMessage import BattleResultBigGameMessage
from Packets.Messages.Server.Battle.BattleResultBossFightMessage import BattleResultBossFightMessage
from Packets.Messages.Server.Battle.BattleResultDuoShowdownMessage import BattleResultDuoShowdownMessage
from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage
from Packets.Messages.Server.Battle.BattleResultRoboRumbleMessage import BattleResultRoboRumbleMessage
from Packets.Messages.Server.Battle.BattleResultRoboWarsMessage import BattleResultRoboWarsMessage
from Packets.Messages.Server.Battle.BattleResultShowdownMessage import BattleResultShowdownMessage
from Utils.Reader import BSMessageReader


class AskForBattleEndMessage(BSMessageReader):
    RESULT_MESSAGES = {
        0: BattleResultMessage,
        1: BattleResultRoboWarsMessage,
        2: BattleResultShowdownMessage,
        3: BattleResultRoboRumbleMessage,
        4: BattleResultBigGameMessage,
        5: BattleResultDuoShowdownMessage,
        6: BattleResultBossFightMessage,
    }
    MIN_BATTLE_INTERVAL = 10

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.initial_bytes = initial_bytes
        self.battle = None

    def decode(self):
        self.battle = BattleEndService.decode(self, self.initial_bytes)

    def process(self):
        if self.battle is None:
            raise BattleEndError("BattleEnd não foi decodificado")
        current_time = time.monotonic()
        previous_hash = getattr(self.player, "last_battle_end_hash", None)
        previous_time = float(getattr(self.player, "last_battle_end_time", 0) or 0)
        if (
            previous_hash != self.battle.battle_id
            and current_time - previous_time < self.MIN_BATTLE_INTERVAL
        ):
            return "BattleEnd diferente recebido antes do intervalo mínimo"
        BattleEndService.apply_to_player(self.player, self.battle)
        message_class = self.RESULT_MESSAGES[self.battle.game_mode]
        message = message_class(self.client, self.player)
        message.send()
        self.player.last_battle_end_hash = self.battle.battle_id
        self.player.last_battle_end_time = current_time
        return {
            "gameMode": self.battle.game_mode,
            "mapID": self.battle.map_id,
            "participants": len(self.battle.participants),
            "battleID": self.battle.battle_id,
        }
