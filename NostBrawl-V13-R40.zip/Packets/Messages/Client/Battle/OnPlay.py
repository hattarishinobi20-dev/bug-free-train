from Packets.Messages.Server.Battle.MatchMakingCancelledMessage import (
    MatchMakingCancelledMessage,
)
from Utils.Reader import BSMessageReader


class OnPlay(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.CardID = self.read_Vint()
        self.read_Vint()
        self.MapIndex = self.read_Vint()

    def process(self):
        self.player.map_id = 15
        self.player.mmplayers = 1
        MatchMakingCancelledMessage(self.client, self.player).send()
