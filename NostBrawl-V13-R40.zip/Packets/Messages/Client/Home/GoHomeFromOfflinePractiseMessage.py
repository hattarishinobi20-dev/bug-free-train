from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader


class GoHomeFromOfflinePractiseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.unknown = self.read_boolean()
        self.ensure_end()

    def process(self):
        room = GameRoomService.return_to_room(self.player)
        if room is not None:
            TeamGameroomDataMessage(self.client, self.player, room).send()
            return room
        OwnHomeDataMessage(self.client, self.player).send()
        return None
