from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamKickOK import TeamKickOK
from Utils.Reader import BSMessageReader


class TeamKickMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.high_id = 0
        self.low_id = 0

    def decode(self):
        self.high_id = self.read_Vint()
        self.low_id = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.kick(self.player, self.low_id)
        TeamKickOK(None, self.player).sendWithLowID(self.low_id)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
