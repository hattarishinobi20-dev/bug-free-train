from Files.CsvLogic.Skins import Skins
from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomError, GameRoomService
from Utils.Reader import BSMessageReader


class TeamChangeMemberSettingsMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.unknown = 0
        self.skin_reference = (0, -1)

    def decode(self):
        self.unknown = self.read_Vint()
        self.skin_reference = self.readScId()
        self.ensure_end()

    def process(self):
        csv_id, skin_id = self.skin_reference
        if csv_id != 29:
            raise GameRoomError("DataReference de skin inválida")
        brawler_id = Skins.getBrawler(skin_id)
        room = GameRoomService.set_member_settings(
            self.player, brawler_id, skin_id
        )
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
