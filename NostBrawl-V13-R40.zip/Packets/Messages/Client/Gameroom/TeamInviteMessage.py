from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamInvitationMessage import TeamInvitationMessage
from Utils.Reader import BSMessageReader


class TeamInviteMessage(BSMessageReader):
    club_only = False

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.high_id = 0
        self.recipient_id = 0
        self.invite_type = 0

    def decode(self):
        self.high_id = self.read_Vint()
        self.recipient_id = self.read_Vint()
        self.invite_type = self.read_Vint()
        self.ensure_end()

    def process(self):
        room, invite = GameRoomService.invite(
            self.player, self.recipient_id, self.invite_type, self.club_only
        )
        GameRoomGateway.deliver(self.client, self.player, room)
        TeamInvitationMessage(
            None, self.player, invite
        ).sendWithLowID(self.recipient_id)
        return {"room": room, "invite": invite}
