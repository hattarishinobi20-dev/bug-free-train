from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamTogglePractiseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        room = GameRoomService.toggle_practice(self.player)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
