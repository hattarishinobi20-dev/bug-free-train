from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Reader import BSMessageReader


class TeamRequestJoinMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.room_high_id = 0
        self.room_id = 0
        self.owner_high_id = 0
        self.owner_id = 0

    def decode(self):
        self.room_high_id = self.read_int()
        self.room_id = self.read_int()
        self.owner_high_id = self.read_int()
        self.owner_id = self.read_int()
        self.ensure_end()

    def process(self):
        room = GameRoomService.request_join(
            self.player, self.room_id, self.owner_id
        )
        TeamGameroomDataMessage(
            None, self.player, room
        ).sendWithLowID(room["owner_id"])
        return room
