from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamInvitationResponseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.invite_type = 0
        self.high_id = 0
        self.room_id = 0
        self.accepted = False

    def decode(self):
        self.invite_type = self.read_Vint()
        self.high_id = self.read_int()
        self.room_id = self.read_int()
        self.accepted = self.read_boolean()
        self.ensure_end()

    def process(self):
        operation = (
            GameRoomService.accept_invite if self.accepted
            else GameRoomService.clear_invite
        )
        room, invite = operation(
            self.player, self.room_id, self.invite_type
        )
        if self.accepted:
            GameRoomGateway.deliver(self.client, self.player, room)
        else:
            GameRoomGateway.broadcast(self.player, room)
        return {"room": room, "invite": invite, "accepted": self.accepted}
