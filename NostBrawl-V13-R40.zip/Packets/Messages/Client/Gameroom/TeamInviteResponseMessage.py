from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamInviteResponseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.room_id = 0
        self.accepted = 0

    def decode(self):
        self.room_id = self.read_Vint()
        self.accepted = self.read_Vint()
        self.ensure_end()

    def process(self):
        if self.accepted:
            room, invite = GameRoomService.accept_invite(
                self.player, self.room_id
            )
            GameRoomGateway.deliver(self.client, self.player, room)
        else:
            room, invite = GameRoomService.clear_invite(
                self.player, self.room_id
            )
            GameRoomGateway.broadcast(self.player, room)
        return {"room": room, "invite": invite, "accepted": bool(self.accepted)}
