from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamPostAdMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.enabled = 0

    def decode(self):
        self.enabled = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_advertisement(self.player, self.enabled)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
