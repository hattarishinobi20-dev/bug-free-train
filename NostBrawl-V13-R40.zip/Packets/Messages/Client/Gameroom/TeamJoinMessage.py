from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamJoinMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.room_type = 0
        self.room_id = 0
        self.unknown = 0
        self.location = (0, -1)

    def decode(self):
        self.room_type = self.read_Vint()
        self.room_id = self.read_Vint()
        self.unknown = self.read_Vint()
        self.location = self.readScId()
        self.ensure_end()

    def process(self):
        room = GameRoomService.join(self.player, self.room_id)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
