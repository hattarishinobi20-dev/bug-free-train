from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamClearInviteMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.high_id = 0
        self.room_id = 0

    def decode(self):
        self.high_id = self.read_int()
        self.room_id = self.read_int()
        self.ensure_end()

    def process(self):
        room, invite = GameRoomService.clear_invite(self.player, self.room_id)
        if int(getattr(self.player, "room_id", 0)) == int(self.room_id):
            GameRoomGateway.deliver(self.client, self.player, room)
        return {"room": room, "invite": invite}
