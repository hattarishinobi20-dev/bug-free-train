from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomError, GameRoomService
from Logic.TeamCode import TeamCode
from Utils.Reader import BSMessageReader


class TeamJoinOrCreateRoomMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.code = ""

    def decode(self):
        self.code = self.read_string()
        self.ensure_end()

    def process(self):
        try:
            high_id, room_id = TeamCode.to_id(self.code)
        except ValueError:
            raise GameRoomError("Código de equipe inválido") from None
        if high_id != 0:
            raise GameRoomError("Código de equipe inválido")
        if room_id == 0:
            room = GameRoomService.create(self.player, 0, -64, 0, False)
        else:
            room = GameRoomService.join(self.player, room_id)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
