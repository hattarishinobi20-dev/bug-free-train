from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamRequestJoinApproveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.high_id = 0
        self.target_id = 0
        self.approved = False
        self.unknown = False

    def decode(self):
        self.high_id = self.read_int()
        self.target_id = self.read_int()
        self.approved = self.read_boolean()
        self.unknown = self.read_boolean()
        self.ensure_end()

    def process(self):
        room, request = GameRoomService.approve_join_request(
            self.player, self.target_id, self.approved
        )
        GameRoomGateway.deliver(self.client, self.player, room)
        return {"room": room, "request": request}
