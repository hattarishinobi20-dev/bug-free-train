from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamSetRankedLocationMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.unknown = 0
        self.slot = 0

    def decode(self):
        self.unknown = self.read_Vint()
        self.slot = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_ranked_location(self.player, self.slot)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
