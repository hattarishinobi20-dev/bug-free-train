from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Reader import BSMessageReader


class TeamRequestJoinCancelMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        rooms = GameRoomService.cancel_join_requests(self.player)
        for room in rooms:
            TeamGameroomDataMessage(
                None, self.player, room
            ).sendWithLowID(room["owner_id"])
        return rooms
