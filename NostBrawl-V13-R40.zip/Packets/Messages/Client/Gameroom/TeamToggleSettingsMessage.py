from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamToggleSettingsMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.enabled = False

    def decode(self):
        self.enabled = self.read_boolean()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_friend_advertisement(
            self.player, self.enabled
        )
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
