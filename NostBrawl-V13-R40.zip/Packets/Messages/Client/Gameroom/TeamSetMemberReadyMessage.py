from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamSetMemberReadyMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.ready = False
        self.unknown = 0

    def decode(self):
        self.ready = self.read_boolean()
        self.unknown = self.read_Vint()
        self.ensure_end()

    def process(self):
        room, started = GameRoomService.set_ready(self.player, self.ready)
        GameRoomGateway.deliver(self.client, self.player, room)
        if started:
            GameRoomGateway.send_starting(self.player, room, self.client)
        return {"room": room, "started": started}
