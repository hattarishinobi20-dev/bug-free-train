from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage
from Utils.Reader import BSMessageReader


class TeamLeaveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.ensure_end()

    def process(self):
        room = GameRoomService.leave(self.player)
        TeamLeftMessage(self.client, self.player).send()
        GameRoomGateway.broadcast(self.player, room, {self.player.low_id})
        return room
