from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class SetTeamChatMutedMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.muted = False

    def decode(self):
        self.muted = self.read_boolean()
        self.ensure_end()

    def process(self):
        return GameRoomService.set_team_chat_muted(self.player, self.muted)
