from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamReportChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.message_id = 0
        self.reported_id = 0

    def decode(self):
        self.message_id = self.read_int()
        self.reported_id = self.read_int()
        self.ensure_end()

    def process(self):
        return GameRoomService.report_chat(
            self.player, self.message_id, self.reported_id
        )
