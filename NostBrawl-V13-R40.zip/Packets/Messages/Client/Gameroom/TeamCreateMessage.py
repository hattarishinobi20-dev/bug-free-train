from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamCreateMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.map_slot = 0
        self.requested_map = 0
        self.room_type = 0
        self.practice = False

    def decode(self):
        self.map_slot = self.read_Vint()
        self.requested_map = self.read_Vint()
        self.room_type = self.read_Vint()
        self.practice = self.read_boolean()
        self.ensure_end()

    def process(self):
        room = GameRoomService.create(
            self.player, self.map_slot, self.requested_map,
            self.room_type, self.practice,
        )
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
