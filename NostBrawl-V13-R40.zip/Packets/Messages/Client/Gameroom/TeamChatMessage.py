from Logic.GameRoomService import GameRoomService
from Packets.Messages.Server.Gameroom.TeamChatServerMessage import TeamChatServerMessage
from Utils.Reader import BSMessageReader


class TeamChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.message = ""

    def decode(self):
        self.message = self.read_string()
        self.ensure_end()

    def process(self):
        room, chat = GameRoomService.add_chat(self.player, self.message)
        TeamChatServerMessage(self.client, self.player, chat).send()
        for member in room["members"]:
            if member["low_id"] == int(getattr(self.player, "low_id", 0)):
                continue
            TeamChatServerMessage(
                None, self.player, chat
            ).sendWithLowID(member["low_id"])
        return {"room": room, "chat": chat}
