from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomService
from Utils.Reader import BSMessageReader


class TeamMemberStatusMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.status = 0

    def decode(self):
        self.status = self.read_Vint()
        self.ensure_end()

    def process(self):
        room = GameRoomService.set_status(self.player, self.status)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
