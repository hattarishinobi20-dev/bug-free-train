from Packets.Messages.Client.Gameroom.TeamInviteMessage import TeamInviteMessage


class TeamAllianceMemberInviteMessage(TeamInviteMessage):
    club_only = True
