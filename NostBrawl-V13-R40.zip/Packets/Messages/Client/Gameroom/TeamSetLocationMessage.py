from Logic.GameRoomGateway import GameRoomGateway
from Logic.GameRoomService import GameRoomError, GameRoomService
from Utils.Reader import BSMessageReader


class TeamSetLocationMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.location = (0, -1)

    def decode(self):
        self.location = self.readScId()
        self.ensure_end()

    def process(self):
        csv_id, map_id = self.location
        if csv_id != 15:
            raise GameRoomError("DataReference de mapa inválida")
        room = GameRoomService.set_location(self.player, map_id)
        GameRoomGateway.deliver(self.client, self.player, room)
        return room
