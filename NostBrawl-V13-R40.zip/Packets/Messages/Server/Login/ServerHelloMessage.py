import secrets

from Utils.Writer import Writer


class ServerHelloMessage(Writer):
    """V13 ServerHello with the 24-byte value expected by the client."""

    SUFFIX = bytes.fromhex("00446f6e277420747279203a29")

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20100
        self.player = player

    def encode(self):
                                                                        
                                                                         
        session_value = secrets.token_bytes(11)
        self.player.server_hello_value = session_value
        self.writeInt(len(session_value + self.SUFFIX))
        self.writeBytes(session_value)
        self.writeBytes(self.SUFFIX)
