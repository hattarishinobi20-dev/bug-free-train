from Logic.ClubService import ClubService
from Utils.Writer import Writer


class AllianceBotChatServerMessage(Writer):
    def __init__(self, client, player, bot_msg_content):
        super().__init__(client)
        self.bot_msg_content = bot_msg_content
        self.id = 24312
        self.player = player

    def encode(self):
        club_id = int(getattr(self.player, "club_low_id", 0) or 0)
        message_count = len(ClubService.get_messages(club_id)) if club_id else 0
        self.writeVint(2)
        self.writeVint(0)
        self.writeVint(message_count)
        self.writeVint(1)
        self.writeVint(1)
        self.writeString("Club Bot")
        self.writeVint(3)
        self.writeVint(0)
        self.writeVint(0)
        self.writeString(self.bot_msg_content)
