from Utils.Writer import Writer


class BotProfileMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24113
        self.player = player

    def encode(self):
        self.writeVint(1)           
        self.writeVint(1)          

        self.writeBoolean(False)

        self.writeVint(len(self.player.brawlers_id))                           

        for brawler_id in self.player.brawlers_id:
            self.writeScId(16, brawler_id)
            self.writeVint(0)
            self.writeVint(99999)                   
            self.writeVint(99999)                           
            self.writeVint(10)                 

        self.writeVint(15)        

        self.writeVint(1)
        self.writeVint(99999)                 

        self.writeVint(2)
        self.writeVint(1262469)             

        self.writeVint(3)
        self.writeVint(self.player.trophies)            

        self.writeVint(4)
        self.writeVint(self.player.trophies)                    

        self.writeVint(5)
        self.writeVint(len(self.player.brawlers_id))                 

        self.writeVint(6)
        self.writeVint(0)

        self.writeVint(7)
        self.writeVint(99999)

        self.writeVint(8)
        self.writeVint(99999)                  

        self.writeVint(9)
        self.writeVint(99999)                         

        self.writeVint(10)
        self.writeVint(99999)                            

        self.writeVint(11)
        self.writeVint(99999)                 

        self.writeVint(12)
        self.writeVint(10)                                    

        self.writeVint(13)
        self.writeVint(99999)

        self.writeVint(14)
        self.writeVint(1)                               

        self.writeVint(15)
        self.writeVint(99999)                       


        self.writeString(self.player.name)              

        self.writeVint(100)
        self.writeVint(28000000)
        self.writeVint(43000000)

        in_club = True

        if in_club:

            self.writeBoolean(True)                 

            self.writeInt(0)               
            self.writeInt(1)              

            self.writeString("Classic Brawl")            

            self.writeVint(8)
            self.writeVint(5)           

            self.writeVint(3)             
            self.writeVint(2)                      

            self.writeVint(99999)                      
            self.writeVint(99999)                         
            self.writeVint(0)

            self.writeVint(0)
            self.writeVint(0)

        else:
            self.writeVint(0)
            self.writeVint(0)



