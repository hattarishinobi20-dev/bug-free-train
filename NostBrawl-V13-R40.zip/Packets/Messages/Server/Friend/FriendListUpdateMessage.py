from Logic.FriendPayload import encode_friend_entry
from Utils.Writer import Writer


class FriendListUpdateMessage(Writer):
    def __init__(self, client, player, entry, removed=False):
        super().__init__(client)
        self.id = 20106
        self.player = player
        self.entry = entry
        self.removed = bool(removed)

    def encode(self):
        self.writeBoolean(self.removed)
        encode_friend_entry(self, self.entry)
