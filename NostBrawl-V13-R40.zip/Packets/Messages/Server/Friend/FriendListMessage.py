from Logic.FriendPayload import encode_friend_entry
from Logic.FriendService import FriendService
from Utils.Writer import Writer


class FriendListMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20105
        self.player = player

    def encode(self):
        entries = FriendService.friends(self.player)
        self.writeInt(len(entries))
        self.writeBoolean(True)
        self.writeInt(len(entries))
        for entry in entries:
            encode_friend_entry(self, entry)
