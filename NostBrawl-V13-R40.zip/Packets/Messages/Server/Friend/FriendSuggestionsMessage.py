from Logic.FriendPayload import encode_friend_entry
from Utils.Writer import Writer


class FriendSuggestionsMessage(Writer):
    def __init__(self, client, player, entries):
        super().__init__(client)
        self.id = 20199
        self.player = player
        self.entries = list(entries)

    def encode(self):
        self.writeInt(len(self.entries))
        for entry in self.entries:
            self.writeInt(0)
            encode_friend_entry(self, entry)
