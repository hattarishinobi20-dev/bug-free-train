from Logic.LeaderboardService import LeaderboardService
from Packets.Messages.Server.Leaderboard.LeaderboardMessage import LeaderboardMessage


class GetLeaderboardClubGlobalOkMessage(LeaderboardMessage):
    def __init__(self, client, player, type=2):
        super().__init__(
            client, player, 2, False, LeaderboardService.clubs()
        )
