from Utils.Writer import Writer
from Logic.ClubService import ClubService
import json


class PlayerProfileMessage(Writer):

    def __init__(self, client, player, high_id, low_id, players):
        super().__init__(client)
        self.id = 24113
        self.player = player
        self.high_id = high_id
        self.low_id = low_id
        self.players = players

    def encode(self):
        for player in self.players:
            if self.low_id == player[4]:
                self.UnlockedBrawlersList = []
                UnlockedBrawlers = json.loads(player[34])
                for brawler_id in UnlockedBrawlers:
                    if UnlockedBrawlers[brawler_id] == 1:
                        self.UnlockedBrawlersList.append(int(brawler_id))

                self.writeVint(self.high_id)           
                self.writeVint(self.low_id)          
                self.writeVint(0)           

                self.writeVint(len(self.UnlockedBrawlersList))                  

                for brawler_id in self.UnlockedBrawlersList:
                    brawlerTrophies = json.loads(player[29])
                    brawlerTrophiesForRank = json.loads(player[30])
                    brawlerPowerLevel = json.loads(player[32])
                    brawlerStarPower = json.loads(player[33])
                    self.writeScId(16, int(brawler_id))
                    self.writeVint(0)
                    self.writeVint(brawlerTrophies[str(brawler_id)])             
                    self.writeVint(brawlerTrophiesForRank[str(brawler_id)])                     
                    if brawlerStarPower[str(brawler_id)] >= 1:
                        self.writeVint(2 + brawlerPowerLevel[str(brawler_id)])
                    else:
                        self.writeVint(1 + brawlerPowerLevel[str(brawler_id)])

                self.writeVint(15)

                self.writeVint(1)
                self.writeVint(player[11])                 

                self.writeVint(2)
                self.writeVint(player[8])                     

                self.writeVint(3)
                self.writeVint(player[19])            

                self.writeVint(4)
                self.writeVint(player[20])                    

                self.writeVint(5)
                self.writeVint(len(self.UnlockedBrawlersList))                 

                self.writeVint(7)
                self.writeVint(28000000 + player[21])                  

                self.writeVint(8)
                self.writeVint(player[9])                  

                self.writeVint(9)
                self.writeVint(0)                         

                self.writeVint(10)
                self.writeVint(0)                            

                self.writeVint(11)
                self.writeVint(player[10])                 

                self.writeVint(12)
                self.writeVint(0)                                 

                self.writeVint(13)
                self.writeVint(0)                               

                self.writeVint(14)
                self.writeVint(0)                           

                self.writeVint(15)
                self.writeVint(0)                       

                self.writeVint(16)
                self.writeVint(20)

                self.writeString(player[2])
                self.writeVint(100)
                self.writeVint(28000000 + player[21])                
                self.writeVint(43000000 + player[22])              

                club = ClubService.get_club(player[6]) if player[6] else None
                if club is not None:
                    self.writeBoolean(True)
                    self.writeInt(0)
                    self.writeInt(club["id"])
                    self.writeString(club["name"])
                    self.writeVint(8)
                    self.writeVint(club["badge_id"])
                    self.writeVint(club["type"])
                    self.writeVint(club["member_count"])
                    self.writeVint(club["trophies"])
                    self.writeVint(club["required_trophies"])
                    self.writeVint(0)
                    self.writeString(club["region"])
                    self.writeVint(0)
                    self.writeVint(25)
                    self.writeVint(player[7])
                else:
                    self.writeVint(0)
                    self.writeVint(0)