from Utils.Writer import Writer


class BattleLogMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23458
        self.player = player

    def encode(self):
        self.writeBoolean(True)

        self.writeVint(0)        

        self.writeVint(0)
        self.writeVint(0)                                            
        self.writeVint(1)                                                                       
        self.writeVint(6)                     
        self.writeVint(120)               
        self.writeUInt8(0)                                                          
        self.writeScId(15, 95)           
        self.writeVint(2)                      
        self.writeVint(0)      

        self.writeInt(0)
        self.writeInt(0)

        self.writeVint(1)
        self.writeUInt8(1)

        self.writeVint(0)         

        self.writeVint(0)
        self.writeUInt8(0)
        self.writeVint(0)
        self.writeUInt8(0)
        self.writeVint(0)

        print("[INFO] Message BattleLogMessage has been sent.")
