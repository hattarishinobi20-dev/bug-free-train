from Utils.Writer import Writer


class StartLoadingMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20559
        self.client = client
        self.player = player

    def encode(self):
        self.writeInt(1)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(1)
        for i in range(1):
            self.writeLong(0, self.player.low_id)
            self.writeVint(1)
            self.writeVint(0)
            self.writeVint(0)
            self.writeInt(1000000)
            self.writeScId(16, 0)
            self.writeScId(29, 29)
            self.writeBoolean(False)
            self.writeString("Nost Brawl")
            self.writeVint(100)
            self.writeVint(28000000)
            self.writeVint(43000000)
        self.writeInt(0)
        self.writeInt(0)
        self.writeInt(0)
        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(1)
        self.writeBoolean(True)
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(15, self.player.map_id)
        self.writeBoolean(False)
