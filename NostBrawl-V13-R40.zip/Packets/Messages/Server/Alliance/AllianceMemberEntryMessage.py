from Database.DatabaseManager import DataBase
from Utils.Writer import Writer
import json

class AllianceMemberEntryMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24308
        self.player = player

    def encode(self):
        self.writeInt(0)              
        self.writeInt(self.player.ClubID)             
        
        self.writeInt(self.player.HighID)
        self.writeInt(self.player.LowID)
        self.writeString(self.player.name)              
        self.writeVint(100)
        self.writeVint(28000000 + self.player.profileIcon)               
        self.writeVint(43000000 + self.player.namecolor)             
        self.writeHexa('''7F''')