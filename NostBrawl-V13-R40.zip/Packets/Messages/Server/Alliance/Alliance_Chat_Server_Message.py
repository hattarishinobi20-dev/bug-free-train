from Logic.ClubService import ClubService
from Utils.Writer import Writer


class AllianceChatServerMessage(Writer):
    def __init__(self, client, player, msg_content, clubID, isbot=False, entry=None):
        super().__init__(client)
        self.msg_content = msg_content
        self.id = 24312
        self.player = player
        self.clubID = clubID
        self.isbot = isbot
        self.client = client
        self.entry = entry

    def _latest_entry(self):
        entries = ClubService.get_messages(self.clubID)
        if not entries:
            raise ValueError("Club stream is empty")
        if isinstance(self.msg_content, int):
            for entry in reversed(entries):
                if entry["event"] == 4 and entry["message"] == str(self.msg_content):
                    return entry
        else:
            for entry in reversed(entries):
                if entry["event"] == 2 and entry["message"] == str(self.msg_content):
                    return entry
        return entries[-1]

    def encode(self):
        entry = self.entry or self._latest_entry()
        self.writeVint(entry["event"])
        self.writeVint(0)
        self.writeVint(1 if self.isbot else entry.get("position", entry["id"]))
        self.writeVint(0)
        self.writeVint(entry["player_id"])
        self.writeString(entry["player_name"])
        self.writeVint(entry["player_role"])
        self.writeVint(0)
        self.writeVint(0)
        if entry["event"] == 4:
            self.writeVint(int(entry["message"]))
            self.writeVint(1)
            self.writeVint(0)
            self.writeVint(entry["player_id"])
            self.writeString(entry["player_name"])
        else:
            self.writeString(entry["message"])
