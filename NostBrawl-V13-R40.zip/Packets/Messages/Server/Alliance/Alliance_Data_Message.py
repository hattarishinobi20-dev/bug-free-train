from Logic.ClubService import ClubService
from Utils.Writer import Writer


class AllianceDataMessage(Writer):
    def __init__(self, client, player, clubHighID, clubLowID, member_override=None):
        super().__init__(client)
        self.id = 24301
        self.player = player
        self.clubHighID = clubHighID
        self.clubLowID = clubLowID
        self.member_override = member_override

    def encode(self):
        club = ClubService.get_club(self.clubLowID) or {
            "id": self.clubLowID,
            "name": "",
            "description": "",
            "region": "",
            "badge_id": 0,
            "type": 0,
            "required_trophies": 0,
            "members": [],
            "member_count": 0,
            "trophies": 0,
        }
        is_member = bool(getattr(self.player, "club_low_id", 0)) if self.member_override is None else self.member_override
        self.writeVint(0 if is_member else 2)
        self.writeInt(0)
        self.writeInt(club["id"])
        self.writeString(club["name"])
        self.writeVint(8)
        self.writeVint(club["badge_id"])
        self.writeVint(club["type"])
        self.writeVint(club["member_count"])
        self.writeVint(club["trophies"])
        self.writeVint(club["required_trophies"])
        self.writeVint(0)
        self.writeVint(0)
        self.writeString(club["description"])
        self.writeVint(club["member_count"])
        for member in club["members"]:
            self.writeInt(0)
            self.writeInt(member["low_id"])
            self.writeString(member["name"])
            self.writeVint(member["role"])
            self.writeVint(member["trophies"])
            self.writeVint(member["status"])
            self.writeVint(0)
            self.writeVint(0)
            self.writeScId(28, member["profile_icon"])
