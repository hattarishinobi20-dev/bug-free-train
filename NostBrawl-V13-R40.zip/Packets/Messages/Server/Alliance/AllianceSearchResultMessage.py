from Logic.ClubService import ClubService
from Utils.Writer import Writer


class AllianceSearchResultMessage(Writer):
    def __init__(self, client, player, requestedName, count, clubs=None):
        super().__init__(client)
        self.id = 24310
        self.player = player
        self.requestedName = str(requestedName)
        self.count = count
        self.clubs = clubs

    def encode(self):
        clubs = self.clubs
        if clubs is None:
            clubs = ClubService.list_clubs(1, 100, 2, self.count, self.requestedName)
        self.writeString(self.requestedName)
        self.writeVint(len(clubs))
        for club in clubs:
            self.writeInt(0)
            self.writeInt(club["id"])
            self.writeString(club["name"])
            self.writeVint(8)
            self.writeVint(club["badge_id"])
            self.writeVint(club["type"])
            self.writeVint(club["member_count"])
            self.writeVint(club["trophies"])
            self.writeVint(club["required_trophies"])
            self.writeVint(0)
            self.writeString(club["region"])
            self.writeVint(club["member_count"])
