from Utils.Writer import Writer


class TeamErrorMessage(Writer):
    def __init__(self, client, player, error=1):
        super().__init__(client)
        self.id = 24129
        self.player = player
        self.error = int(error)

    def encode(self):
        self.writeVint(self.error)
        self.writeVint(self.error)
