from Utils.Writer import Writer


class TeamInvitationMessage(Writer):
    def __init__(self, client, player, invite):
        super().__init__(client)
        self.id = 24589
        self.player = player
        self.invite = invite

    def encode(self):
        self.writeVint(self.invite["invite_type"])
        self.writeLong(0, self.invite["room_id"])
