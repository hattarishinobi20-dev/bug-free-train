from Logic.FriendPayload import encode_friend_entry
from Utils.Writer import Writer


class TeamGameroomDataMessage(Writer):
    def __init__(self, client, player, room):
        super().__init__(client)
        self.id = 24124
        self.player = player
        self.room = room

    def encode(self):
        room = self.room
        self.writeVint(room["state"])
        self.writeBoolean(room["practice"])
        self.writeVint(room["capacity"])
        self.writeLong(0, room["id"])
        self.writeVint(room["room_type"])
        self.writeBoolean(room["advertise_band"])
        self.writeBoolean(room["advertise_friends"])
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(15, room["map_id"])
        members = room["members"]
        self.writeVint(len(members))
        for member in members:
            self.writeBoolean(member["host"])
            self.writeLong(member["high_id"], member["low_id"])
            self.writeString(member["name"])
            self.writeVint(0)
            self.writeScId(16, member["brawler_id"])
            self.writeScId(29, member["skin_id"])
            self.writeVint(member["trophies"])
            self.writeVint(member["highest_trophies"])
            self.writeVint(member["power_level"])
            self.writeVint(member["status"])
            self.writeBoolean(member["ready"])
            self.writeVint(member["team"])
            self.writeVint(0)
        invites = room.get("invites", [])
        self.writeVint(len(invites))
        for invite in invites:
            self.writeLong(0, invite["sender_id"])
            self.writeLong(0, invite["recipient_id"])
            self.writeString(invite["name"])
            self.writeVint(invite["invite_type"])
            self.writeVint(invite["status"])
        requests = room.get("join_requests", [])
        self.writeVint(len(requests))
        for request in requests:
            self.writeLong(0, room["id"])
            self.writeLong(0, request["player_id"])
            encode_friend_entry(self, request["entry"])
