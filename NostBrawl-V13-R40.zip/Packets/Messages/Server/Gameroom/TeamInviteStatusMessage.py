from Utils.Writer import Writer


class TeamInviteStatusMessage(Writer):
    def __init__(self, client, player, status, low_id=None):
        super().__init__(client)
        self.id = 24582
        self.player = player
        self.status = int(status)
        self.low_id = low_id

    def encode(self):
        self.writeInt(self.status)
        self.writeBoolean(self.low_id is not None)
        if self.low_id is not None:
            self.writeLong(0, int(self.low_id))
