import time

from Utils.Writer import Writer


class TeamChatServerMessage(Writer):
    def __init__(self, client, player, chat):
        super().__init__(client)
        self.id = 24131
        self.player = player
        self.chat = chat

    def encode(self):
        chat = self.chat
        age = max(0, int(time.time()) - int(chat["created_at"]))
        self.writeVint(0)
        self.writeVint(chat["room_id"])
        self.writeVint(1)
        self.writeVint(2)
        self.writeVint(0)
        self.writeVint(chat["id"])
        self.writeVint(0)
        self.writeVint(chat["player_id"])
        self.writeString(chat["player_name"])
        self.writeVint(0)
        self.writeVint(age)
        self.writeBoolean(False)
        self.writeString(chat["message"])
