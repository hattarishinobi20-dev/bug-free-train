from Utils.Writer import Writer


class BuyBundleBillingPackResponseMessage(Writer):
    def __init__(self, client, player, package_type, starter_pack_number):
        super().__init__(client)
        self.id = 28363
        self.player = player
        self.package_type = package_type
        self.starter_pack_number = starter_pack_number

    def encode(self):
        self.writeVint(self.package_type)
        self.writeVint(self.starter_pack_number)
