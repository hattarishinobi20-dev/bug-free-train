import random

from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Utils.Config import Config


class LogicBoxGenerator:
    BRAWLER_POOLS = {
        "common": (0, 1, 2, 3, 7, 8, 9, 14),
        "rare": (6, 10, 13, 24),
        "super_rare": (4, 18, 19, 25),
        "epic": (15, 16, 20, 26),
        "mega_epic": (11, 17, 21),
        "legendary": (5, 12, 23),
    }
    BRAWLER_CHANCES = (
        (10, "legendary"),
        (25, "mega_epic"),
        (70, "epic"),
        (200, "super_rare"),
        (400, "rare"),
    )
    SKIN_POOLS = {
        "rare": (15, 27, 29, 94, 117),
        "super_rare": (5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93),
        "epic": (26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91),
        "legendary": (49,),
        "silver": (95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115),
        "gold": (96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116),
    }
    POINT_TARGETS = {1: 2, 3: 3, 10: 5}
    REWARD_ORDER = (
        "Coins", "UpgradePoints", "Brawler", "StarPower", "Skin",
        "gems", "tokens_doubler", "tickets",
    )
    AGGREGATED = {"Coins", "gems", "tokens_doubler", "tickets"}

    @staticmethod
    def _number(mapping, key, default=0):
        try:
            return int(mapping.get(str(key), mapping.get(key, default)) or 0)
        except (AttributeError, TypeError, ValueError):
            return default

    @staticmethod
    def _owned_skins(player):
        owned = getattr(player, "UnlockedSkins", {})
        if isinstance(owned, dict):
            owned = owned.get("Skins", [])
        if not isinstance(owned, (list, tuple, set)):
            return set()
        result = set()
        for skin in owned:
            try:
                result.add(int(skin))
            except (TypeError, ValueError):
                continue
        return result

    @classmethod
    def _brawler_pools(cls, player, playable):
        states = getattr(player, "BrawlersUnlockedState", {})
        playable = set(playable)
        return {
            rarity: [
                brawler for brawler in pool
                if brawler in playable and cls._number(states, brawler) != 1
            ]
            for rarity, pool in cls.BRAWLER_POOLS.items()
        }

    @classmethod
    def _point_targets(cls, player, playable):
        states = getattr(player, "BrawlersUnlockedState", {})
        levels = getattr(player, "Brawler_level", {})
        points = getattr(player, "brawlers_upgradium", {})
        return [
            brawler for brawler in playable
            if cls._number(states, brawler) == 1
            and cls._number(levels, brawler, 1) not in (8, 9)
            and max(0, cls._number(points, brawler)) <= 1500
        ]

    @classmethod
    def _star_power_targets(cls, player, playable):
        states = getattr(player, "BrawlersUnlockedState", {})
        levels = getattr(player, "Brawler_level", {})
        powers = getattr(player, "Brawler_starPower", {})
        return [
            brawler for brawler in playable
            if cls._number(states, brawler) == 1
            and cls._number(levels, brawler, 1) == 8
            and cls._number(powers, brawler) == 0
            and Cards.get_brawler_star_power(brawler) != 0
        ]

    @classmethod
    def _skin_pools(cls, player, settings, playable):
        owned = cls._owned_skins(player)
        states = getattr(player, "BrawlersUnlockedState", {})
        available = set(Skins.get_skins_id())
        unique = settings.get("UniqueSkinsBox", True)
        pools = {}
        for rarity, pool in cls.SKIN_POOLS.items():
            if rarity in {"silver", "gold"} and not unique:
                pools[rarity] = []
                continue
            candidates = []
            for skin in pool:
                if skin not in available or skin in owned:
                    continue
                brawler = Skins.getBrawler(skin)
                if brawler not in playable or cls._number(states, brawler) != 1:
                    continue
                if rarity == "gold" and skin - 1 not in owned:
                    continue
                candidates.append(skin)
            pools[rarity] = candidates
        return pools

    @staticmethod
    def _skin_rarity(roll):
        if roll <= 59:
            return "rare"
        if roll <= 84:
            return "super_rare"
        if roll <= 94:
            return "epic"
        if roll <= 97:
            return "legendary"
        if roll <= 99:
            return "silver"
        return "gold"

    @classmethod
    def _context(cls, player, settings):
        playable = list(Characters.get_brawlers_id())
        return {
            "brawlers": cls._brawler_pools(player, playable),
            "points": cls._point_targets(player, playable),
            "starPowers": cls._star_power_targets(player, playable),
            "skins": cls._skin_pools(player, settings, playable),
        }

    @classmethod
    def _generate_single(cls, box_type, rng, settings, context):
        brawler_pools = context["brawlers"]
        point_targets = context["points"]
        star_power_targets = context["starPowers"]
        skin_pools = context["skins"]
        gold = 0
        card_points = 0
        brawlers = []
        star_powers = []
        skins = []

        for _ in range(box_type):
            brawler_roll = rng.randint(1, 10000)
            star_power_roll = rng.randint(1, 1000)
            skin_roll = rng.randint(1, 1000)
            iteration_gold = rng.randint(30, 60)
            iteration_cards = rng.randint(12, 26)
            gold += iteration_gold
            card_points += iteration_cards

            def replace_base_reward():
                nonlocal gold, card_points
                gold = max(0, gold - iteration_gold)
                card_points = max(0, card_points - iteration_cards)

            if settings.get("BrawlersBox", True):
                for threshold, rarity in cls.BRAWLER_CHANCES:
                    if brawler_roll > threshold:
                        continue
                    pool = brawler_pools[rarity]
                    if pool:
                        brawler = rng.choice(pool)
                        pool.remove(brawler)
                        brawlers.append(brawler)
                        replace_base_reward()
                    break

            if star_power_roll < 10 and star_power_targets:
                target = rng.choice(star_power_targets)
                star_power_targets.remove(target)
                star_powers.append(target)
                replace_base_reward()

            if settings.get("SkinsBox", True) and skin_roll <= 20:
                rarity = cls._skin_rarity(rng.randint(1, 100))
                pool = skin_pools[rarity]
                if pool:
                    skin = rng.choice(pool)
                    pool.remove(skin)
                    skins.append(skin)
                    replace_base_reward()

        rewards = []
        if gold > 0:
            rewards.append({"name": "Coins", "amount": gold, "target": 0})

        point_amounts = []
        if card_points > 0:
            for index in range(cls.POINT_TARGETS[box_type]):
                if index == 4:
                    amount = card_points
                elif card_points <= 20:
                    amount = rng.randint(5, 15)
                else:
                    amount = rng.randint(10, card_points // 2)
                    card_points -= amount
                if amount > 0:
                    point_amounts.append(amount)
        point_amounts.sort()

        target_count = min(
            len(point_targets), cls.POINT_TARGETS[box_type], len(point_amounts)
        )
        awarded_points = []
        for _ in range(target_count):
            target = rng.choice(point_targets)
            point_targets.remove(target)
            awarded_points.append([target, point_amounts.pop(0)])
        if awarded_points and target_count < 5:
            extra = 20 // len(awarded_points)
            for point_reward in awarded_points:
                point_reward[1] += extra
        for target, amount in awarded_points:
            rewards.append({
                "name": "UpgradePoints", "amount": amount, "target": target,
            })

        for brawler in brawlers:
            rewards.append({"name": "Brawler", "amount": brawler, "target": 0})
        for target in star_powers:
            rewards.append({
                "name": "StarPower",
                "amount": Cards.get_brawler_star_power(target),
                "target": target,
            })
        for skin in skins:
            rewards.append({
                "name": "Skin",
                "amount": skin,
                "target": Skins.getBrawler(skin),
                "select_skin": False,
            })

        bonuses = {"gems": 0, "tokens_doubler": 0, "tickets": 0}
        for _ in range(box_type):
            if rng.randint(1, 5) != 1:
                continue
            bonus_roll = rng.randint(1, 11)
            if bonus_roll == 10:
                bonuses["gems"] = rng.randint(3, 10)
            elif bonus_roll == 7:
                bonuses["tokens_doubler"] = 200
            else:
                bonuses["tickets"] = rng.choice([3, 5, 7, 10])
        for name in ("gems", "tokens_doubler", "tickets"):
            if bonuses[name] > 0:
                rewards.append({"name": name, "amount": bonuses[name], "target": 0})
        return rewards

    @classmethod
    def generate_rewards(cls, player, box_type, box_count=1, rng=random):
        try:
            box_type = int(box_type)
            box_count = int(box_count)
        except (TypeError, ValueError):
            raise ValueError("Tipo ou quantidade de caixa inválido") from None
        if box_type not in cls.POINT_TARGETS or box_count < 1:
            raise ValueError("Tipo ou quantidade de caixa inválido")

        settings = Config.GetValue()
        context = cls._context(player, settings)
        grouped = {name: [] for name in cls.REWARD_ORDER}
        for _ in range(box_count):
            for reward in cls._generate_single(box_type, rng, settings, context):
                grouped[reward["name"]].append(reward)

        rewards = []
        for name in cls.REWARD_ORDER:
            entries = grouped[name]
            if not entries:
                continue
            if name in cls.AGGREGATED:
                rewards.append({
                    "name": name,
                    "amount": sum(int(entry["amount"]) for entry in entries),
                    "target": 0,
                })
            else:
                rewards.extend(entries)
        return rewards
