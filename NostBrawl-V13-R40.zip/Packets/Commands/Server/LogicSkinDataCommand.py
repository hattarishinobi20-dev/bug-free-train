from Packets.Commands.Server.LogicBuyItem import LogicBuyItem


class LogicSkinDataCommand(LogicBuyItem):
    def __init__(self, client, player, ID, v13=False):
        if isinstance(ID, dict):
            result = ID
            if result.get("rewardNames") != ["Skin"]:
                raise ValueError("LogicSkinDataCommand requires one skin reward")
            skin = int(result.get("skin", result["rewards"][0]))
        else:
            skin = int(ID)
        tail = [0, 0, 1, 0, 0]
        if v13:
            tail.append(0)
        super().__init__(
            client, player, [{"type": 7, "amount": 1, "skin": skin}], tail
        )
