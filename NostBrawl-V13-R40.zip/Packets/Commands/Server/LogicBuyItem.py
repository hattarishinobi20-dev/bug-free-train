from Utils.Writer import Writer


class LogicBuyItem(Writer):
    REWARD_TYPES = {
        1: 7,
        2: 8,
        3: 3,
        4: 2,
        5: 6,
        6: 1,
        7: 9,
        8: 4,
        9: 6,
    }

    def __init__(self, client, player, rewards, response_tail=None):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.rewards = list(rewards or [])
        self.response_tail = (
            [0] * 13 if response_tail is None else list(response_tail)
        )
        if not 1 <= len(self.rewards) <= 3:
            raise ValueError("LogicBuyItem requires between one and three rewards")

    def _encode_rewards(self):
        for reward in self.rewards:
            item_type = int(reward["type"])
            if item_type not in self.REWARD_TYPES:
                raise ValueError(f"Unsupported shop reward type: {item_type}")
            amount = int(reward.get("amount", 1))
            brawler = int(reward.get("brawler", 0))
            skin = int(reward.get("skin", 0))
            if amount < 1:
                raise ValueError("LogicBuyItem requires positive reward amounts")
            self.writeVint(amount)
            if item_type in (5, 6, 8, 9):
                self.writeScId(16, brawler)
            else:
                self.writeVint(0)
            self.writeVint(self.REWARD_TYPES[item_type])
            if item_type == 7:
                self.writeScId(29, skin)
            else:
                self.writeVint(0)
            self.writeVint(0)

    def encode(self):
        self.writeVint(203)
        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(100)
        self.writeVint(len(self.rewards))
        self._encode_rewards()
        for value in self.response_tail:
            self.writeVint(value)
