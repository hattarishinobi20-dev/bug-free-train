from Logic.Boxes import Boxes
from Utils.Writer import Writer


class LogicBoxDataCommand(Writer):
    def __init__(
        self, client, player, boxID=100, rewards=None, rewardNames=None,
        rewardsTargetBrawler=None, trophyRoad=0,
    ):
        super().__init__(client)
        self.id = 24111
        self.player = player
        box_type = boxID
        box_count = 1
        if isinstance(boxID, dict):
            result = boxID
            boxID = result["boxID"]
            box_type = result.get("boxType", boxID)
            box_count = result.get("boxCount", 1)
            rewards = result["rewards"]
            rewardNames = result["rewardNames"]
            rewardsTargetBrawler = result["rewardsTargetBrawler"]
            trophyRoad = result.get("trophyRoad", 0)
        self.boxID = boxID
        self.boxType = box_type
        self.boxCount = int(box_count)
        self.rewards = list(rewards or [])
        self.rewardNames = list(rewardNames or [])
        self.rewardsTargetBrawler = list(rewardsTargetBrawler or [])
        self.trophyRoad = trophyRoad

    def getBoxType(self, boxID):
        try:
            return Boxes.get_box_type(boxID)
        except ValueError:
            return boxID

    @staticmethod
    def itemType(item):
        return {
            "Brawler": 1,
            "tokens_doubler": 2,
            "tickets": 3,
            "StarPower": 4,
            "UpgradePoints": 6,
            "Coins": 7,
            "gems": 8,
            "Skin": 9,
        }[item]

    def encode(self):
        if not (
            len(self.rewards) == len(self.rewardNames)
            == len(self.rewardsTargetBrawler)
        ):
            raise ValueError("Reward arrays have different lengths")
        if self.boxCount < 1:
            raise ValueError("Invalid box count")
        self.writeVint(203)
        self.writeVint(self.getBoxType(self.boxType))
        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(len(self.rewards))
        for amount, name, target in zip(
            self.rewards, self.rewardNames, self.rewardsTargetBrawler
        ):
            amount = int(amount)
            target = int(target)
            reward_type = self.itemType(name)
            if name in {"Coins", "gems", "tickets", "tokens_doubler"}:
                self.writeVint(amount)
                self.writeScId(0, reward_type)
                self.writeVint(0)
                self.writeVint(0)
                continue
            if name == "UpgradePoints":
                self.writeVint(amount)
                self.writeScId(16, target)
                self.writeVint(reward_type)
                self.writeVint(0)
                self.writeVint(0)
                continue
            self.writeVint(1)
            if name == "Skin":
                self.writeVint(0)
                self.writeVint(reward_type)
                self.writeScId(29, amount)
                self.writeVint(0)
                continue
            if name == "StarPower":
                self.writeScId(23, amount)
            else:
                self.writeScId(16, amount)
            self.writeVint(reward_type)
            self.writeVint(0)
            self.writeVint(0)
        self.writeVint(int(self.trophyRoad or 0))
