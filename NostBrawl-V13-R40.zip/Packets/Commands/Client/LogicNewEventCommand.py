from Logic.EventRotation import EventRotation
from Utils.Reader import BSMessageReader


class LogicNewEventCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.event_index = 0

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.event_index = self.read_Vint()

    def process(self):
        return EventRotation.claim(self.player, self.event_index)
