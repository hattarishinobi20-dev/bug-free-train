from Logic.BoxService import open_boxes
from Logic.Rewards import RewardError
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Utils.Reader import BSMessageReader


class LogicPurchaseBoxCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.box_id = 0

    def decode(self):
                                                                                
                                                                               
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        self.box_id = self.read_Vint()

    def process(self):
        try:
            result = open_boxes(self.player, self.box_id)
        except RewardError as error:
            return str(error)
        LogicBoxDataCommand(self.client, self.player, result).send()
        return result
