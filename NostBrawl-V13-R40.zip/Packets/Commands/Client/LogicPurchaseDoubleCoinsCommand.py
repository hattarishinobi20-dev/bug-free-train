from Logic.Rewards import RewardError, RewardTransaction
from Logic.ShopCatalog import ShopCatalog
from Utils.Reader import BSMessageReader


class LogicPurchaseDoubleCoinsCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()

    def process(self):
        try:
            transaction = RewardTransaction(self.player)
            transaction.charge("gems", ShopCatalog.TOKEN_DOUBLER["Cost"])
            transaction.add_reward(
                "tokens_doubler", ShopCatalog.TOKEN_DOUBLER["Amount"]
            )
            transaction.commit()
            return {
                "gems": self.player.gems,
                "tokensdoubler": self.player.tokensdoubler,
            }
        except (RewardError, TypeError, ValueError) as error:
            return str(error)
