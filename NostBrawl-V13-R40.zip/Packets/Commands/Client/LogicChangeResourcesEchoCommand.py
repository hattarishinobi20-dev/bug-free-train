from Utils.Reader import BSMessageReader


class LogicChangeResourcesEchoCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        self.resource_global_id = self.read_Vint()
        self.resource_amount = self.read_Vint()
        self.response_tail = [self.read_Vint() for _ in range(5)]

    def process(self):
        return None
