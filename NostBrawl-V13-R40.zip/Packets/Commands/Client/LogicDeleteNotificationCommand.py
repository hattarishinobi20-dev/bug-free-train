from Logic.NotificationFactory import NotificationFactory
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand


class LogicDeleteNotificationCommand:
    SKIN_REWARD_ACTION = 8

    @staticmethod
    def decode(reader):
        for _ in range(4):
            reader.read_Vint()
        reader.notification_action = reader.read_Vint()

    @staticmethod
    def process(reader):
        if (
            reader.notification_action
            != LogicDeleteNotificationCommand.SKIN_REWARD_ACTION
        ):
            return "A ação não pertence a uma recompensa de skin"
        try:
            result = NotificationFactory.claim_next_skin(reader.player)
        except (TypeError, ValueError) as error:
            return str(error)
        LogicSkinDataCommand(
            reader.client, reader.player, result["skin"], v13=True
        ).send()
        return result
