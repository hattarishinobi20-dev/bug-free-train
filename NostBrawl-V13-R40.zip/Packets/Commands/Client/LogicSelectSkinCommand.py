import copy

from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Skins import Skins
from Logic.Rewards import RewardError, RewardTransaction
from Utils.Reader import BSMessageReader


class LogicSelectSkinCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
                                                                             
                                                                              
        self.read_Vint()
        self.read_Vint()
        self.readLogicLong()
        self.skin_reference = self.readScId()
        if self.skin_reference[0] != 29 or self.skin_reference[1] < 0:
            raise ValueError(f"Invalid skin DataReference: {self.skin_reference}")
        self.skin_id = self.skin_reference[1]

    def process(self):
        try:
            skin = int(getattr(self, "skin_id", self.player.skin_id))
            brawler = int(self.player.brawler_id)
            states = getattr(self.player, "BrawlersUnlockedState", {})
            if states.get(str(brawler), states.get(brawler, 0)) != 1:
                raise RewardError("O brawler precisa estar desbloqueado")
            if skin != 0:
                if skin not in Skins.get_skins_id():
                    raise RewardError("Skin inválida")
                if Skins.getBrawler(skin) != brawler:
                    raise RewardError("Skin e brawler não correspondem")
                owned = getattr(self.player, "UnlockedSkins", {}).get("Skins", [])
                if skin not in owned:
                    raise RewardError("A skin precisa estar desbloqueada")

            selected = copy.deepcopy(getattr(self.player, "brawlers_skins", {}))
            selected[str(brawler)] = skin
            starpower = Cards.get_spg_by_brawler_id(self, brawler, 4)
            transaction = RewardTransaction(self.player)
            transaction.set_value("skin_id", "skinID", skin)
            transaction.set_value("brawler_id", "brawlerID", brawler)
            transaction.set_value("brawlers_skins", "brawlersSkins", selected)
            transaction.set_value("starpower", "starpower", starpower)
            transaction.commit()
            return {"skin": skin, "brawler": brawler}
        except (RewardError, TypeError, ValueError) as error:
            return str(error)
