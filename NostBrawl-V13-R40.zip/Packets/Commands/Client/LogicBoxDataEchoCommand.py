from Utils.Reader import BSMessageReader


class LogicBoxDataEchoCommand(BSMessageReader):
    """Consume the patched client's 203 echo without applying rewards again."""

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        self.box_count_or_type = self.read_Vint()
        self.box_count = self.read_Vint()
        self.box_id = self.read_Vint()
        reward_count = self.read_Vint()
        if reward_count < 0 or reward_count > 64:
            raise ValueError(f"Invalid 203 reward count: {reward_count}")
        self.rewards = []
        self.v18_skin_response = (
            (self.box_count_or_type, self.box_count, self.box_id, reward_count)
            == (0, 1, 100, 1)
        )
        if self.v18_skin_response:
            amount = self.read_Vint()
            csv_id = self.read_Vint()
            reward_type = self.read_Vint()
            reference = self.readScId()
            if csv_id != 0 or reward_type != 9 or reference[0] != 29:
                raise ValueError("Invalid V18 skin reward echo")
            self.rewards.append((amount, reward_type, reference))
            self.trophy_road = 0
            if self.command_count == 1:
                end = len(self.initial_bytes)
                if self.initial_bytes.endswith(b"\xff" * 4):
                    end -= 4
                values = []
                while self.tell() < end:
                    values.append(self.read_Vint())
                if len(values) in (6, 11):
                    tail_size = 6
                elif len(values) in (7, 12):
                    tail_size = 7
                else:
                    raise ValueError("Invalid skin reward echo suffix")
                self.response_tail = values[:tail_size]
                self.turn_context = values[tail_size:]
            else:
                self.response_tail = [self.read_Vint() for _ in range(6)]
                self.turn_context = [self.read_Vint() for _ in range(5)]
            if (
                self.response_tail[:6] != [0, 0, 0, 1, 0, 0]
                or any(self.response_tail[6:])
                or len(self.turn_context) not in (0, 5)
            ):
                raise ValueError("Invalid skin reward echo suffix")
            return

        for _ in range(reward_count):
            amount = self.read_Vint()
            csv_id = self.read_Vint()
            reference_or_type = self.read_Vint()
            if csv_id == 0:
                reward_type = reference_or_type
                if reward_type == 9:
                    reference = self.readScId()
                    self.read_Vint()
                else:
                    reference = (0, 0)
                    self.read_Vint()
                    self.read_Vint()
            else:
                reward_type = self.read_Vint()
                reference = self.readScId()
                self.read_Vint()
            self.rewards.append((amount, reward_type, reference))

        self.trophy_road = self.read_Vint()
                                                                             
                                                                        
        self.turn_context = [self.read_Vint() for _ in range(5)]

    def process(self):
                                                                           
        return None
