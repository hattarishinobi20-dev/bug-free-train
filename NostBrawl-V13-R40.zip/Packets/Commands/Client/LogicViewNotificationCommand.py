from Logic.NotificationFactory import NotificationFactory
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand


class LogicViewNotificationCommand:
    @staticmethod
    def decode(reader):
        if reader.command_count == 1:
            values = []
            while reader.tell() < len(reader.initial_bytes):
                values.append(reader.read_Vint())
            if len(values) == 2:
                reader.notification_index = values[0]
                return
            if len(values) == 5:
                reader.notification_index = values[4]
                return
            raise ValueError("Payload de visualização de notificação inválido")
        for _ in range(4):
            reader.read_Vint()
        reader.notification_index = reader.read_Vint()

    @staticmethod
    def process(reader):
        try:
            result = NotificationFactory.claim_skin(
                reader.player, reader.notification_index
            )
        except (TypeError, ValueError) as error:
            return str(error)
        LogicSkinDataCommand(
            reader.client, reader.player, result["skin"], v13=True
        ).send()
        return result
