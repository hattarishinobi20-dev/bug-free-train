import copy
import datetime
import json
import os
import sqlite3 as sql
import threading
from contextlib import contextmanager
from pathlib import Path

from Logic.Player import Players
from Utils.Config import Config


class DataBase:
    """SQLite-backed account store plus Nost's existing SQLite club store."""

    MAX_POWER_POINTS = 1410
    TROPHY_ROAD_COMPLETE = 95
    PLAYER_EXPERIENCE = 99999
    EXPERIENCE_MIGRATION_VERSION = 1

    PLAYER_COLUMNS = (
        "id",
        "token",
        "name",
        "leagueReward",
        "lowID",
        "tgid",
        "clubID",
        "clubRole",
        "playerExp",
        "soloWins",
        "duoWins",
        "TvsTWins",
        "gems",
        "gold",
        "tokensdoubler",
        "battleTokens",
        "tickets",
        "brawlerID",
        "skinID",
        "trophies",
        "highest_trophies",
        "profileIcon",
        "namecolor",
        "brawlBoxes",
        "bigBoxes",
        "starpower",
        "DoNotDistrub",
        "roomID",
        "brawlersSkins",
        "brawlersTrophies",
        "brawlersTrophiesForRank",
        "brawlersUpgradePoints",
        "brawlerPowerLevel",
        "brawlerStarPower",
        "UnlockedBrawlers",
        "UnlockedSkins",
        "Friends",
        "online",
        "Notifications",
        "progression",
    )

    JSON_COLUMNS = frozenset({
        "brawlersSkins",
        "brawlersTrophies",
        "brawlersTrophiesForRank",
        "brawlersUpgradePoints",
        "brawlerPowerLevel",
        "brawlerStarPower",
        "UnlockedBrawlers",
        "UnlockedSkins",
        "Friends",
        "Notifications",
        "progression",
    })

    PLAYER_SCHEMA = """
        CREATE TABLE IF NOT EXISTS players (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL DEFAULT 'Guest',
            leagueReward INTEGER NOT NULL DEFAULT 0,
            lowID INTEGER NOT NULL UNIQUE,
            tgid INTEGER NOT NULL DEFAULT 0,
            clubID INTEGER NOT NULL DEFAULT 0,
            clubRole INTEGER NOT NULL DEFAULT 0,
            playerExp INTEGER NOT NULL DEFAULT 99999,
            soloWins INTEGER NOT NULL DEFAULT 0,
            duoWins INTEGER NOT NULL DEFAULT 0,
            TvsTWins INTEGER NOT NULL DEFAULT 0,
            gems INTEGER NOT NULL DEFAULT 0,
            gold INTEGER NOT NULL DEFAULT 0,
            tokensdoubler INTEGER NOT NULL DEFAULT 0,
            battleTokens INTEGER NOT NULL DEFAULT 0,
            tickets INTEGER NOT NULL DEFAULT 0,
            brawlerID INTEGER NOT NULL DEFAULT 0,
            skinID INTEGER NOT NULL DEFAULT 0,
            trophies INTEGER NOT NULL DEFAULT 0,
            highest_trophies INTEGER NOT NULL DEFAULT 0,
            profileIcon INTEGER NOT NULL DEFAULT 0,
            namecolor INTEGER NOT NULL DEFAULT 0,
            brawlBoxes INTEGER NOT NULL DEFAULT 0,
            bigBoxes INTEGER NOT NULL DEFAULT 0,
            starpower INTEGER NOT NULL DEFAULT 0,
            DoNotDistrub INTEGER NOT NULL DEFAULT 0,
            roomID INTEGER NOT NULL DEFAULT 0,
            brawlersSkins TEXT NOT NULL DEFAULT '{}',
            brawlersTrophies TEXT NOT NULL DEFAULT '{}',
            brawlersTrophiesForRank TEXT NOT NULL DEFAULT '{}',
            brawlersUpgradePoints TEXT NOT NULL DEFAULT '{}',
            brawlerPowerLevel TEXT NOT NULL DEFAULT '{}',
            brawlerStarPower TEXT NOT NULL DEFAULT '{}',
            UnlockedBrawlers TEXT NOT NULL DEFAULT '{}',
            UnlockedSkins TEXT NOT NULL DEFAULT '{"Skins":[]}',
            Friends TEXT NOT NULL DEFAULT '{}',
            online INTEGER NOT NULL DEFAULT 0,
            Notifications TEXT NOT NULL DEFAULT '{}',
            progression TEXT NOT NULL DEFAULT '{}'
        )
    """

    CLUB_SCHEMA = """
        CREATE TABLE IF NOT EXISTS clubs (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            region TEXT NOT NULL DEFAULT 'RU',
            badge_id INTEGER NOT NULL DEFAULT 0,
            type INTEGER NOT NULL DEFAULT 1,
            required_trophies INTEGER NOT NULL DEFAULT 0,
            family_friendly INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS club_members (
            club_id INTEGER NOT NULL,
            player_id INTEGER NOT NULL,
            role INTEGER NOT NULL DEFAULT 1,
            joined_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (club_id, player_id),
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE,
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS club_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            club_id INTEGER NOT NULL,
            event INTEGER NOT NULL,
            tick INTEGER NOT NULL DEFAULT 0,
            player_id INTEGER NOT NULL DEFAULT 0,
            player_name TEXT NOT NULL DEFAULT '',
            player_role INTEGER NOT NULL DEFAULT 0,
            message TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS club_notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            club_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            sender_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (club_id) REFERENCES clubs(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS club_members_player
            ON club_members(player_id);
        CREATE INDEX IF NOT EXISTS club_messages_club
            ON club_messages(club_id, id);
        CREATE INDEX IF NOT EXISTS club_notifications_club
            ON club_notifications(club_id, id);
    """

    SOCIAL_SCHEMA = """
        CREATE TABLE IF NOT EXISTS game_rooms (
            id INTEGER PRIMARY KEY,
            room_type INTEGER NOT NULL DEFAULT 0,
            map_id INTEGER NOT NULL DEFAULT 0,
            slot_index INTEGER NOT NULL DEFAULT 0,
            practice INTEGER NOT NULL DEFAULT 0,
            advertise_band INTEGER NOT NULL DEFAULT 0,
            advertise_friends INTEGER NOT NULL DEFAULT 1,
            owner_id INTEGER NOT NULL,
            state INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (owner_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS game_room_members (
            room_id INTEGER NOT NULL,
            low_id INTEGER NOT NULL,
            host INTEGER NOT NULL DEFAULT 0,
            ready INTEGER NOT NULL DEFAULT 0,
            team INTEGER NOT NULL DEFAULT 0,
            status INTEGER NOT NULL DEFAULT 3,
            brawler_id INTEGER NOT NULL DEFAULT 0,
            skin_id INTEGER NOT NULL DEFAULT 0,
            joined_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (room_id, low_id),
            FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (low_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS game_room_members_player
            ON game_room_members(low_id, room_id);
        CREATE TABLE IF NOT EXISTS game_room_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id INTEGER NOT NULL,
            player_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            created_at INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS game_room_messages_room
            ON game_room_messages(room_id, id);
        CREATE TABLE IF NOT EXISTS friend_relations (
            owner_id INTEGER NOT NULL,
            friend_id INTEGER NOT NULL,
            state INTEGER NOT NULL,
            created_at INTEGER NOT NULL DEFAULT 0,
            updated_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (owner_id, friend_id),
            FOREIGN KEY (owner_id) REFERENCES players(lowID) ON DELETE CASCADE,
            FOREIGN KEY (friend_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS friend_relations_friend
            ON friend_relations(friend_id, owner_id);
        CREATE TABLE IF NOT EXISTS game_room_invites (
            room_id INTEGER NOT NULL,
            sender_id INTEGER NOT NULL,
            recipient_id INTEGER NOT NULL,
            invite_type INTEGER NOT NULL DEFAULT 0,
            created_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (room_id, recipient_id),
            FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (sender_id) REFERENCES players(lowID) ON DELETE CASCADE,
            FOREIGN KEY (recipient_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS game_room_join_requests (
            room_id INTEGER NOT NULL,
            player_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (room_id, player_id),
            FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (player_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS game_room_chat_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id INTEGER NOT NULL,
            message_id INTEGER NOT NULL,
            reporter_id INTEGER NOT NULL,
            reported_id INTEGER NOT NULL,
            created_at INTEGER NOT NULL DEFAULT 0,
            UNIQUE(room_id, message_id, reporter_id),
            FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (message_id) REFERENCES game_room_messages(id) ON DELETE CASCADE,
            FOREIGN KEY (reporter_id) REFERENCES players(lowID) ON DELETE CASCADE,
            FOREIGN KEY (reported_id) REFERENCES players(lowID) ON DELETE CASCADE
        );
    """

    _schema_lock = threading.Lock()
    _initialized_paths = set()

    def _database_path():
        database = Config.GetValue().get("Database", {})
        return str(database.get("Path", "Database/players.db"))

    def _connect():
        configured_path = DataBase._database_path()
        if configured_path == ":memory:":
            database_path = configured_path
        else:
            path = Path(configured_path).expanduser().resolve()
            path.parent.mkdir(parents=True, exist_ok=True)
            database_path = str(path)

        connection = sql.connect(database_path, timeout=10)
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")

        if database_path not in DataBase._initialized_paths:
            with DataBase._schema_lock:
                if database_path not in DataBase._initialized_paths:
                    if database_path != ":memory:":
                        connection.execute("PRAGMA journal_mode = WAL")
                    connection.execute("PRAGMA synchronous = NORMAL")
                    connection.executescript(DataBase.PLAYER_SCHEMA)
                    connection.executescript(DataBase.CLUB_SCHEMA)
                    connection.executescript(DataBase.SOCIAL_SCHEMA)
                                                                           
                                                                         
                                                                    
                    columns = {
                        row[1]
                        for row in connection.execute(
                            "PRAGMA table_info(players)"
                        ).fetchall()
                    }
                    if "progression" not in columns:
                        connection.execute(
                            "ALTER TABLE players ADD COLUMN progression "
                            "TEXT NOT NULL DEFAULT '{}'"
                        )
                    schema_version = connection.execute(
                        "PRAGMA user_version"
                    ).fetchone()[0]
                    if schema_version < DataBase.EXPERIENCE_MIGRATION_VERSION:
                        connection.execute(
                            "UPDATE players SET playerExp = ? WHERE playerExp <> ?",
                            (
                                DataBase.PLAYER_EXPERIENCE,
                                DataBase.PLAYER_EXPERIENCE,
                            ),
                        )
                        connection.execute(
                            f"PRAGMA user_version = {DataBase.EXPERIENCE_MIGRATION_VERSION}"
                        )
                    connection.commit()
                    DataBase._initialized_paths.add(database_path)
        return connection

    @contextmanager
    def _connection():
        connection = DataBase._connect()
        try:
            yield connection
        except Exception:
            connection.rollback()
            raise
        else:
            connection.commit()
        finally:
            connection.close()

    def _number(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _json_default(column):
        if column == "UnlockedSkins":
            return {"Skins": []}
        return {}

    def _decode_json(value, column):
        default = DataBase._json_default(column)
        if value is None:
            return copy.deepcopy(default)
        if isinstance(value, (dict, list)):
            return value
        try:
            decoded = json.loads(value)
        except (TypeError, ValueError):
            return copy.deepcopy(default)
        return copy.deepcopy(default) if decoded is None else decoded

    def _serialize_value(column, value):
        if column not in DataBase.JSON_COLUMNS:
            return value
        if value is None:
            value = DataBase._json_default(column)
        elif isinstance(value, str):
                                                                       
            try:
                value = json.loads(value)
            except ValueError:
                pass
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))

    def _apply_row(player, row):
        player.id = row[0]
        player.token = row[1] or ""
        player.name = row[2] or "Guest"

        numeric_fields = (
            ("trophy_road", 3),
            ("low_id", 4),
            ("tgid", 5),
            ("club_low_id", 6),
            ("club_role", 7),
            ("player_experience", 8),
            ("solo_wins", 9),
            ("duo_wins", 10),
            ("ThreeVSThree_wins", 11),
            ("gems", 12),
            ("gold", 13),
            ("tokensdoubler", 14),
            ("battle_tokens", 15),
            ("tickets", 16),
            ("brawler_id", 17),
            ("skin_id", 18),
            ("trophies", 19),
            ("highest_trophies", 20),
            ("profile_icon", 21),
            ("name_color", 22),
            ("brawl_boxes", 23),
            ("big_boxes", 24),
            ("starpower", 25),
            ("do_not_distrub", 26),
            ("room_id", 27),
            ("online", 37),
        )
        for attribute, index in numeric_fields:
            setattr(player, attribute, DataBase._number(row[index]))

        json_fields = (
            ("brawlers_skins", 28, "brawlersSkins"),
            ("brawlers_trophies", 29, "brawlersTrophies"),
            ("brawlers_trophies_in_rank", 30, "brawlersTrophiesForRank"),
            ("brawlers_upgradium", 31, "brawlersUpgradePoints"),
            ("Brawler_level", 32, "brawlerPowerLevel"),
            ("Brawler_starPower", 33, "brawlerStarPower"),
            ("BrawlersUnlockedState", 34, "UnlockedBrawlers"),
            ("UnlockedSkins", 35, "UnlockedSkins"),
            ("Friends", 36, "Friends"),
            ("Notifications", 38, "Notifications"),
            ("progression", 39, "progression"),
        )
        for attribute, index, column in json_fields:
            setattr(player, attribute, DataBase._decode_json(row[index], column))

        progression = getattr(player, "progression", {})
        if not isinstance(progression, dict):
            progression = {}
            player.progression = progression
        player.tokensAnim = DataBase._number(progression.get("keyReward", 0))
        player.trophiesAnim = DataBase._number(
            progression.get("trophyReward", 0)
        )
        player.bigTokensAnim = DataBase._number(
            progression.get("starKeyReward", 0)
        )
        player.star_points = DataBase._number(
            progression.get("starPoints", getattr(player, "star_points", 0))
        )
        player.IsFacebookLinked = int(bool(progression.get("isFBLinked", False)))
        player.FacebookID = str(progression.get("facebookID", "") or "")
        player.FacebookToken = str(progression.get("facebookToken", "") or "")

                                                                            
                                                                        
                                                        
        stored_levels = getattr(player, "Brawler_level", {})
        normalized_levels = copy.deepcopy(Players.Brawler_level)
        if isinstance(stored_levels, dict):
            for key, value in stored_levels.items():
                normalized_levels[str(key)] = max(
                    1, DataBase._number(value, 1)
                )
        player.Brawler_level = normalized_levels

        stored_points = getattr(player, "brawlers_upgradium", {})
        if not isinstance(stored_points, dict):
            stored_points = copy.deepcopy(Players.brawlers_upgradium)
        player.brawlers_upgradium = {
            str(key): min(
                DataBase.MAX_POWER_POINTS,
                max(0, DataBase._number(value)),
            )
            for key, value in stored_points.items()
        }
        player.trophy_road = min(
            DataBase.TROPHY_ROAD_COMPLETE,
            max(1, player.trophy_road),
        )

    def loadAccount(self):
        with DataBase._connection() as connection:
            row = connection.execute(
                "SELECT * FROM players WHERE token = ?", (self.player.token,)
            ).fetchone()
            if row is None:
                return False

            stored_points = DataBase._decode_json(row[31], "brawlersUpgradePoints")
            stored_position = DataBase._number(row[3])
            DataBase._apply_row(self.player, row)
            if stored_points != self.player.brawlers_upgradium:
                connection.execute(
                    "UPDATE players SET brawlersUpgradePoints = ? WHERE token = ?",
                    (
                        DataBase._serialize_value(
                            "brawlersUpgradePoints", self.player.brawlers_upgradium
                        ),
                        self.player.token,
                    ),
                )
            if stored_position != self.player.trophy_road:
                connection.execute(
                    "UPDATE players SET leagueReward = ? WHERE token = ?",
                    (self.player.trophy_road, self.player.token),
                )
            if self.player.trophies >= self.player.highest_trophies:
                self.player.highest_trophies = self.player.trophies
                connection.execute(
                    "UPDATE players SET highest_trophies = ? WHERE token = ?",
                    (self.player.highest_trophies, self.player.token),
                )
            return True

    def createAccount(self):
        player = self.player
        player.BrawlersUnlockedState = Players.CreateNewBrawlersList()
        player.highest_trophies = max(
            getattr(player, "trophies", 0),
            getattr(player, "highest_trophies", 0),
        )

        data = {
            "token": str(player.token),
            "name": str(getattr(player, "name", "Guest")),
            "leagueReward": DataBase._number(getattr(player, "trophy_road", 1)),
            "lowID": DataBase._number(player.low_id),
            "tgid": DataBase._number(getattr(player, "tgid", 0)),
            "clubID": DataBase._number(getattr(player, "club_low_id", 0)),
            "clubRole": DataBase._number(getattr(player, "club_role", 0)),
            "playerExp": DataBase._number(
                getattr(player, "player_experience", DataBase.PLAYER_EXPERIENCE)
            ),
            "soloWins": DataBase._number(getattr(player, "solo_wins", 0)),
            "duoWins": DataBase._number(getattr(player, "duo_wins", 0)),
            "TvsTWins": DataBase._number(getattr(player, "ThreeVSThree_wins", 0)),
            "gems": DataBase._number(getattr(player, "gems", 0)),
            "gold": DataBase._number(getattr(player, "gold", 0)),
            "tokensdoubler": DataBase._number(getattr(player, "tokensdoubler", 0)),
            "battleTokens": DataBase._number(getattr(player, "battle_tokens", 0)),
            "tickets": DataBase._number(getattr(player, "tickets", 0)),
            "brawlerID": DataBase._number(getattr(player, "brawler_id", 0)),
            "skinID": DataBase._number(getattr(player, "skin_id", 0)),
            "trophies": DataBase._number(getattr(player, "trophies", 0)),
            "highest_trophies": DataBase._number(
                max(
                    getattr(player, "trophies", 0),
                    getattr(player, "highest_trophies", 0),
                )
            ),
            "profileIcon": DataBase._number(getattr(player, "profile_icon", 0)),
            "namecolor": DataBase._number(getattr(player, "name_color", 0)),
            "brawlBoxes": DataBase._number(getattr(player, "brawl_boxes", 0)),
            "bigBoxes": DataBase._number(getattr(player, "big_boxes", 0)),
            "starpower": DataBase._number(getattr(player, "starpower", 0)),
            "DoNotDistrub": DataBase._number(getattr(player, "do_not_distrub", 0)),
            "roomID": DataBase._number(getattr(player, "room_id", 0)),
            "brawlersSkins": getattr(player, "brawlers_skins", {}),
            "brawlersTrophies": getattr(player, "brawlers_trophies", {}),
            "brawlersTrophiesForRank": getattr(player, "brawlers_trophies_in_rank", {}),
            "brawlersUpgradePoints": getattr(player, "brawlers_upgradium", {}),
            "brawlerPowerLevel": getattr(player, "Brawler_level", {}),
            "brawlerStarPower": getattr(player, "Brawler_starPower", {}),
            "UnlockedBrawlers": player.BrawlersUnlockedState,
            "UnlockedSkins": getattr(player, "UnlockedSkins", {"Skins": []}),
            "Friends": getattr(player, "Friends", {}),
            "online": DataBase._number(getattr(player, "online", 0)),
            "Notifications": getattr(player, "Notifications", {}),
            "progression": getattr(player, "progression", {}),
        }

        columns = DataBase.PLAYER_COLUMNS[1:]
        quoted_columns = ", ".join(f'"{column}"' for column in columns)
        placeholders = ", ".join("?" for _ in columns)
        values = [DataBase._serialize_value(column, data[column]) for column in columns]

        with DataBase._connection() as connection:
            connection.execute(
                f"INSERT INTO players ({quoted_columns}) VALUES ({placeholders})",
                values,
            )
        return player.low_id

    def _update_value(where_column, where_value, value_name, new_value):
        if value_name not in DataBase.PLAYER_COLUMNS or value_name == "id":
            raise ValueError(f"Unsupported player column: {value_name}")
        if where_column not in {"token", "lowID"}:
            raise ValueError(f"Unsupported lookup column: {where_column}")

        serialized = DataBase._serialize_value(value_name, new_value)
        with DataBase._connection() as connection:
            cursor = connection.execute(
                f'UPDATE players SET "{value_name}" = ? WHERE "{where_column}" = ?',
                (serialized, where_value),
            )
            return cursor.rowcount > 0

    def _update_values(where_column, where_value, values):
        """Update several player columns in one SQLite transaction."""
        if where_column not in {"token", "lowID"}:
            raise ValueError(f"Unsupported lookup column: {where_column}")
        if not values:
            return True
        for column in values:
            if column not in DataBase.PLAYER_COLUMNS or column == "id":
                raise ValueError(f"Unsupported player column: {column}")

        assignments = ", ".join(f'"{column}" = ?' for column in values)
        parameters = [
            DataBase._serialize_value(column, value)
            for column, value in values.items()
        ]
        parameters.append(where_value)
        with DataBase._connection() as connection:
            cursor = connection.execute(
                f'UPDATE players SET {assignments} '
                f'WHERE "{where_column}" = ?',
                parameters,
            )
            return cursor.rowcount > 0

    def replaceValue(self, value_name, new_value):
        aliases = {
            "availableTokens": "battleTokens",
            "tokens": "battleTokens",
        }
        value_name = aliases.get(value_name, value_name)
        progression_fields = {
            "starpoints": "starPoints",
            "starPoints": "starPoints",
            "tokensAnim": "keyReward",
            "trophiesAnim": "trophyReward",
            "bigTokensAnim": "starKeyReward",
        }
        if value_name in progression_fields:
            progression = copy.deepcopy(getattr(self.player, "progression", {}))
            if not isinstance(progression, dict):
                progression = {}
            progression[progression_fields[value_name]] = DataBase._number(new_value)
            updated = DataBase._update_value(
                "token", self.player.token, "progression", progression
            )
            if updated:
                self.player.progression = progression
                attribute = progression_fields[value_name]
                if attribute == "starPoints":
                    self.player.star_points = DataBase._number(new_value)
                else:
                    animation_names = {
                        "keyReward": "tokensAnim",
                        "trophyReward": "trophiesAnim",
                        "starKeyReward": "bigTokensAnim",
                    }
                    setattr(
                        self.player, animation_names[attribute],
                        DataBase._number(new_value),
                    )
            return updated
        return DataBase._update_value(
            "token", self.player.token, value_name, new_value
        )

    def replaceValues(self, values):
        return DataBase._update_values("token", self.player.token, values)

    def replaceOtherValue(self, low_id, value_name, new_value):
        return DataBase._update_value("lowID", low_id, value_name, new_value)

    def DeleteTrash(self):
        with DataBase._connection() as connection:
            count = connection.execute(
                "SELECT COUNT(*) FROM players WHERE name = ?", ("Guest",)
            ).fetchone()[0]
            if count >= 15:
                connection.execute("DELETE FROM players WHERE name = ?", ("Guest",))

    def fixAccount(self):
        for column, value in (
            ("trophies", 0),
            ("highest_trophies", 0),
            ("clubID", 0),
            ("gold", 100),
            ("gems", 0),
            ("tickets", 5),
            ("bigBoxes", 0),
            ("brawlBoxes", 0),
            ("tokensdoubler", 0),
            ("tgid", 0),
            ("playerExp", 0),
        ):
            DataBase.replaceValue(self, column, value)

        self.player.brawlers_trophies[str(self.player.brawler_id)] = 0
        self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] = 0
        DataBase.replaceValue(
            self, "brawlersTrophies", self.player.brawlers_trophies
        )
        DataBase.replaceValue(
            self,
            "brawlersTrophiesForRank",
            self.player.brawlers_trophies_in_rank,
        )

    def checkID(self, new_id):
        with DataBase._connection() as connection:
            row = connection.execute(
                "SELECT 1 FROM players WHERE lowID = ?", (new_id,)
            ).fetchone()
            return 0 if row else 1

    def sendNotifData(self, lowID, ID, text, type):
        row = DataBase.loadMembersById(self, lowID)
        if row is None:
            return False
        notifications = DataBase._decode_json(row[38], "Notifications")
        notifications[str(len(notifications))] = {
            "ID": ID,
            "Index": 3,
            "Read": False,
            "Time": datetime.datetime.timestamp(datetime.datetime.now()),
            "Text": text,
        }
        if ID == 81:
            notifications[str(len(notifications) - 1)]["Type"] = type
        return DataBase.replaceOtherValue(lowID, "Notifications", notifications)

    def loadOldAccount(self, nost_id):
        with DataBase._connection() as connection:
            cursor = connection.execute(
                "UPDATE players SET token = ? WHERE tgid = ?",
                (self.player.token, nost_id),
            )
            return cursor.rowcount > 0

    def resetOnlineStatus():
        with DataBase._connection() as connection:
            connection.execute("UPDATE players SET online = 0, roomID = 0")

    def getLeaders(self):
        with DataBase._connection() as connection:
            return connection.execute(
                "SELECT lowID, name, trophies, profileIcon, namecolor, clubID, playerExp "
                "FROM players ORDER BY trophies DESC, lowID ASC LIMIT 100"
            ).fetchall()

    def loadById(self, ID):
        with DataBase._connection() as connection:
            return connection.execute(
                "SELECT * FROM players WHERE lowID = ?", (ID,)
            ).fetchall()

    def loadMembersById(self, ID):
        with DataBase._connection() as connection:
            return connection.execute(
                "SELECT * FROM players WHERE lowID = ?", (ID,)
            ).fetchone()

          
    def createClub(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.con = sql.connect(f"Database/Chats/{clubid}.db")
        self.cur = self.conn.cursor()
        self.c = self.con.cursor()
        self.cur.execute(f"CREATE TABLE IF NOT EXISTS clubs (clubID INT, name TEXT, description TEXT, region TEXT, badgeID INT, type INT, trophiesneeded INT, trophies INT, members JSON, notif JSON)")
        self.c.execute(f"CREATE TABLE IF NOT EXISTS chats (Event INT, Tick INT, plrid INT, plrname TEXT, plrrole INT, Msg TEXT)")
        self.con.commit()
        self.conn.commit()
        data = {"members": {self.player.low_id:self.player.name}}
        notif = {}
        var = clubid,str(self.clubName),str(self.clubdescription),"RU",self.clubbadgeID,self.clubtype,self.clubtrophiesneeded,self.player.trophies,json.dumps(data),json.dumps(notif)
        self.cur.execute(f"INSERT INTO clubs VALUES (?,?,?,?,?,?,?,?,?,?)", var)
        self.conn.commit()
        msgData = {
            "clubID": clubid,
            "info": {
                "Total": 1,
                "1": {
                    "Event": 2,
                    "Tick": 1,
                    "PlayerID": self.player.low_id,
                    "PlayerName": self.player.name,
                    "PlayerRole": 2,
                    "Message": "Welcome to your new club!"
                }
            }
        }
        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?)"
        var = 2, 1, self.player.low_id, str(self.player.name), 2, "Club Created!"
        self.c.execute(sss, var)
        self.con.commit()
        if str(self.clubName) == "лох":
            self.c.execute("DELETE FROM chats")
            self.cur.execute(f"DELETE FROM clubs WHERE clubID={clubid}")
            self.con.commit()
            self.conn.commit()
        else:
            pass

    def setNotifData(self, text, by):
    	self.conn = sql.connect("Database/clubs.db")
    	self.cur = self.conn.cursor()
    	self.cur.execute("SELECT * FROM clubs WHERE clubID=?", (self.player.club_low_id,))
    	fetch = self.cur.fetchall()
    	if fetch:
    	   	notifData = json.loads(fetch[0][9])
    	   	l = str(len(notifData))
    	   	notifData[l]={}
    	   	notifData[l]["text"]=text
    	   	notifData[l]["by"]=by
    	   	notifData[l]["timer"]=datetime.datetime.timestamp(datetime.datetime.now())
    	   	self.cur.execute("UPDATE clubs SET notif=? WHERE clubID=?", (json.dumps(notifData),self.player.club_low_id))
    	   	self.conn.commit()
    	   	self.conn.close()

    def CountClub(self):
        self.AllianceCount = 0
        self.club_list = []
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()
        try:
                		self.cur.execute(f"SELECT * FROM clubs")
                		fetch = self.cur.fetchall()
                		if len(fetch)>0:
                			for i in fetch:
                				self.club_list.append(int(i[0]))
                				self.AllianceCount+=1
                		self.conn.close()
        except:
            pass

    def loadClub(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()
        
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={clubid}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        		for i in fetch:
        			self.clubmembercount = 0
        			self.plrids = []
        			self.clubName = i[1]
        			self.clubdescription = i[2]
        			self.clubregion = i[3]
           
        			self.clubbadgeID = i[4]
        			self.clubtype = i[5]
        			self.clubtrophiesneeded = i[6]
        			try:
        				self.notifData = json.loads(i[9])
        			except:
        				self.cur.execute("ALTER TABLE clubs ADD COLUMN notif JSON")
        				self.conn.commit()
        			self.clubtrophies = 0
        			data = json.loads(i[8])
        			for ID in data["members"]:
        			     	if ID != "members":
        			     		self.plrids.append(int(ID))
        			     		self.clubmembercount += 1
        			     		DataBase.GetMemberData(self, int(ID))
        			     		self.clubtrophies += self.plrtrophies
                                                                                                    
                                                                                                    
        			self.conn.commit()
        			self.conn.close()

    def loadClubName(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()

        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={clubid}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        		for i in fetch:
        			self.clubName = i[1]
        		self.conn.commit()
        		self.conn.close()

    def AddMember(self, AllianceID, PlayerID, PlayerName, Action):
        self.conn = sql.connect("Database/clubs.db")
        self.con = sql.connect(f"Database/Chats/{AllianceID}.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={AllianceID}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        	data = json.loads(fetch[0][8])
        	if Action == 0:
        		self.chat.execute(f"DELETE FROM chats")
        		self.cur.execute(f"DELETE FROM clubs WHERE clubID={AllianceID}")
        		self.con.commit()
        		self.conn.commit()
        		os.remove(f"Database/Chats/{AllianceID}.db")
        	elif Action == 1:
        	   data["members"][str(PlayerID)] = PlayerName
        	   self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?",(json.dumps(data),AllianceID))
        	   ol = fetch[0][7]
        	   self.cur.execute(f"UPDATE clubs SET trophies={ol+self.player.trophies} WHERE clubID={AllianceID}")
        	   self.conn.commit()
        	elif Action == 2:
        	       data['members'].pop(str(PlayerID))
        	       self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?", (json.dumps(data), AllianceID))
        	       ol = fetch[0][7]
        	       self.cur.execute(f"UPDATE clubs SET trophies={ol-self.player.trophies} WHERE clubID={AllianceID}")
        	       self.conn.commit()
        	self.con.close()
        	self.conn.close()

    def GetMemberData(self, Low_id):
        try:
            self.players = DataBase.loadMembersById(self, Low_id)
            if self.players[4] == int(Low_id):
                    self.lowplrid = self.players[4]
                    self.plrrole = self.players[7]
                    self.plrtrophies = self.players[19]
                    self.plrname = self.players[2]
                    self.plricon = self.players[21]
                    self.plrnamecolor = self.players[22]
                    self.plrexperience = self.players[8]
                    self.plrstatus = self.players[37]

        except Exception as e:
            self.lowplrid = 1
            self.plrrole = 1
            self.plrtrophies = 0
            self.plrname = "Falied to load account!"
            self.plricon = 0
            self.plrnamecolor = 0
            self.plrexperience = 999
            self.plrstatus = 0

    def replaceClubValue(self, target, inf1, inf2, inf3, inf4):
        self.conn = sql.connect("Database/clubs.db")
        self.cur= self.conn.cursor()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={self.player.club_low_id}")
        if 1==1:
         
        	self.cur.execute(f"UPDATE clubs SET description='{inf1}' WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET badgeID={inf2} WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET type={inf3} WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET trophiesneeded={inf4} WHERE clubID={self.player.club_low_id}")
         
        	self.conn.commit()
        	self.conn.close()

    def GetmsgCount(self, clubID):
        self.con = sql.connect(f"Database/Chats/{clubID}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        if len(fetch)>0:
        	self.MessageCount = len(fetch)
        else:
        	self.MessageCount = 1
        self.con.close()

    def Addmsg(self, clubID, event, tick, Low_id, name, role, msg):
        clubid = self.player.club_low_id
        self.con = sql.connect(f"Database/Chats/{clubid}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?)"
        var = event, len(fetch)+1, Low_id, name, role, msg
        self.chat.execute(sss, var)
        self.con.commit()
        self.con.close()

    def DeleteAllMsg(self, clubID):
        self.con = sql.connect(f"Database/Chats/{clubID}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        if len(fetch)>=400:
        	self.chat.execute(f"DELETE FROM chats")
        	self.con.commit()