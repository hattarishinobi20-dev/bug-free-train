import copy
import random
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic import TrophyRoad
from Logic.BattleResultAdapter import apply_battle_result_rewards
from Logic.BoxInventory import BoxInventory
from Logic.BoxService import open_boxes
from Logic.EventRotation import EventRotation
from Logic.Player import Players
from Logic.Rewards import RewardError, RewardTransaction
from Logic.ShopService import ShopService
from Packets.Commands.Client.LogicBuySkinCommand import LogicBuySkinCommand
from Packets.Commands.Client.LogicChangeResourcesEchoCommand import LogicChangeResourcesEchoCommand
from Packets.Commands.Client.LogicClaimRankUpRewardCommand import LogicClaimRankUpRewardCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicBuyItem import LogicBuyItem
from Packets.Commands.Server.LogicChangeResourcesCommand import LogicChangeResourcesCommand
from Utils.Reader import BSMessageReader

NOW = 1700000000


def packet_parts(packet):
    return int.from_bytes(packet[:2], "big"), packet[7:]


def read_vints(payload):
    reader = BSMessageReader(payload)
    result = []
    while reader.tell() < len(payload):
        result.append(reader.read_Vint())
    return result


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))


class RewardDeliveryTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        time_patch = patch("Logic.ShopService.time.time", return_value=NOW)
        time_patch.start()
        self.addCleanup(time_patch.stop)
        self.player = self.make_account()

    def make_account(self, low_id=1):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = f"reward-delivery-{low_id}"
        player.name = "Reward Delivery"
        DataBase.createAccount(SimpleNamespace(player=player))
        DataBase.replaceValues(SimpleNamespace(player=player), {
            "brawlBoxes": 0,
            "bigBoxes": 0,
            "UnlockedBrawlers": {"0": 1},
            "brawlersUpgradePoints": {"0": 0},
            "brawlerPowerLevel": {"0": 1},
            "brawlerStarPower": {"0": 0},
        })
        player.brawl_boxes = 0
        player.big_boxes = 0
        player.BrawlersUnlockedState = {"0": 1}
        player.brawlers_upgradium = {"0": 0}
        player.Brawler_level = {"0": 1}
        player.Brawler_starPower = {"0": 0}
        return player

    def reload(self, player=None):
        source = player or self.player
        loaded = Players(SimpleNamespace())
        loaded.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded

    def update(self, values, player=None):
        player = player or self.player
        self.assertTrue(DataBase.replaceValues(SimpleNamespace(player=player), values))
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))

    def offer(self, key, items, price=0):
        return {
            "key": key,
            "items": items,
            "currency": 0,
            "price": price,
            "originalPrice": price,
            "display": 0,
            "expiresAt": NOW + 3600,
            "seen": False,
            "purchased": False,
            "title": "",
            "daily": True,
        }

    def install(self, offers):
        state = ShopService.get_state(self.player, NOW)
        state["offers"] = copy.deepcopy(offers)
        ShopService._save_state(self.player, state)

    def purchase(self, index=0):
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = index
        command.target_reference = (0, -1)
        result = command.process()
        self.assertIsInstance(result, dict)
        return result, client.packets

    def test_daily_shop_contains_only_free_box_and_power_points(self):
        state = ShopService.get_state(self.player, NOW)
        self.assertEqual([offer["key"] for offer in state["offers"]], [
            "free_box", "power_points",
        ])
        self.assertEqual([offer["items"][0]["offerId"] for offer in state["offers"]], [0, 8])
        old = copy.deepcopy(state)
        old["offers"].extend([
            self.offer("coins", [{"offerId": 1, "amount": 150, "value": 0, "target": None}], 20),
            self.offer("mega_box", [{"offerId": 10, "amount": 1, "value": 0, "target": None}], 80),
            self.offer("resource_bundle", [{"offerId": 9, "amount": 500, "value": 0, "target": None}], 99),
        ])
        old["offers"][0]["purchased"] = True
        old["billing"]["transactions"]["receipt"] = {"product": "pack"}
        ShopService._save_state(self.player, old)
        migrated = ShopService.get_state(self.reload(), NOW)
        self.assertEqual([offer["key"] for offer in migrated["offers"]], [
            "free_box", "power_points",
        ])
        self.assertTrue(migrated["offers"][0]["purchased"])
        self.assertIn("receipt", migrated["billing"]["transactions"])

    def test_resource_command_has_native_payload(self):
        command = LogicChangeResourcesCommand(None, self.player, 5000001, 300)
        command.encode()
        self.assertEqual(read_vints(command.buffer), [
            207, 5000001, 300, 0, 0, 0, 0, 0,
        ])
        reader = BSMessageReader(command.buffer)
        self.assertEqual(reader.read_Vint(), 207)
        echo = LogicChangeResourcesEchoCommand(None, self.player, reader.read())
        with patch.object(
            DataBase, "replaceValues",
            side_effect=AssertionError("207 echo alterou o banco"),
        ):
            echo.decode()
            self.assertIsNone(echo.process())
        self.assertEqual(echo.resource_global_id, 5000001)
        self.assertEqual(echo.resource_amount, 300)
        self.assertEqual(echo.response_tail, [0, 0, 0, 0, 0])
        self.assertEqual(echo.read(), b"")

    def test_brawl_and_big_purchases_store_resources_without_opening(self):
        cases = (
            (0, 1, 3, 5000001, 300, "brawl_boxes", 300, 10),
            (14, 0, 2, 5000009, 20, "big_boxes", 20, 12),
        )
        for index, (offer_id, value, amount, resource, delta, attribute, balance, box_type) in enumerate(cases):
            with self.subTest(offer_id=offer_id):
                self.player = self.make_account(20 + index)
                column = {
                    "brawl_boxes": "brawlBoxes", "big_boxes": "bigBoxes",
                }[attribute]
                self.update({column: 0, "gold": 0})
                self.install([self.offer("box", [{
                    "offerId": offer_id, "amount": amount, "value": value, "target": None,
                }])])
                with patch("Logic.BoxService.generate_rewards") as generate:
                    result, packets = self.purchase()
                generate.assert_not_called()
                self.assertEqual(len(packets), 1)
                packet_id, payload = packet_parts(packets[0])
                self.assertEqual(packet_id, 24111)
                self.assertEqual(read_vints(payload), [207, resource, delta, 0, 0, 0, 0, 0])
                self.assertEqual(getattr(self.player, attribute), balance)
                self.assertEqual(self.player.gold, 0)
                self.assertEqual(BoxInventory.count(self.player, box_type), amount)
                self.assertEqual(result["storedBoxes"], [{"boxType": box_type, "amount": amount}])
                loaded = self.reload()
                self.assertEqual(getattr(loaded, attribute), balance)
                self.assertEqual(loaded.gold, 0)
                self.assertEqual(BoxInventory.count(loaded, box_type), amount)

    def test_mega_purchase_is_stored_and_explicit_claim_opens_it(self):
        self.update({"gold": 0})
        self.install([self.offer("mega", [{
            "offerId": 10, "amount": 2, "value": 0, "target": None,
        }])])
        with patch("Logic.BoxService.generate_rewards") as generate:
            result, packets = self.purchase()
        generate.assert_not_called()
        self.assertEqual(packets, [])
        self.assertEqual(BoxInventory.count(self.player, 11), 2)
        state = ShopService.get_state(self.reload(), NOW)
        self.assertEqual(len(state["offers"]), 2)
        stored_index = next(
            index for index, offer in enumerate(state["offers"])
            if offer.get("storedBox") == 11
        )
        self.player = self.reload()
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[{"name": "Coins", "amount": 75, "target": 0}],
        ) as generate:
            opened, packets = self.purchase(stored_index)
        generate.assert_called_once()
        self.assertEqual(len(packets), 1)
        _, payload = packet_parts(packets[0])
        values = read_vints(payload)
        self.assertEqual(values[:5], [203, 11, 1, 0, 1])
        self.assertEqual(values[5:10], [75, 0, 7, 0, 0])
        self.assertEqual(BoxInventory.count(self.player, 11), 1)
        self.assertEqual(opened["openingSource"], "storedOffer")
        self.assertEqual(self.reload().gold, 75)

    def test_every_box_type_generates_and_persists_nonempty_rewards(self):
        cases = ((5, "brawlBoxes", 1000, 10), (4, "bigBoxes", 100, 12), (3, "gems", 1000, 11))
        for index, (box_id, column, balance, box_type) in enumerate(cases):
            for seed in (1, 2, 3, 4, 5):
                with self.subTest(box_id=box_id, seed=seed):
                    self.player = self.make_account(100 + index * 10 + seed)
                    values = {column: balance}
                    if column != "gold":
                        values["gold"] = 0
                    self.update(values)
                    result = open_boxes(self.player, box_id, rng=random.Random(seed))
                    self.assertTrue(result["rewards"])
                    self.assertEqual(len(result["rewards"]), len(result["rewardNames"]))
                    self.assertEqual(len(result["rewards"]), len(result["rewardsTargetBrawler"]))
                    self.assertTrue(all(amount > 0 for amount in result["rewards"]))
                    command = LogicBoxDataCommand(None, self.player, result)
                    command.encode()
                    values = read_vints(command.buffer)
                    self.assertEqual(values[:3], [203, box_type, 1])
                    self.assertEqual(values[4], len(result["rewards"]))
                    loaded = self.reload()
                    self.assertEqual(loaded.gold, self.player.gold)
                    self.assertEqual(loaded.gems, self.player.gems)
                    self.assertEqual(loaded.brawl_boxes, self.player.brawl_boxes)
                    self.assertEqual(loaded.big_boxes, self.player.big_boxes)
                    self.assertEqual(loaded.brawlers_upgradium, self.player.brawlers_upgradium)
                    self.assertEqual(loaded.BrawlersUnlockedState, self.player.BrawlersUnlockedState)

    def test_partial_inventory_fallback_is_atomic(self):
        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 11, 1)
        transaction.commit()
        self.update({"gems": 80, "gold": 0})
        generated = [{"name": "Coins", "amount": 10, "target": 0}]
        with patch("Logic.BoxService.generate_rewards", return_value=generated):
            result = open_boxes(self.player, 3, count=2)
        self.assertEqual(result["openingSource"], "mixed")
        self.assertEqual((self.player.gems, BoxInventory.count(self.player, 11)), (0, 0))
        loaded = self.reload()
        self.assertEqual((loaded.gems, BoxInventory.count(loaded, 11)), (0, 0))

        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 11, 1)
        transaction.commit()
        self.update({"gems": 79})
        with self.assertRaises(RewardError):
            open_boxes(self.player, 3, count=2)
        self.assertEqual((self.player.gems, BoxInventory.count(self.player, 11)), (79, 1))
        loaded = self.reload()
        self.assertEqual((loaded.gems, BoxInventory.count(loaded, 11)), (79, 1))

        self.update({"gold": 150, "brawlBoxes": 150})
        with self.assertRaisesRegex(RewardError, "Saldo insuficiente"):
            open_boxes(self.player, 5, count=2)
        self.assertEqual((self.player.gold, self.player.brawl_boxes), (150, 150))
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.brawl_boxes), (150, 150))

    def test_multiple_box_grants_accumulate_pending_balances(self):
        self.update({"gold": 77, "brawlBoxes": 0, "bigBoxes": 0})
        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 10, 1)
        BoxInventory.add(transaction, 10, 2)
        BoxInventory.add(transaction, 12, 1)
        BoxInventory.add(transaction, 12, 3)
        transaction.commit()
        self.assertEqual(
            (self.player.gold, self.player.brawl_boxes, self.player.big_boxes),
            (77, 300, 40),
        )
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.brawl_boxes, loaded.big_boxes), (77, 300, 40))
        self.assertEqual(BoxInventory.count(loaded, 10), 3)
        self.assertEqual(BoxInventory.count(loaded, 12), 4)

    def test_legacy_balances_and_pending_boxes_migrate_exactly_once(self):
        self.update({"gold": 7, "brawlBoxes": 50, "bigBoxes": 3})
        transaction = RewardTransaction(self.player)
        transaction.set_progression_value("boxInventory", {
            "version": 1,
            "boxes": {"10": 2, "11": 1, "12": 3},
        })
        transaction.commit()
        before = BoxInventory.counts(self.player)
        self.assertTrue(BoxInventory.migrate(self.player))
        self.assertEqual((self.player.gold, self.player.brawl_boxes, self.player.big_boxes), (7, 250, 33))
        self.assertEqual(BoxInventory.counts(self.player), before)
        self.assertEqual(self.player.progression["boxInventory"]["boxes"], {
            "10": 0, "11": 1, "12": 0,
        })
        self.assertFalse(BoxInventory.migrate(self.reload()))
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.brawl_boxes, loaded.big_boxes), (7, 250, 33))

    def test_battle_and_event_tokens_use_the_opening_balance(self):
        self.update({"gold": 0, "brawlBoxes": 0, "battleTokens": 200, "tokensdoubler": 0})
        self.player.battle_result = 0
        self.player.result = 16
        apply_battle_result_rewards(self.player, 0)
        self.assertGreater(self.player.brawl_boxes, 0)
        self.assertEqual(self.player.gold, 0)
        event = EventRotation.claim(self.player, 3)
        self.assertTrue(event["claimed"])
        self.assertEqual(self.player.brawl_boxes, event["balance"])
        self.assertEqual(self.player.gold, 0)
        loaded = self.reload()
        self.assertEqual(loaded.brawl_boxes, self.player.brawl_boxes)
        self.assertEqual(loaded.gold, 0)

    def test_trophy_road_uses_box_animation_only_for_boxes(self):
        self.assertEqual(len(TrophyRoad.REWARDS), 94)
        for position in (1, 2, 7, 8, 9, 16, 24, 94):
            with self.subTest(position=position):
                self.player = self.make_account(200 + position)
                self.update({"leagueReward": position, "gold": 0, "bigBoxes": 100})
                client = CaptureClient()
                command = LogicClaimRankUpRewardCommand(client, self.player, b"")
                command.brawlerID = 0
                result = command.process()
                self.assertIsInstance(result, dict)
                if result["rewardType"] == "event":
                    self.assertEqual(client.packets, [])
                    continue
                self.assertEqual(len(client.packets), 1)
                _, payload = packet_parts(client.packets[0])
                values = read_vints(payload)
                if result["rewardType"] == "box":
                    self.assertEqual(values[0:3], [203, result["boxType"], 1])
                    self.assertGreater(values[4], 0)
                else:
                    self.assertEqual(values[:5], [203, 0, 1, 100, 1])
                    displayed_amount = (
                        1 if result["rewardNames"][0] in {"Brawler", "Skin", "StarPower"}
                        else result["rewards"][0]
                    )
                    self.assertEqual(values[5], displayed_amount)

    def test_trophy_power_points_reject_truncation_before_commit(self):
        self.update({
            "leagueReward": 9,
            "brawlersUpgradePoints": {"0": 1400},
            "UnlockedBrawlers": {"0": 1},
        })
        client = CaptureClient()
        command = LogicClaimRankUpRewardCommand(client, self.player, b"")
        command.brawlerID = 0
        result = command.process()
        self.assertIsInstance(result, str)
        self.assertIn("capacidade", result)
        self.assertEqual(client.packets, [])
        loaded = self.reload()
        self.assertEqual(loaded.trophy_road, 9)
        self.assertEqual(loaded.brawlers_upgradium["0"], 1400)

    def test_skin_and_default_brawler_purchase_use_item_animation(self):
        normal = 29
        self.update({"gems": 1000, "UnlockedSkins": {"Skins": []}, "UnlockedBrawlers": {"0": 1, "1": 0}})
        client = CaptureClient()
        command = LogicBuySkinCommand(client, self.player, b"")
        command.skin_id = normal
        command.brawler_id = Skins.getBrawler(normal)
        result = command.process()
        self.assertIsInstance(result, dict)
        self.assertEqual(len(client.packets), 1)
        _, payload = packet_parts(client.packets[0])
        values = read_vints(payload)
        self.assertEqual(values[:5], [203, 0, 1, 100, 1])
        self.assertEqual(values[5:11], [1, 0, 9, 29, normal, 0])
        default_skin = next(
            skin for skin in Skins.get_skins_id()
            if Skins.getBrawler(skin) == 1 and Skins.getIsDefaultSkin(skin)
        )
        client = CaptureClient()
        command = LogicBuySkinCommand(client, self.player, b"")
        command.skin_id = default_skin
        command.brawler_id = 1
        result = command.process()
        self.assertIsInstance(result, dict)
        _, payload = packet_parts(client.packets[0])
        values = read_vints(payload)
        self.assertEqual(values[:5], [203, 0, 1, 100, 1])
        self.assertEqual(values[5:11], [1, 16, 1, 1, 0, 0])
        self.assertEqual(self.reload().BrawlersUnlockedState["1"], 1)


if __name__ == "__main__":
    unittest.main()
