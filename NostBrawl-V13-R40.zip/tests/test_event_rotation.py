import os
import sys
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.EventRotation import EventError, EventRotation
from Logic.Player import Players
from Packets.Commands.Client.LogicNewEventCommand import LogicNewEventCommand


class EventRotationTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.now = datetime(2026, 10, 26, 12, 0, 0)

    def make_account(self, low_id):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = "event-token-%d" % low_id
        player.name = "Event %d" % low_id
        DataBase.createAccount(SimpleNamespace(player=player))
        DataBase.replaceValues(SimpleNamespace(player=player), {"brawlBoxes": 0})
        player.brawl_boxes = 0
        return player

    def reload(self, source):
        player = Players(SimpleNamespace())
        player.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
        return player

    def test_five_slots_use_only_enabled_csv_maps_in_canonical_order(self):
        events = EventRotation.events(self.now)
        self.assertEqual(len(events), 5)
        self.assertEqual(
            [event["game_mode"] for event in events],
            ["CoinRush", "BattleRoyale", "BountyHunter", "LaserBall", "BattleRoyaleTeam"],
        )
        locations = EventRotation.locations()
        self.assertEqual(len(locations), 69)
        for event in events:
            location = locations[event["map_id"]]
            self.assertTrue(location["enabled"])
            self.assertEqual(location["game_mode"], event["game_mode"])

    def test_rotation_is_deterministic_and_changes_with_the_date(self):
        first = EventRotation.events(self.now)
        self.assertEqual(first, EventRotation.events(self.now))
        following = EventRotation.events(datetime(2026, 10, 27, 12, 0, 0))
        self.assertNotEqual(
            [event["map_id"] for event in first],
            [event["map_id"] for event in following],
        )
        self.assertEqual(first, EventRotation.events(self.now))

    def test_timer_uses_the_next_local_midnight(self):
        self.assertEqual(EventRotation.seconds_to_next_day(self.now), 43200)
        self.assertEqual(
            EventRotation.seconds_to_next_day(datetime(2026, 10, 26, 23, 59, 59)),
            1,
        )

    def test_claim_is_persistent_per_account_and_date_and_replay_is_free(self):
        player = self.make_account(1)
        other = self.make_account(2)
        command = LogicNewEventCommand(None, player, b"")
        command.event_index = 3
        with patch("Logic.EventRotation.datetime") as clock:
            clock.now.return_value = self.now
            clock.strptime.side_effect = datetime.strptime
            result = command.process()
            replay = command.process()
        self.assertTrue(result["claimed"])
        self.assertEqual(player.brawl_boxes, 10)
        self.assertFalse(replay["claimed"])
        self.assertEqual(player.brawl_boxes, 10)

        restored = self.reload(player)
        self.assertEqual(restored.brawl_boxes, 10)
        self.assertIn(3, EventRotation.claimed_slots(restored, self.now))
        self.assertTrue(EventRotation.snapshot(restored, self.now)[2]["claimed"])
        self.assertFalse(EventRotation.snapshot(other, self.now)[2]["claimed"])

        other_command = LogicNewEventCommand(None, other, b"")
        other_command.event_index = 3
        with patch("Logic.EventRotation.datetime") as clock:
            clock.now.return_value = self.now
            clock.strptime.side_effect = datetime.strptime
            self.assertTrue(other_command.process()["claimed"])
        self.assertEqual(other.brawl_boxes, 10)
        self.assertEqual(self.reload(player).brawl_boxes, 10)

        next_day = LogicNewEventCommand(None, restored, b"")
        next_day.event_index = 3
        with patch("Logic.EventRotation.datetime") as clock:
            clock.now.return_value = datetime(2026, 10, 27, 12, 0, 0)
            clock.combine.side_effect = datetime.combine
            clock.strptime.side_effect = datetime.strptime
            self.assertTrue(next_day.process()["claimed"])
        self.assertEqual(self.reload(player).brawl_boxes, 20)

    def test_concurrent_replays_grant_only_once(self):
        player = self.make_account(7)
        players = []
        for index in range(8):
            clone = self.reload(player)
            players.append(clone)
        def claim(clone):
            return EventRotation.claim(clone, 4, self.now)
        with ThreadPoolExecutor(max_workers=8) as executor:
            results = list(executor.map(claim, players))
        self.assertEqual(sum(bool(result["claimed"]) for result in results), 1)
        self.assertEqual(self.reload(player).brawl_boxes, 10)

    def test_invalid_slot_does_not_change_the_account(self):
        player = self.make_account(9)
        for slot in (-1, 6, 999, "bad"):
            with self.assertRaises(EventError):
                EventRotation.claim(player, slot, self.now)
        self.assertEqual(self.reload(player).brawl_boxes, 0)


if __name__ == "__main__":
    unittest.main()
