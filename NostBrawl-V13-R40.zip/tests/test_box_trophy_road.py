import copy
import json
import random
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Skins import Skins
from Logic import TrophyRoad
from Logic.BattleResultAdapter import apply_battle_result_rewards
from Logic.Boxes import Boxes
from Logic.BoxInventory import BoxInventory
from Logic.BoxService import generate_rewards, open_boxes
from Logic.Player import Players
from Logic.Rewards import RewardError, RewardTransaction
from Logic.SkinPurchase import (
    SkinPurchase, V18_GOLD_REQUIREMENTS, V18_PRICE_GROUPS, V18_SKIN_PRICES,
)
from Packets.Commands.Client.LogicChangeAvatarNameCommand import LogicChangeAvatarNameCommand
from Packets.Commands.Client.LogicPurchaseBoxCommand import LogicPurchaseBoxCommand
from Packets.Commands.Client.LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from Packets.Commands.Client.LogicPurchaseHeroLvlUpMaterialCommand import LogicPurchaseHeroLvlUpMaterialCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Client.LogicRemoveNewTagBrawler import LogicRemoveNewTagBrawler
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand
from Packets.Commands.Client.LogicSelectBrawlerCommand import LogicSelectBrawlerCommand
from Packets.Commands.Client.LogicBoxDataEchoCommand import LogicBoxDataEchoCommand
from Packets.Commands.Client.LogicBuySkinCommand import LogicBuySkinCommand
from Packets.Commands.Client.LogicUnlockSkinCommand import LogicUnlockSkinCommand
from Packets.Commands.Client.LogicUpgradeBrawler import Upgrade_Brawler
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicBuyItem import LogicBuyItem
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand
from Packets.Commands.Server.LogicUnlockSkinServerCommand import LogicUnlockSkinServerCommand
from Packets.LogicCommandManager import COMMAND_HANDLERS, EndClientTurn
from Packets.Messages.Server.Battle.BattleResultMessage import BattleResultMessage
from Packets.Messages.Server.Battle.BattleResultShowdownMessage import BattleResultShowdownMessage
from Packets.Messages.Server.Battle.BattleResultDuoShowdownMessage import BattleResultDuoShowdownMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Config import Config
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


LOGGED_NAME_201 = bytes.fromhex(
    "00820100018903000000036b6174001d810181017f7fffffffff"
)
LOGGED_BOX_500 = bytes.fromhex("00a8010001b407a701a7017f7f05ffffffff")
LOGGED_NEW_TAG_522 = bytes.fromhex(
    "00910100018a08900190017f7f100000000002ffffffff"
)
LOGGED_SKIN_507 = bytes.fromhex("0093020001bb07920292027f7f1d1dffffffff")
LOGGED_SELECT_SKIN_AND_BRAWLER = bytes.fromhex(
    "00970f0002ba07960f960f7f7f1d008d08960f960f7f7f1000ffffffff"
)
LOGGED_203_BODIES = [
    bytes.fromhex(value) for value in (
        "a401010101011000091d1d0000bf41ba01ba017f7f",
        "0a0100020f000700001810000600000069b204b2047f7f",
        "0a0100020d0007000018100006000000d0d15e980698067f7f",
        "0b010003ac020007000032100006000001100401000000009c089c087f7f",
        "0b010005ac03000700000e100006000022100406000001100601000000020003000000348b0b8b0b7f7f",
        "0b0100048902000700001e10000600000a1004060000281006060000003f900d900d7f7f",
    )
]


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def read_vints(payload):
    reader = BSMessageReader(payload)
    values = []
    while reader.tell() < len(payload):
        values.append(reader.read_Vint())
    return values


class V18RNG:
    def __init__(
        self, brawler=10000, star_power=1000, skin=1000, bonus=5,
        bonus_type=1, skin_rarity=100, maximum=False,
    ):
        self.brawler = brawler
        self.star_power = star_power
        self.skin = skin
        self.bonus = bonus
        self.bonus_type = bonus_type
        self.skin_rarity = skin_rarity
        self.maximum = maximum
        self.special_rolls = 0

    def randint(self, low, high):
        pair = (low, high)
        if pair == (1, 10000):
            return self.brawler
        if pair == (1, 1000):
            self.special_rolls += 1
            return self.star_power if self.special_rolls % 2 else self.skin
        if pair == (1, 5):
            return self.bonus
        if pair == (1, 11):
            return self.bonus_type
        if pair == (1, 100):
            return self.skin_rarity
        return high if self.maximum else low

    def sample(self, population, count):
        return list(population)[:count]

    def choice(self, population):
        return population[0]

    def choices(self, population, weights=None, k=1):
        return [population[0]]


class MaxRNG(V18RNG):
    def __init__(self):
        super().__init__(maximum=True)


class ForcedBrawlerRNG(MaxRNG):
    def __init__(self, roll=400):
        super().__init__()
        self.brawler = roll


class ForcedStarPowerRNG(MaxRNG):
    def __init__(self):
        super().__init__()
        self.star_power = 9


class AccountTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.player, self.owner = self.make_account()

    def make_account(self, low_id=1, token="economy-token"):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = "Economy Test"
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)
        return player, owner

    def update(self, values, player=None):
        player = player or self.player
        owner = SimpleNamespace(player=player)
        self.assertTrue(DataBase.replaceValues(owner, values))
        self.assertTrue(DataBase.loadAccount(owner))

    def reload(self, player=None):
        source = player or self.player
        loaded = Players(SimpleNamespace())
        loaded.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded


class BoxEconomyTests(AccountTestCase):
    def test_direct_box_costs_and_persistence(self):
        cases = (
            (5, "brawlBoxes", "brawl_boxes", 100, 10),
            (4, "bigBoxes", "big_boxes", 10, 12),
            (1, "gems", "gems", 30, 12),
            (3, "gems", "gems", 80, 11),
        )
        for box_id, column, attribute, cost, box_type in cases:
            with self.subTest(box_id=box_id):
                self.update({column: 1000, "gold": 100})
                with patch(
                    "Logic.BoxService.generate_rewards",
                    return_value=[{"name": "Coins", "amount": 1, "target": 0}],
                ):
                    result = open_boxes(self.player, box_id, rng=random.Random(1))
                self.assertEqual(result["boxType"], box_type)
                self.assertEqual(getattr(self.player, attribute), 1000 - cost)
                self.assertEqual(self.player.gold, 101)
                loaded = self.reload()
                self.assertEqual(getattr(loaded, attribute), 1000 - cost)
                self.assertEqual(loaded.gold, 101)

    def test_stored_boxes_open_only_on_command_without_charging_currency(self):
        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 11, 3)
        transaction.commit()
        self.update({"gems": 500, "gold": 0})
        self.player.box_id = 3
        command = LogicPurchaseBoxCommand(None, self.player, b"")
        command.box_id = 3
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[{"name": "Coins", "amount": 25, "target": 0}],
        ) as generate, patch.object(LogicBoxDataCommand, "send") as send:
            result = command.process()
        generate.assert_called_once()
        self.assertEqual(generate.call_args.kwargs["box_count"], 1)
        send.assert_called_once()
        self.assertEqual(result["openingSource"], "inventory")
        self.assertEqual(result["boxCount"], 1)
        self.assertEqual(self.player.gems, 500)
        self.assertEqual(self.player.gold, 25)
        self.assertEqual(BoxInventory.count(self.player, 11), 2)
        loaded = self.reload()
        self.assertEqual(loaded.gems, 500)
        self.assertEqual(loaded.gold, 25)
        self.assertEqual(BoxInventory.count(loaded, 11), 2)

    def test_native_token_boxes_persist_and_open_without_double_charge(self):
        cases = (
            (5, 10, "brawlBoxes", "brawl_boxes", 100),
            (4, 12, "bigBoxes", "big_boxes", 10),
        )
        for box_id, box_type, column, attribute, cost in cases:
            with self.subTest(box_id=box_id):
                self.update({column: 0, "gold": 0})
                transaction = RewardTransaction(self.player)
                BoxInventory.add(transaction, box_type, 2)
                transaction.commit()
                self.assertEqual(getattr(self.player, attribute), 2 * cost)
                self.assertEqual(BoxInventory.count(self.player, box_type), 2)
                loaded = self.reload()
                self.assertEqual(getattr(loaded, attribute), 2 * cost)
                self.assertEqual(BoxInventory.count(loaded, box_type), 2)
                with patch(
                    "Logic.BoxService.generate_rewards", return_value=[]
                ) as generate:
                    result = open_boxes(loaded, box_id, rng=random.Random(1))
                generate.assert_called_once()
                self.assertEqual(result["openingSource"], "inventory")
                self.assertEqual(result["storedBoxes"], 1)
                self.assertEqual(getattr(loaded, attribute), cost)
                self.assertEqual(loaded.gold, 0)
                persisted = self.reload(loaded)
                self.assertEqual(BoxInventory.count(persisted, box_type), 1)
                self.assertEqual(getattr(persisted, attribute), cost)

    def test_home_migrates_legacy_token_boxes_exactly_once(self):
        transaction = RewardTransaction(self.player)
        transaction.set_value("brawl_boxes", "brawlBoxes", 50)
        transaction.set_value("big_boxes", "bigBoxes", 3)
        transaction.set_progression_value("boxInventory", {
            "version": 1,
            "boxes": {"10": 2, "11": 1, "12": 3},
        })
        transaction.commit()
        with patch(
            "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home"
        ):
            OwnHomeDataMessage(None, self.player).encode()
        self.assertEqual((self.player.brawl_boxes, self.player.big_boxes), (250, 33))
        self.assertEqual(BoxInventory.count(self.player, 10), 2)
        self.assertEqual(BoxInventory.count(self.player, 12), 3)
        state = self.player.progression["boxInventory"]
        self.assertEqual(state["version"], 2)
        self.assertEqual(state["boxes"], {"10": 0, "11": 1, "12": 0})
        loaded = self.reload()
        self.assertEqual((loaded.brawl_boxes, loaded.big_boxes), (250, 33))
        self.assertFalse(BoxInventory.migrate(loaded))
        self.assertEqual((loaded.brawl_boxes, loaded.big_boxes), (250, 33))
        self.assertEqual(BoxInventory.count(loaded, 11), 1)

    def test_multiple_stored_boxes_keep_multiplier_and_persist_one_commit(self):
        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 11, 3)
        transaction.commit()
        self.update({"gems": 500})
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[{"name": "Coins", "amount": 90, "target": 0}],
        ) as generate:
            result = open_boxes(self.player, 3, count=3, rng=random.Random(1))
        self.assertEqual(generate.call_args.kwargs["box_count"], 3)
        self.assertEqual(result["boxCount"], 3)
        self.assertEqual(result["openingSource"], "inventory")
        self.assertEqual(self.player.gems, 500)
        self.assertEqual(BoxInventory.count(self.player, 11), 0)
        command = LogicBoxDataCommand(None, self.player, result)
        command.encode()
        reader = BSMessageReader(command.buffer)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 11, 1, 0, 1])
        loaded = self.reload()
        self.assertEqual(loaded.gems, 500)
        self.assertEqual(BoxInventory.count(loaded, 11), 0)

    def test_partially_stored_multiplier_charges_only_remainder(self):
        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 11, 1)
        transaction.commit()
        self.update({"gems": 500, "UnlockedBrawlers": {"0": 1}})
        with patch(
            "Logic.BoxService.generate_rewards",
            return_value=[
                {"name": "Coins", "amount": 25, "target": 0},
                {"name": "Brawler", "amount": 4, "target": 0},
            ],
        ) as generate:
            result = open_boxes(self.player, 3, count=2)
        self.assertEqual(generate.call_args.kwargs["box_count"], 2)
        self.assertEqual(result["openingSource"], "mixed")
        self.assertEqual(result["boxCount"], 2)
        self.assertEqual(self.player.gems, 420)
        self.assertEqual(self.player.BrawlersUnlockedState["4"], 1)
        self.assertEqual(BoxInventory.count(self.player, 11), 0)
        loaded = self.reload()
        self.assertEqual(loaded.gems, 420)
        self.assertEqual(loaded.BrawlersUnlockedState["4"], 1)
        self.assertEqual(BoxInventory.count(loaded, 11), 0)

    def test_insufficient_multi_box_charge_preserves_inventory(self):
        transaction = RewardTransaction(self.player)
        BoxInventory.add(transaction, 11, 1)
        transaction.commit()
        self.update({"gems": 79})
        with self.assertRaisesRegex(RewardError, "Saldo insuficiente"):
            open_boxes(self.player, 3, count=2)
        self.assertEqual(self.player.gems, 79)
        self.assertEqual(BoxInventory.count(self.player, 11), 1)
        loaded = self.reload()
        self.assertEqual(loaded.gems, 79)
        self.assertEqual(BoxInventory.count(loaded, 11), 1)

    def test_box_encoder_has_no_generation_or_database_side_effect_api(self):
        self.assertFalse(hasattr(LogicBoxDataCommand, "getRewards"))

    def test_unaffordable_box_command_does_not_charge(self):
        self.update({"brawlBoxes": 99, "gold": 123})
        self.player.box_id = 5
        command = LogicPurchaseBoxCommand(None, self.player, b"")
        command.box_id = 5
        with patch.object(LogicBoxDataCommand, "send") as send:
            result = command.process()
        self.assertIn("insuficiente", result.lower())
        self.assertEqual(self.player.brawl_boxes, 99)
        self.assertEqual(self.reload().brawl_boxes, 99)
        send.assert_not_called()

    def test_power_points_are_capped_at_1410(self):
        self.update({
            "brawlBoxes": 100,
            "gold": 0,
            "brawlersUpgradePoints": {"0": 1400},
        })
        result = open_boxes(self.player, 5, rng=MaxRNG())
        self.assertEqual(result["rewardNames"], ["Coins", "UpgradePoints"])
        self.assertEqual(result["rewards"], [60, 10])
        self.assertEqual(self.player.brawlers_upgradium["0"], 1410)
        self.assertEqual(self.reload().brawlers_upgradium["0"], 1410)

    def test_star_power_is_awarded_once(self):
        self.update({
            "brawlBoxes": 200,
            "brawlerPowerLevel": {"0": 8},
            "brawlerStarPower": {"0": 0},
        })
        result = open_boxes(self.player, 5, rng=ForcedStarPowerRNG())
        card = Cards.get_brawler_star_power(0)
        self.assertEqual(result["rewardNames"], ["StarPower"])
        self.assertEqual(result["rewards"], [card])
        self.assertEqual(self.player.Brawler_starPower["0"], card)
        second = open_boxes(self.player, 5, rng=ForcedStarPowerRNG())
        self.assertNotIn("StarPower", second["rewardNames"])
        self.assertEqual(self.reload().Brawler_starPower["0"], card)

    def test_brawler_unlock_does_not_reset_existing_progress(self):
        self.update({"brawlBoxes": 100})
        result = open_boxes(self.player, 5, rng=ForcedBrawlerRNG())
        brawler = result["rewards"][result["rewardNames"].index("Brawler")]
        self.assertEqual(self.player.BrawlersUnlockedState[str(brawler)], 1)
        self.update({
            "brawlersTrophies": {str(brawler): 321},
            "brawlersUpgradePoints": {str(brawler): 222},
            "brawlerPowerLevel": {str(brawler): 5},
        })
        transaction = RewardTransaction(self.player)
        transaction.add_reward("Brawler", brawler)
        transaction.commit()
        self.assertEqual(self.player.brawlers_trophies[str(brawler)], 321)
        self.assertEqual(self.player.brawlers_upgradium[str(brawler)], 222)
        self.assertEqual(self.player.Brawler_level[str(brawler)], 5)

    def test_fully_unlocked_account_never_generates_duplicate_brawler(self):
        states = {str(key): 1 for key in self.player.brawlers_id}
        points = {str(key): 1410 for key in self.player.brawlers_id}
        self.update({
            "UnlockedBrawlers": states,
            "brawlersUpgradePoints": points,
        })
        rewards = generate_rewards(self.player, 10, ForcedBrawlerRNG())
        self.assertNotIn("Brawler", [reward["name"] for reward in rewards])

    def test_purchase_box_v13_decoder_reads_fifth_vint(self):
        payload = bytes.fromhex("a701a7017f7f05ffffffff")
        command = LogicPurchaseBoxCommand(None, self.player, payload)
        command.decode()
        self.assertEqual(command.box_id, 5)
        self.assertEqual(command.read(), b"\xff" * 4)


class V18BoxGeneratorTests(AccountTestCase):
    def unlock_all_for_power_points(self):
        brawlers = list(self.player.brawlers_id)
        self.update({
            "UnlockedBrawlers": {str(brawler): 1 for brawler in brawlers},
            "brawlerPowerLevel": {str(brawler): 1 for brawler in brawlers},
            "brawlersUpgradePoints": {str(brawler): 0 for brawler in brawlers},
        })

    def test_nost_box_ids_use_one_three_and_ten_v18_iterations(self):
        self.unlock_all_for_power_points()
        for visual_type, generation_type, gold, point_count in (
            (10, 1, 30, 2),
            (12, 3, 90, 3),
            (11, 10, 300, 5),
        ):
            with self.subTest(visual_type=visual_type):
                self.assertEqual(
                    Boxes.get_generation_type(visual_type), generation_type
                )
                rewards = generate_rewards(self.player, visual_type, V18RNG())
                names = [reward["name"] for reward in rewards]
                self.assertEqual(names.count("Coins"), 1)
                self.assertEqual(names.count("UpgradePoints"), point_count)
                coins = rewards[names.index("Coins")]["amount"]
                self.assertEqual(coins, gold)
                self.assertTrue(all(reward["amount"] > 0 for reward in rewards))

    def test_multiple_boxes_generate_every_slot_and_aggregate_resources(self):
        self.unlock_all_for_power_points()
        rewards = generate_rewards(
            self.player, 10, V18RNG(), box_count=3
        )
        names = [reward["name"] for reward in rewards]
        self.assertEqual(names.count("Coins"), 1)
        self.assertEqual(rewards[names.index("Coins")]["amount"], 90)
        self.assertEqual(names.count("UpgradePoints"), 6)
        self.assertTrue(all(reward["amount"] > 0 for reward in rewards))

    def test_every_v18_brawler_rarity_threshold(self):
        cases = (
            (10, 5, "legendary"),
            (25, 11, "mega_epic"),
            (70, 15, "epic"),
            (200, 4, "super_rare"),
            (400, 6, "rare"),
        )
        for roll, expected, rarity in cases:
            with self.subTest(rarity=rarity, roll=roll):
                rewards = generate_rewards(
                    self.player, 10, V18RNG(brawler=roll)
                )
                self.assertEqual(
                    [reward["name"] for reward in rewards], ["Brawler"]
                )
                self.assertEqual(rewards[0]["amount"], expected)

    def test_all_v18_bonus_types(self):
        for bonus_type, name, amount in (
            (10, "gems", 3),
            (7, "tokens_doubler", 200),
            (1, "tickets", 3),
        ):
            with self.subTest(name=name):
                rewards = generate_rewards(
                    self.player,
                    10,
                    V18RNG(bonus=1, bonus_type=bonus_type),
                )
                self.assertEqual(rewards[-1], {
                    "name": name, "amount": amount, "target": 0,
                })

    def test_simultaneous_special_rewards_never_create_negative_values(self):
        self.update({
            "brawlBoxes": 100,
            "gold": 0,
            "brawlerPowerLevel": {"0": 8},
            "brawlerStarPower": {"0": 0},
            "UnlockedSkins": {"Skins": []},
            "brawlersSkins": {"0": 0},
        })
        rng = V18RNG(
            brawler=1,
            star_power=9,
            skin=20,
            skin_rarity=1,
            maximum=True,
        )
        result = open_boxes(self.player, 5, rng=rng)
        self.assertEqual(
            result["rewardNames"], ["Brawler", "StarPower", "Skin"]
        )
        self.assertTrue(all(amount >= 0 for amount in result["rewards"]))
        self.assertEqual(self.player.gold, 0)
        self.assertTrue(all(
            value >= 0 for value in self.player.brawlers_upgradium.values()
        ))
        self.assertEqual(self.player.BrawlersUnlockedState["5"], 1)
        self.assertIn(29, self.player.UnlockedSkins["Skins"])
        self.assertEqual(self.player.brawlers_skins["0"], 0)
        loaded = self.reload()
        self.assertEqual(loaded.gold, 0)
        self.assertIn(29, loaded.UnlockedSkins["Skins"])
        self.assertEqual(loaded.brawlers_skins["0"], 0)

    def test_generation_has_no_account_or_database_side_effects(self):
        before = {
            "gold": self.player.gold,
            "states": copy.deepcopy(self.player.BrawlersUnlockedState),
            "points": copy.deepcopy(self.player.brawlers_upgradium),
            "skins": copy.deepcopy(self.player.UnlockedSkins),
        }
        rewards = generate_rewards(
            self.player, 10, V18RNG(brawler=400, skin=20, skin_rarity=1)
        )
        self.assertTrue(any(reward["name"] == "Brawler" for reward in rewards))
        self.assertEqual(self.player.gold, before["gold"])
        self.assertEqual(self.player.BrawlersUnlockedState, before["states"])
        self.assertEqual(self.player.brawlers_upgradium, before["points"])
        self.assertEqual(self.player.UnlockedSkins, before["skins"])
        loaded = self.reload()
        self.assertEqual(loaded.BrawlersUnlockedState, before["states"])
        self.assertEqual(loaded.brawlers_upgradium, before["points"])

    def test_seeded_bundles_never_contain_negative_amounts(self):
        self.unlock_all_for_power_points()
        for box_type in (10, 12, 11):
            for seed in range(40):
                with self.subTest(box_type=box_type, seed=seed):
                    rewards = generate_rewards(
                        self.player, box_type, random.Random(seed)
                    )
                    self.assertTrue(rewards)
                    self.assertTrue(all(
                        isinstance(reward["amount"], int)
                        and reward["amount"] >= 0
                        for reward in rewards
                    ))


class ValidatedEconomyCommandTests(AccountTestCase):
    @staticmethod
    def payload(*values):
        header = b"".join(vint(value) for value in (1, 1, -1, -1))
        return header + b"".join(vint(value) for value in values) + b"\xff" * 4

    def test_gold_purchase_is_atomic_and_persistent(self):
        self.update({"gems": 999, "gold": 0})
        command = LogicPurchaseHeroLvlUpMaterialCommand(
            None, self.player, self.payload(2)
        )
        command.decode()
        result = command.process()
        self.assertIsInstance(result, dict)
        self.assertEqual((self.player.gems, self.player.gold), (859, 1200))
        loaded = self.reload()
        self.assertEqual((loaded.gems, loaded.gold), (859, 1200))
        self.assertEqual(command.read(), b"\xff" * 4)

    def test_gold_purchase_rejects_insufficient_balance_and_bad_index(self):
        for index, gems in ((0, 10), (99, 999), (-1, 999)):
            with self.subTest(index=index, gems=gems):
                self.update({"gems": gems, "gold": 123})
                command = LogicPurchaseHeroLvlUpMaterialCommand(
                    None, self.player, self.payload(index)
                )
                command.decode()
                self.assertIsInstance(command.process(), str)
                self.assertEqual((self.player.gems, self.player.gold), (gems, 123))
                loaded = self.reload()
                self.assertEqual((loaded.gems, loaded.gold), (gems, 123))

    def test_token_doubler_checks_balance_and_persists_atomically(self):
        self.update({"gems": 999, "tokensdoubler": 25})
        command = LogicPurchaseDoubleCoinsCommand(None, self.player, self.payload())
        command.decode()
        self.assertIsInstance(command.process(), dict)
        self.assertEqual((self.player.gems, self.player.tokensdoubler), (949, 1025))
        self.assertEqual(command.read(), b"\xff" * 4)

        self.update({"gems": 0})
        rejected = LogicPurchaseDoubleCoinsCommand(None, self.player, self.payload())
        rejected.decode()
        self.assertIsInstance(rejected.process(), str)
        self.assertEqual((self.player.gems, self.player.tokensdoubler), (0, 1025))
        loaded = self.reload()
        self.assertEqual((loaded.gems, loaded.tokensdoubler), (0, 1025))

    def test_brawler_upgrade_charges_once_and_persists(self):
        self.update({"gold": 1000, "brawlerPowerLevel": {"0": 1}})
        command = Upgrade_Brawler(None, self.player, self.payload(16, 0))
        command.decode()
        self.assertEqual(command.process(), {"brawler": 0, "level": 2})
        self.assertEqual(self.player.gold, 965)
        self.assertEqual(self.player.Brawler_level["0"], 2)
        loaded = self.reload()
        self.assertEqual((loaded.gold, loaded.Brawler_level["0"]), (965, 2))
        self.assertEqual(command.read(), b"\xff" * 4)

    def test_brawler_upgrade_rejects_locked_poor_and_max_level_accounts(self):
        cases = ((1, 1000, 1), (0, 0, 1), (0, 2000, 8))
        for brawler, gold, level in cases:
            with self.subTest(brawler=brawler, gold=gold, level=level):
                self.update({
                    "gold": gold,
                    "UnlockedBrawlers": {"0": 1},
                    "brawlerPowerLevel": {"0": level, "1": 1},
                })
                command = Upgrade_Brawler(
                    None, self.player, self.payload(16, brawler)
                )
                command.decode()
                self.assertIsInstance(command.process(), str)
                self.assertEqual(self.player.gold, gold)
                self.assertEqual(self.player.Brawler_level[str(brawler)], level)
                loaded = self.reload()
                self.assertEqual(loaded.gold, gold)
                self.assertEqual(loaded.Brawler_level[str(brawler)], level)

        invalid = Upgrade_Brawler(None, self.player, self.payload(16, 999))
        with self.assertRaises(ValueError):
            invalid.decode()


class BoxProtocolTests(AccountTestCase):
    def test_required_command_ids_are_registered(self):
        self.assertEqual(COMMAND_HANDLERS[500], LogicPurchaseBoxCommand)
        self.assertEqual(COMMAND_HANDLERS[535], LogicPurchaseBoxCommand)
        self.assertEqual(COMMAND_HANDLERS[519], LogicPurchaseOfferCommand)
        self.assertEqual(COMMAND_HANDLERS[507], LogicBuySkinCommand)
        self.assertEqual(COMMAND_HANDLERS[525], LogicSelectBrawlerCommand)
        self.assertEqual(COMMAND_HANDLERS[203], LogicBoxDataEchoCommand)
        self.assertEqual(COMMAND_HANDLERS[515].__name__, "LogicClearShopTickersCommand")
        self.assertEqual(COMMAND_HANDLERS[517].__name__, "LogicClaimRankUpRewardCommand")
        self.assertEqual(COMMAND_HANDLERS[522], LogicRemoveNewTagBrawler)
        self.assertEqual(COMMAND_HANDLERS[201], LogicChangeAvatarNameCommand)

    def test_logged_box_500_is_decoded_charged_and_answered(self):
        message = EndClientTurn(None, self.player, LOGGED_BOX_500)
        message.decode()
        with patch.object(LogicBoxDataCommand, "send") as send:
            message.process()
        self.assertEqual(message.command_ids, [500])
        send.assert_called_once()
        self.assertEqual(self.player.brawl_boxes, 899)
        self.assertEqual(self.reload().brawl_boxes, 899)
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_logged_skin_507_is_decoded_charged_and_answered(self):
        message = EndClientTurn(None, self.player, LOGGED_SKIN_507)
        message.decode()
        with patch.object(LogicBuyItem, "send") as send:
            message.process()
        self.assertEqual(message.command_ids, [507])
        send.assert_called_once()
        self.assertEqual((self.player.skin_id, self.player.brawler_id), (29, 0))
        self.assertEqual(self.player.gems, 949)
        self.assertIn(29, self.player.UnlockedSkins["Skins"])
        self.assertEqual(self.player.brawlers_skins["0"], 29)
        loaded = self.reload()
        self.assertEqual(loaded.gems, 949)
        self.assertIn(29, loaded.UnlockedSkins["Skins"])
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_default_skin_507_unlocks_brawler_through_correct_item_response(self):
        default_skin = next(
            skin for skin in Skins.get_skins_id()
            if Skins.getBrawler(skin) == 1 and Skins.getIsDefaultSkin(skin)
        )
        self.update({
            "UnlockedBrawlers": {"0": 1, "1": 0},
            "UnlockedSkins": {"Skins": []},
        })
        payload = b"".join(vint(value) for value in (0, 1, 0, 1, 507))
        payload += b"".join(
            vint(value) for value in (146, 146, -64, -64, 29, default_skin)
        ) + b"\xff" * 4
        message = EndClientTurn(None, self.player, payload)
        message.decode()
        with patch.object(LogicBoxDataCommand, "send") as box_send, \
             patch.object(LogicBuyItem, "send") as item_send, \
             patch.object(LogicSkinDataCommand, "send") as skin_send:
            message.process()
        box_send.assert_not_called()
        item_send.assert_called_once()
        skin_send.assert_not_called()
        self.assertEqual(message.command_ids, [507])
        self.assertEqual(self.player.BrawlersUnlockedState["1"], 1)
        self.assertEqual((self.player.brawler_id, self.player.skin_id), (1, default_skin))
        self.assertEqual(self.reload().BrawlersUnlockedState["1"], 1)
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_select_skin_506_requires_ownership_and_persists_atomically(self):
        payload = bytes.fromhex("920292027f7f1d1dffffffff")
        self.update({
            "brawlerID": 0,
            "skinID": 0,
            "brawlersSkins": {"0": 0},
            "UnlockedSkins": {"Skins": [29]},
        })
        command = LogicSelectSkinCommand(None, self.player, payload)
        command.decode()
        self.assertEqual(command.process(), {"skin": 29, "brawler": 0})
        self.assertEqual(self.player.brawlers_skins["0"], 29)
        self.assertEqual(command.read(), b"\xff" * 4)
        loaded = self.reload()
        self.assertEqual((loaded.skin_id, loaded.brawlers_skins["0"]), (29, 29))

        self.update({
            "skinID": 0,
            "brawlersSkins": {"0": 0},
            "UnlockedSkins": {"Skins": []},
        })
        rejected = LogicSelectSkinCommand(None, self.player, payload)
        rejected.decode()
        self.assertIsInstance(rejected.process(), str)
        self.assertEqual((self.player.skin_id, self.player.brawlers_skins["0"]), (0, 0))
        loaded = self.reload()
        self.assertEqual((loaded.skin_id, loaded.brawlers_skins["0"]), (0, 0))

    def test_logged_remove_new_tag_522_consumes_int_and_persists(self):
        progression = copy.deepcopy(self.player.progression)
        progression["brawlerNewTag"] = {"0": 1}
        self.update({"progression": progression})
        message = EndClientTurn(None, self.player, LOGGED_NEW_TAG_522)
        message.decode()
        message.process()
        self.assertEqual(self.player.progression["brawlerNewTag"]["0"], 0)
        self.assertEqual(self.reload().progression["brawlerNewTag"]["0"], 0)
        self.assertEqual(message.new_tag_state, 2)
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_name_echo_201_never_claims_trophy_road(self):
        message = EndClientTurn(None, self.player, LOGGED_NAME_201)
        message.decode()
        with patch.object(TrophyRoad, "claim") as claim:
            message.process()
        claim.assert_not_called()
        self.assertEqual(message.echoed_name, "kat")
        self.assertEqual(message.avatar_fields, [0, 29, 65, 65, -64, -64])
        self.assertEqual(message.read(), b"\xff" * 4)
        self.assertEqual(self.player.trophy_road, 1)
        self.assertEqual(self.reload().trophy_road, 1)

    def test_real_506_525_turn_is_interleaved_and_fully_consumed(self):
        self.update({
            "brawlerID": 0,
            "skinID": 29,
            "brawlersSkins": {"0": 29},
            "UnlockedSkins": {"Skins": [29]},
            "UnlockedBrawlers": {"0": 1},
        })
        message = EndClientTurn(None, self.player, LOGGED_SELECT_SKIN_AND_BRAWLER)
        message.decode()
        message.process()
        self.assertEqual(message.command_ids, [506, 525])
        self.assertEqual(message.skin_reference, (29, 0))
        self.assertEqual(message.brawler_reference, (16, 0))
        self.assertEqual((self.player.brawler_id, self.player.skin_id), (0, 0))
        self.assertEqual(self.player.brawlers_skins["0"], 0)
        loaded = self.reload()
        self.assertEqual((loaded.brawler_id, loaded.skin_id), (0, 0))
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_525_switches_only_to_an_unlocked_brawler(self):
        payload = b"".join(
            vint(value) for value in (982, 982, -64, -64, 16, 1)
        ) + b"\xff" * 4
        self.update({
            "brawlerID": 0,
            "skinID": 29,
            "brawlersSkins": {"0": 29, "1": 0},
            "UnlockedBrawlers": {"0": 1, "1": 1},
        })
        command = LogicSelectBrawlerCommand(None, self.player, payload)
        command.decode()
        self.assertEqual(command.process(), {"brawler": 1, "skin": 0})
        self.assertEqual((self.player.brawler_id, self.player.skin_id), (1, 0))
        self.assertEqual(command.read(), b"\xff" * 4)
        self.assertEqual((self.reload().brawler_id, self.reload().skin_id), (1, 0))

        self.update({
            "brawlerID": 0,
            "skinID": 29,
            "UnlockedBrawlers": {"0": 1, "1": 0},
        })
        rejected = LogicSelectBrawlerCommand(None, self.player, payload)
        rejected.decode()
        self.assertIsInstance(rejected.process(), str)
        self.assertEqual((self.player.brawler_id, self.player.skin_id), (0, 29))
        self.assertEqual((self.reload().brawler_id, self.reload().skin_id), (0, 29))

    def test_multiple_commands_use_interleaved_payloads(self):
        progression = copy.deepcopy(self.player.progression)
        progression["brawlerNewTag"] = {"0": 1}
        self.update({"progression": progression})
        payload = b"".join(vint(value) for value in (0, 1, 0, 3))
        payload += vint(201) + (3).to_bytes(4, "big") + b"kat"
        payload += b"".join(vint(value) for value in (0, 29, 65, 65, -64, -64))
        payload += vint(500)
        payload += b"".join(vint(value) for value in (99, 99, -1, -1, 5))
        payload += vint(522)
        payload += b"".join(vint(value) for value in (100, 100, -1, -1, 16, 0))
        payload += (2).to_bytes(4, "big") + b"\xff" * 4
        message = EndClientTurn(None, self.player, payload)
        message.decode()
        with patch.object(LogicBoxDataCommand, "send") as send:
            message.process()
        self.assertEqual(message.command_ids, [201, 500, 522])
        send.assert_called_once()
        self.assertEqual(self.player.brawl_boxes, 899)
        self.assertEqual(self.player.progression["brawlerNewTag"]["0"], 0)
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_logged_203_echoes_are_consumed_without_reapplying_rewards(self):
        for body in LOGGED_203_BODIES:
            with self.subTest(body=body.hex()):
                before = (self.player.gold, self.player.gems, self.player.brawl_boxes)
                payload = b"".join(vint(value) for value in (0, 1, 0, 1, 203))
                payload += body + b"\xff" * 4
                message = EndClientTurn(None, self.player, payload)
                message.decode()
                with patch.object(
                    DataBase, "replaceValues",
                    side_effect=AssertionError("203 echo wrote to the database"),
                ):
                    message.process()
                self.assertEqual(message.command_ids, [203])
                self.assertEqual(len(message.turn_context), 5)
                self.assertEqual(
                    (self.player.gold, self.player.gems, self.player.brawl_boxes),
                    before,
                )
                self.assertEqual(message.read(), b"\xff" * 4)

    def test_box_encoder_has_native_v13_header_and_no_database_writes(self):
        card = Cards.get_brawler_star_power(0)
        result = {
            "boxID": 100,
            "boxType": 10,
            "rewards": [25, 10, 1, card],
            "rewardNames": ["Coins", "UpgradePoints", "Brawler", "StarPower"],
            "rewardsTargetBrawler": [0, 0, 1, 0],
            "trophyRoad": 9,
        }
        command = LogicBoxDataCommand(None, self.player, result)
        with patch.object(
            DataBase, "replaceValues", side_effect=AssertionError("encode wrote DB")
        ):
            command.encode()
        self.assertEqual(read_vints(command.buffer), [
            203, 10, 1, 0, 4,
            25, 0, 7, 0, 0,
            10, 16, 0, 6, 0, 0,
            1, 16, 1, 1, 0, 0,
            1, 23, 76, 4, 0, 0,
            9,
        ])

    def test_native_v13_box_body_round_trips_through_the_203_echo(self):
        card = Cards.get_brawler_star_power(0)
        result = {
            "boxID": 5,
            "boxType": 5,
            "rewards": [25, 10, 1, card],
            "rewardNames": ["Coins", "UpgradePoints", "Brawler", "StarPower"],
            "rewardsTargetBrawler": [0, 0, 1, 0],
            "trophyRoad": 0,
        }
        command = LogicBoxDataCommand(None, self.player, result)
        command.encode()
        encoded = BSMessageReader(command.buffer)
        self.assertEqual(encoded.read_Vint(), 203)
        context = b"".join(vint(value) for value in (7, 8, 8, -64, -64))
        payload = b"".join(vint(value) for value in (0, 1, 0, 1, 203))
        payload += encoded.read() + context + b"\xff" * 4
        message = EndClientTurn(None, self.player, payload)
        message.decode()
        with patch.object(
            DataBase, "replaceValues",
            side_effect=AssertionError("203 echo wrote to the database"),
        ):
            message.process()
        self.assertEqual(
            (message.box_count_or_type, message.box_count, message.box_id),
            (10, 1, 0),
        )
        self.assertEqual([reward[1] for reward in message.rewards], [7, 6, 1, 4])
        self.assertEqual(message.turn_context, [7, 8, 8, -64, -64])
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_direct_skin_delivery_uses_dedicated_v18_response(self):
        self.update({"gems": 100})
        result = SkinPurchase.purchase(self.player, 29, 0)
        command = LogicSkinDataCommand(None, self.player, result)
        with patch.object(
            DataBase, "replaceValues", side_effect=AssertionError("encode wrote DB")
        ):
            command.encode()
        self.assertEqual(read_vints(command.buffer), [
            203, 0, 1, 100, 1,
            1, 0, 9, 29, 29,
            0, 0, 0, 1, 0, 0,
        ])
        legacy = LogicUnlockSkinServerCommand(None, self.player, result)
        legacy.encode()
        self.assertEqual(legacy.buffer, command.buffer)

    def test_v18_skin_response_round_trips_through_the_203_echo(self):
        command = LogicSkinDataCommand(None, self.player, 29)
        command.encode()
        encoded = BSMessageReader(command.buffer)
        self.assertEqual(encoded.read_Vint(), 203)
        context = b"".join(vint(value) for value in (9, 10, 10, -64, -64))
        payload = b"".join(vint(value) for value in (0, 1, 0, 1, 203))
        payload += encoded.read() + context + b"\xff" * 4
        message = EndClientTurn(None, self.player, payload)
        message.decode()
        with patch.object(
            DataBase, "replaceValues",
            side_effect=AssertionError("203 skin echo wrote to the database"),
        ):
            message.process()
        self.assertTrue(message.v18_skin_response)
        self.assertEqual(message.rewards, [(1, 9, (29, 29))])
        self.assertEqual(message.response_tail, [0, 0, 0, 1, 0, 0])
        self.assertEqual(message.turn_context, [9, 10, 10, -64, -64])
        self.assertEqual(message.read(), b"\xff" * 4)

    def test_notification_skin_echoes_accept_the_short_and_extended_tails(self):
        for skin in (52, 59):
            for with_context in (False, True):
                with self.subTest(skin=skin, with_context=with_context):
                    command = LogicSkinDataCommand(
                        None, self.player, skin, v13=True
                    )
                    command.encode()
                    encoded = BSMessageReader(command.buffer)
                    self.assertEqual(encoded.read_Vint(), 203)
                    context = b""
                    trailer = b""
                    if with_context:
                        context = b"".join(
                            vint(value) for value in (9, 10, 10, -64, -64)
                        )
                        trailer = b"\xff" * 4
                    payload = b"".join(
                        vint(value) for value in (0, 1, 0, 1, 203)
                    )
                    payload += encoded.read() + context + trailer
                    message = EndClientTurn(None, self.player, payload)
                    message.decode()
                    with patch.object(
                        DataBase, "replaceValues",
                        side_effect=AssertionError("203 skin echo wrote to the database"),
                    ):
                        message.process()
                    self.assertEqual(message.rewards, [(1, 9, (29, skin))])
                    self.assertEqual(
                        message.response_tail, [0, 0, 0, 1, 0, 0, 0]
                    )
                    self.assertEqual(
                        message.turn_context,
                        [9, 10, 10, -64, -64] if with_context else [],
                    )
                    self.assertEqual(message.read(), trailer)

    def test_skin_echo_rejects_an_unknown_suffix(self):
        command = LogicSkinDataCommand(None, self.player, 52, v13=True)
        command.encode()
        encoded = BSMessageReader(command.buffer)
        self.assertEqual(encoded.read_Vint(), 203)
        payload = b"".join(vint(value) for value in (0, 1, 0, 1, 203))
        payload += encoded.read() + vint(0)
        message = EndClientTurn(None, self.player, payload)
        message.decode()
        self.assertEqual(message.read_Vint(), 203)
        message.commandID = 203
        with self.assertRaisesRegex(ValueError, "Invalid skin reward echo suffix"):
            LogicBoxDataEchoCommand.decode(message)

    def test_offer_and_skin_decoders_match_logged_v13_layout(self):
        offer = LogicPurchaseOfferCommand(
            None, self.player,
            b"".join(vint(0) for _ in range(4)) + vint(7) + vint(0) + b"x",
        )
        offer.decode()
        self.assertEqual(offer.offer_index, 7)
        self.assertEqual(offer.target_reference, (0, -1))
        self.assertEqual(offer.read(), b"x")

        skin = LogicBuySkinCommand(
            None, self.player, bytes.fromhex("920292027f7f1d1dffffffff")
        )
        skin.decode()
        self.assertEqual(skin.skin_reference, (29, 29))
        self.assertEqual((skin.skin_id, skin.brawler_id), (29, 0))
        self.assertEqual(self.player.skin_id, 0)
        self.assertEqual(skin.read(), b"\xff" * 4)


class SkinPurchaseV18Tests(AccountTestCase):
    def test_all_v18_price_groups_and_gold_requirements_are_ported(self):
        expected = {
            50: (15, 27, 29, 94, 117, 118),
            80: (5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93),
            100: (95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115),
            150: (26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91),
            250: (96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116),
            300: (49,),
        }
        self.assertEqual(V18_PRICE_GROUPS, expected)
        self.assertEqual(len(V18_SKIN_PRICES), 58)
        for price, skins in expected.items():
            for skin in skins:
                self.assertEqual(SkinPurchase.price_for(skin), price)
        self.assertEqual(V18_GOLD_REQUIREMENTS, {
            96: 95, 98: 97, 100: 99, 102: 101, 104: 103, 106: 105,
            108: 107, 110: 109, 112: 111, 114: 113, 116: 115,
        })
        for gold, silver in V18_GOLD_REQUIREMENTS.items():
            self.assertEqual(SkinPurchase.required_skin_for(gold), silver)
        self.assertEqual(SkinPurchase.required_skin_for(29), 0)

    def test_every_v18_priced_skin_available_in_v13_is_charged_correctly(self):
        available = [
            skin for skin in sorted(V18_SKIN_PRICES)
            if skin in Skins.get_skins_id()
        ]
        self.assertTrue(available)
        self.update({
            "gems": 100000,
            "UnlockedBrawlers": {
                str(brawler): 1 for brawler in self.player.brawlers_id
            },
            "UnlockedSkins": {"Skins": []},
        })
        for skin in available:
            with self.subTest(skin=skin):
                brawler = Skins.getBrawler(skin)
                self.assertFalse(Skins.getIsDefaultSkin(skin))
                before = self.player.gems
                result = SkinPurchase.purchase(self.player, skin, brawler)
                self.assertEqual(result["price"], V18_SKIN_PRICES[skin])
                self.assertEqual(self.player.gems, before - V18_SKIN_PRICES[skin])
                self.assertIn(skin, self.player.UnlockedSkins["Skins"])
        loaded = self.reload()
        self.assertEqual(loaded.gems, self.player.gems)
        for skin in available:
            self.assertIn(skin, loaded.UnlockedSkins["Skins"])

    def test_v18_price_overrides_csv_and_unlisted_skin_keeps_csv_price(self):
        self.assertEqual(Skins.getSkinPrice(29), 30)
        self.assertEqual(SkinPurchase.price_for(29), 50)
        self.assertEqual(SkinPurchase.price_for(2), 30)
        self.update({
            "gems": 100,
            "UnlockedBrawlers": {"0": 1, "1": 1},
            "UnlockedSkins": {"Skins": []},
        })
        result = SkinPurchase.purchase(self.player, 2, 1)
        self.assertEqual((result["price"], result["v18PriceRule"]), (30, False))
        self.assertEqual(self.player.gems, 70)
        self.assertEqual(self.player.brawlers_skins["1"], 2)
        loaded = self.reload()
        self.assertEqual((loaded.gems, loaded.skin_id), (70, 2))
        self.assertIn(2, loaded.UnlockedSkins["Skins"])

    def test_v18_skin_with_insufficient_balance_is_atomic(self):
        self.update({"gems": 49, "UnlockedSkins": {"Skins": []}})
        with self.assertRaises(RewardError):
            SkinPurchase.purchase(self.player, 29, 0)
        self.assertEqual(self.player.gems, 49)
        self.assertNotIn(29, self.player.UnlockedSkins["Skins"])
        loaded = self.reload()
        self.assertEqual(loaded.gems, 49)
        self.assertNotIn(29, loaded.UnlockedSkins["Skins"])

    def test_gold_skin_requires_silver_and_never_charges_on_failure(self):
        self.update({
            "gems": 500,
            "UnlockedBrawlers": {"0": 1},
            "UnlockedSkins": {"Skins": []},
            "brawlersSkins": {"0": 0},
        })
        with patch.object(Skins, "get_skins_id", return_value=[95, 96]), \
             patch.object(Skins, "getBrawler", return_value=0), \
             patch.object(Skins, "getIsDefaultSkin", return_value=False):
            with self.assertRaises(RewardError):
                SkinPurchase.purchase(self.player, 96, 0)
            self.assertEqual(self.player.gems, 500)
            self.assertNotIn(96, self.player.UnlockedSkins["Skins"])
            self.assertEqual(self.reload().gems, 500)

            self.update({"UnlockedSkins": {"Skins": [95]}})
            result = SkinPurchase.purchase(self.player, 96, 0)
            self.assertEqual((result["price"], result["requiredSkin"]), (250, 95))
            self.assertEqual(self.player.gems, 250)
            self.assertEqual(self.player.brawlers_skins["0"], 96)
            loaded = self.reload()
            self.assertEqual((loaded.gems, loaded.skin_id), (250, 96))
            self.assertIn(96, loaded.UnlockedSkins["Skins"])

            with self.assertRaises(RewardError):
                SkinPurchase.purchase(self.player, 96, 0)
            self.assertEqual(self.player.gems, 250)

            self.update({"gems": 249, "UnlockedSkins": {"Skins": [95]}})
            with self.assertRaises(RewardError):
                SkinPurchase.purchase(self.player, 96, 0)
            self.assertEqual(self.player.gems, 249)
            self.assertNotIn(96, self.player.UnlockedSkins["Skins"])
            self.assertNotIn(96, self.reload().UnlockedSkins["Skins"])


class TrophyRoadTests(AccountTestCase):
    def test_all_94_positions_claim_sequentially(self):
        unlocked_events = 0
        for position in range(1, 95):
            with self.subTest(position=position):
                self.assertEqual(self.player.trophy_road, position)
                result = TrophyRoad.claim(self.player, 0, random.Random(position))
                self.assertEqual(result["claimedPosition"], position)
                self.assertEqual(result["rewardType"], TrophyRoad.REWARDS[position - 1])
                self.assertEqual(self.player.trophy_road, position + 1)
                if result["rewardType"] == "event":
                    unlocked_events += 1
                    self.assertEqual(
                        self.player.progression["unlockedEvents"], unlocked_events
                    )
        self.assertEqual(self.player.trophy_road, 95)
        self.assertEqual(unlocked_events, 4)
        with self.assertRaises(RewardError):
            TrophyRoad.claim(self.player, 0)
        loaded = self.reload()
        self.assertEqual(loaded.trophy_road, 95)
        self.assertEqual(loaded.progression["unlockedEvents"], 4)

    def test_exact_non_box_rewards(self):
        cases = (
            (2, "Brawler", 8),
            (7, "tokens_doubler", 200),
            (9, "UpgradePoints", 25),
            (16, "Coins", 50),
            (24, "tickets", 10),
            (51, "tokens_doubler", 600),
            (94, "Coins", 150),
        )
        for position, name, amount in cases:
            with self.subTest(position=position):
                self.player.trophy_road = position
                result = TrophyRoad.claim(self.player, 0, random.Random(1))
                self.assertEqual(result["rewardNames"], [name])
                self.assertEqual(result["rewards"], [amount])
                self.assertEqual(result["trophyRoad"], position + 1)


class TrophyRoadCsvCompatibilityTests(AccountTestCase):
    def test_csv_positions_seven_eight_and_twelve_are_aligned(self):
        self.assertEqual(len(TrophyRoad.REWARDS), 94)
        self.assertEqual(len(TrophyRoad.REWARD_VALUES), 94)
        self.assertEqual(
            (TrophyRoad.REWARDS[6], TrophyRoad.REWARD_VALUES[6]),
            ("tokenDoublers", 200),
        )
        self.assertEqual(
            (TrophyRoad.REWARDS[7], TrophyRoad.REWARD_VALUES[7]),
            ("event", 3),
        )
        self.assertEqual(
            (TrophyRoad.REWARDS[11], TrophyRoad.REWARD_VALUES[11]),
            ("event", 7),
        )

    def test_unlocked_trophy_brawler_falls_back_to_brawl_box(self):
        states = copy.deepcopy(self.player.BrawlersUnlockedState)
        states["8"] = 1
        self.update({"UnlockedBrawlers": states, "leagueReward": 2})
        result = TrophyRoad.claim(self.player, 0, V18RNG())
        self.assertEqual(result["rewardType"], "box")
        self.assertEqual(result["boxType"], 10)
        self.assertNotIn("Brawler", result["rewardNames"])
        self.assertEqual(result["trophyRoad"], 3)
        self.assertEqual(self.reload().trophy_road, 3)


class BattleRewardTests(AccountTestCase):
    def test_three_vs_three_victory_persists_all_rewards(self):
        self.player.player_experience = 0
        self.update({
            "playerExp": 0,
            "tokensdoubler": 5,
            "brawlBoxes": 0,
            "trophies": 0,
            "highest_trophies": 0,
        })
        self.player.battle_result = 0
        self.player.result = 16
        result = apply_battle_result_rewards(self.player, 0)
        self.assertEqual(result.rewards["trophies_gain"], 6)
        self.assertEqual(result.rewards["tokens_gain"], 20)
        self.assertEqual(result.rewards["doubled_tokens"], 5)
        self.assertEqual(result.totaltokens, 25)
        self.assertEqual(result.experience, 18)
        self.assertEqual(result.mvpexperience, 10)
        self.assertEqual(self.player.trophies, 6)
        self.assertEqual(self.player.brawlers_trophies["0"], 6)
        self.assertEqual(self.player.brawl_boxes, 25)
        self.assertEqual(self.player.big_boxes, 1)
        self.assertEqual(self.player.player_experience, 28)
        self.assertEqual(self.player.ThreeVSThree_wins, 1)
        self.assertEqual(
            (self.player.tokensAnim, self.player.trophiesAnim, self.player.bigTokensAnim),
            (25, 6, 1),
        )
        loaded = self.reload()
        self.assertEqual(loaded.trophies, 6)
        self.assertEqual(loaded.brawl_boxes, 25)
        self.assertEqual(loaded.player_experience, 28)

    def test_solo_and_duo_tables(self):
        cases = (
            (2, 1, 8, 0, "solo_wins"),
            (2, 10, 0, 34, "solo_wins"),
            (5, 1, 7, 0, "duo_wins"),
            (5, 5, 0, 32, "duo_wins"),
        )
        for index, (mode, rank, trophies, tokens, win_attribute) in enumerate(cases, 10):
            with self.subTest(mode=mode, rank=rank):
                player, _ = self.make_account(index, f"battle-{mode}-{rank}")
                player.rank = rank
                player.result = 16
                result = apply_battle_result_rewards(player, mode)
                self.assertEqual(result.rewards["trophies_gain"], trophies)
                self.assertEqual(result.rewards["tokens_gain"], tokens)
                self.assertEqual(player.brawlers_trophies["0"], trophies)
                self.assertEqual(getattr(player, win_attribute), 1)

    def test_high_trophy_defeat_and_milestone_crossing(self):
        self.update({
            "brawlersTrophies": {"0": 100},
            "brawlersTrophiesForRank": {"0": 100},
            "trophies": 100,
            "highest_trophies": 100,
        })
        self.player.battle_result = 1
        result = apply_battle_result_rewards(self.player, 0)
        self.assertEqual(result.rewards["trophies_gain"], -2)
        self.assertEqual(self.player.brawlers_trophies["0"], 98)
        self.assertEqual(self.player.brawlers_trophies_in_rank["0"], 100)
        self.assertEqual(self.player.highest_trophies, 100)

        self.update({
            "brawlersTrophies": {"0": 5},
            "brawlersTrophiesForRank": {"0": 5},
            "trophies": 5,
            "highest_trophies": 5,
        })
        self.player.battle_result = 0
        result = apply_battle_result_rewards(self.player, 0)
        self.assertEqual(result.rewards["milestonesRewardRank"], 10)

    def test_tutorial_and_invalid_rank_do_not_write_rewards(self):
        self.update({
            "tokensdoubler": 5,
            "gold": 100,
            "trophies": 0,
            "highest_trophies": 0,
        })
        self.player.tutorial = 1
        self.player.battle_result = 0
        result = apply_battle_result_rewards(self.player, 0)
        self.assertEqual(result.totaltokens, 0)
        self.assertEqual(self.player.trophies, 0)
        self.assertEqual(self.player.tokensdoubler, 5)
        self.assertEqual(self.reload().tokensdoubler, 5)

        self.player.tutorial = 2
        self.player.rank = 0
        with self.assertRaises(RewardError):
            apply_battle_result_rewards(self.player, 2)
        self.assertEqual(self.reload().trophies, 0)

    def test_full_battle_result_payloads_encode_after_real_reward_updates(self):
        cases = (
            (BattleResultMessage, 0, 6, 6, 20),
            (BattleResultShowdownMessage, 2, 10, 8, 0),
            (BattleResultDuoShowdownMessage, 5, 10, 7, 0),
        )
        for index, (message_class, mode, players, trophies, tokens) in enumerate(cases, 30):
            with self.subTest(mode=mode):
                player, _ = self.make_account(index, f"full-battle-{mode}")
                self.update({
                    "brawlBoxes": 0,
                    "trophies": 0,
                    "highest_trophies": 0,
                }, player)
                player.result = 16
                player.rank = 1
                player.battle_result = 0
                player.players = players
                player.team = 0
                for bot in range(1, 10):
                    setattr(player, f"bot{bot}", bot % 21)
                    setattr(player, f"bot{bot}_n", f"Bot {bot}")
                    setattr(player, f"bot{bot}_team", bot % 2)
                message = message_class(None, player)
                message.encode()
                self.assertGreater(len(message.buffer), 100)
                self.assertEqual(player.trophies, trophies)
                self.assertEqual(player.brawl_boxes, tokens)
                self.assertEqual(self.reload(player).trophies, trophies)

    def test_all_three_v13_encoders_call_the_pro_adapter(self):
        cases = (
            (BattleResultMessage, "Packets.Messages.Server.Battle.BattleResultMessage.apply_battle_result_rewards", 0),
            (BattleResultShowdownMessage, "Packets.Messages.Server.Battle.BattleResultShowdownMessage.apply_battle_result_rewards", 2),
            (BattleResultDuoShowdownMessage, "Packets.Messages.Server.Battle.BattleResultDuoShowdownMessage.apply_battle_result_rewards", 5),
        )
        for message_class, target, mode in cases:
            with self.subTest(mode=mode), patch(target, side_effect=StopIteration) as adapter:
                with self.assertRaises(StopIteration):
                    message_class(None, self.player).encode()
                adapter.assert_called_once_with(self.player, mode)


class MigrationAndHomeTests(AccountTestCase):
    def test_new_accounts_start_with_999_boxes_gems_and_trophies(self):
        self.assertEqual(Config.DEFAULT_SETTINGS["BrawlBoxTokens"], 999)
        self.assertEqual(Config.DEFAULT_SETTINGS["Gems"], 999)
        self.assertEqual(Config.DEFAULT_SETTINGS["Trophies"], 999)
        player, _ = self.make_account(90, "starting-999")
        self.assertEqual(player.brawl_boxes, 999)
        self.assertEqual(player.gems, 999)
        self.assertEqual(player.trophies, 999)
        self.assertEqual(player.highest_trophies, 999)
        loaded = self.reload(player)
        self.assertEqual(loaded.brawl_boxes, 999)
        self.assertEqual(loaded.gems, 999)
        self.assertEqual(loaded.trophies, 999)
        self.assertEqual(loaded.highest_trophies, 999)

    def test_invalid_power_points_and_trophy_position_are_repaired_in_sqlite(self):
        owner = SimpleNamespace(player=self.player)
        self.assertTrue(DataBase.replaceValues(owner, {
            "brawlersUpgradePoints": {"0": -80, "1": 1800, "2": 25},
            "leagueReward": 500,
        }))
        loaded = self.reload()
        self.assertEqual(loaded.brawlers_upgradium, {"0": 0, "1": 1410, "2": 25})
        self.assertEqual(loaded.trophy_road, 95)
        with closing(sqlite3.connect(self.database_path)) as connection:
            points, position = connection.execute(
                "SELECT brawlersUpgradePoints, leagueReward FROM players WHERE token = ?",
                (self.player.token,),
            ).fetchone()
        self.assertEqual(json.loads(points), {"0": 0, "1": 1410, "2": 25})
        self.assertEqual(position, 95)

    def test_zero_trophy_position_is_repaired_to_first_claim(self):
        owner = SimpleNamespace(player=self.player)
        self.assertTrue(DataBase.replaceValues(owner, {"leagueReward": 0}))
        loaded = self.reload()
        self.assertEqual(loaded.trophy_road, 1)
        with closing(sqlite3.connect(self.database_path)) as connection:
            position = connection.execute(
                "SELECT leagueReward FROM players WHERE token = ?",
                (self.player.token,),
            ).fetchone()[0]
        self.assertEqual(position, 1)

    def test_own_home_data_keeps_v13_conf_data_without_v12_milestones(self):
        self.player.battle_tokens = 200
        message = OwnHomeDataMessage(None, self.player)
        message.encode()
        gold_marker = b"".join(vint(value) for value in [3, 150, 400, 1200])
        offset = message.buffer.find(gold_marker)
        self.assertGreaterEqual(offset, 0)
        reader = BSMessageReader(message.buffer[offset + len(gold_marker):])
        self.assertEqual(
            [reader.read_Vint() for _ in range(6)],
            [0, 200, 20, 8640, 10, 5],
        )
        self.assertLess(len(message.buffer), 1000)

    def test_own_home_data_serializes_account_boxes_gems_and_resources(self):
        self.player.BrawlersUnlockedState = {"0": 1}
        self.player.brawlers_id = [0]
        self.player.card_unlock_id = [0]
        self.player.star_points = 12345
        self.player.brawl_boxes = 999
        self.player.gold = 100
        self.player.big_boxes = 0
        self.player.gems = 999
        self.player.player_experience = 77
        self.player.tutorial = 2
        self.player.brawlers_trophies = {"0": 12}
        self.player.brawlers_trophies_in_rank = {"0": 34}
        self.player.brawlers_upgradium = {"0": 56}
        self.player.Brawler_level = {"0": 7}
        self.player.Brawler_starPower = {"0": 76}
        self.player.progression["brawlerNewTag"] = {"0": 1}
        message = OwnHomeDataMessage(None, self.player)
        message.encode()

        resource_values = [23, 0, 12345, 5, 1, 999, 5, 8, 100, 5, 9, 0]
        resource_block = b"".join(vint(value) for value in resource_values)
        offset = message.buffer.rfind(resource_block)
        self.assertGreaterEqual(offset, 0)
        card_prefix = b"".join(vint(value) for value in [5, 23, 0, 1])
        self.assertEqual(
            message.buffer[offset - len(card_prefix):offset], card_prefix
        )
        expected_tail = resource_values
        expected_tail += [1, 16, 0, 12, 1, 16, 0, 34, 0]
        expected_tail += [1, 16, 0, 56, 1, 16, 0, 7]
        expected_tail += [0, 0]
        expected_tail += [999, 999, 77] + [0] * 7 + [2, 0]
        self.assertEqual(read_vints(message.buffer[offset:]), expected_tail)

    def test_legacy_39_column_database_is_migrated_without_data_loss(self):
                                                                            
        legacy_path = str(Path(self.temp_directory.name) / "legacy.db")
        schema = DataBase.PLAYER_SCHEMA.replace(
            ",\n            progression TEXT NOT NULL DEFAULT '{}'", ""
        )
        with closing(sqlite3.connect(legacy_path)) as connection:
            connection.executescript(schema)
            connection.execute(
                "INSERT INTO players(token, lowID, name, gold) VALUES (?,?,?,?)",
                ("legacy-token", 99, "Legacy", 123),
            )
            connection.commit()
        with patch.object(DataBase, "_database_path", lambda: legacy_path):
            player = Players(SimpleNamespace())
            player.token = "legacy-token"
            self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
            self.assertEqual((player.low_id, player.gold), (99, 123))
            self.assertEqual(player.progression, {})
            with closing(sqlite3.connect(legacy_path)) as connection:
                self.assertEqual(len(connection.execute("SELECT * FROM players").fetchone()), 40)


if __name__ == "__main__":
    unittest.main()
