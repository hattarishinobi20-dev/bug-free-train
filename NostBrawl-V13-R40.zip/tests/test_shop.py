import copy
import importlib.util
import json
import os
import random
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Logic.BillingService import BillingService
from Logic.BoxInventory import BoxInventory
from Logic.EventSlots import EventSlots
from Logic.Player import Players
from Logic.Rewards import RewardError, RewardTransaction
from Logic.ShopCatalog import ShopCatalog
from Logic.ShopService import ShopService
from Packets.Commands.Client.LogicClearShopTickersCommand import LogicClearShopTickersCommand
from Packets.Commands.Client.LogicPurchaseBoxCommand import LogicPurchaseBoxCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Server.LogicBuyItem import LogicBuyItem
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Billing.GoogleBillingRequestMessage import GoogleBillingRequestMessage
from Packets.Messages.Server.Billing.BillingRequestFailedMessage import BillingRequestFailedMessage
from Packets.Messages.Server.Billing.BuyBundleBillingPackResponseMessage import BuyBundleBillingPackResponseMessage
from Packets.Messages.Server.Billing.GoogleBillingProcessedByServerMessage import GoogleBillingProcessedByServerMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer
from test_own_home_data_wire import OwnHomeDataReader

NOW = 1700000000


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def packet_parts(packet):
    return (
        int.from_bytes(packet[:2], "big"),
        int.from_bytes(packet[2:5], "big"),
        packet[7:],
    )


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))


class ShopAccountTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        time_patch = patch("Logic.ShopService.time.time", return_value=NOW)
        time_patch.start()
        self.addCleanup(time_patch.stop)
        self.player, _ = self.make_account(1, "shop-token")

    def make_account(self, low_id, token):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = f"Shop {low_id}"
        DataBase.createAccount(SimpleNamespace(player=player))
        return player, token

    def reload(self, player=None):
        source = player or self.player
        loaded = Players(SimpleNamespace())
        loaded.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded

    def update(self, values):
        self.assertTrue(DataBase.replaceValues(SimpleNamespace(player=self.player), values))
        attributes = {
            "gems": "gems",
            "gold": "gold",
            "brawlBoxes": "brawl_boxes",
            "bigBoxes": "big_boxes",
            "tickets": "tickets",
            "tokensdoubler": "tokensdoubler",
            "UnlockedBrawlers": "BrawlersUnlockedState",
            "brawlersUpgradePoints": "brawlers_upgradium",
            "Brawler_starPower": "Brawler_starPower",
        }
        for column, value in values.items():
            if column in attributes:
                setattr(self.player, attributes[column], copy.deepcopy(value))

    def offer(self, **changes):
        result = {
            "key": "test",
            "items": [{"offerId": 1, "amount": 50, "value": 0, "target": None}],
            "currency": 0,
            "price": 10,
            "originalPrice": 10,
            "display": 0,
            "expiresAt": NOW + 3600,
            "seen": False,
            "purchased": False,
            "title": "",
            "daily": True,
        }
        result.update(changes)
        if "price" in changes and "originalPrice" not in changes:
            result["originalPrice"] = result["price"]
        return result

    def install(self, offers, player=None):
        player = player or self.player
        state = ShopService.get_state(player)
        state["offers"] = copy.deepcopy(offers)
        ShopService._save_state(player, state)
        return state

    def read_offers(self, reader):
        offers = []
        for _ in range(reader.v()):
            items = []
            for _ in range(reader.v()):
                offer_id, amount = reader.v(), reader.v()
                csv_id = reader.v()
                item_id = reader.v() if csv_id else -1
                value = reader.v()
                items.append((offer_id, amount, (csv_id, item_id), value))
            numeric = [reader.v() for _ in range(5)]
            purchased = reader.b()
            auxiliary = reader.v()
            daily = reader.b()
            original_price = reader.v()
            title = reader.s()
            offers.append({
                "items": items,
                "numeric": numeric,
                "purchased": purchased,
                "auxiliary": auxiliary,
                "daily": daily,
                "originalPrice": original_price,
                "title": title,
            })
        return offers

    def seek_offers(self, reader):
        [reader.v() for _ in range(2)]
        [reader.v() for _ in range(5)]
        reader.v(), reader.v()
        reader.v()
        reader.references()
        reader.references()
        reader.b()
        [reader.v() for _ in range(6)]
        reader.b()
        reader.v()
        reader.b()
        reader.v(), reader.v()
        [reader.b() for _ in range(4)]
        [reader.v() for _ in range(3)]
        reader.b()
        return reader.tell()


class ShopCatalogTests(ShopAccountTestCase):
    def test_csv_catalog_and_new_daily_config_are_complete(self):
        self.assertEqual(sorted(ShopCatalog.shop_items()), list(range(17)))
        self.assertEqual(len(ShopCatalog.billing_packages()), 11)
        config = ShopCatalog.daily_definitions()
        self.assertEqual(len(config["daily"]), 2)
        self.assertNotIn("rotatingBundles", config)
        for definition in config["daily"]:
            self.assertLessEqual(len(definition["items"]), 3)
            for item in definition["items"]:
                self.assertIn(item["offerId"], ShopCatalog.shop_items())
                if item["offerId"] == 0:
                    self.assertEqual(item["value"], 1)
                if item["offerId"] == 8:
                    self.assertEqual((item["amount"], item["value"]), (20, 40))
                    self.assertEqual(item["target"][0], 16)
        starter = ShopCatalog.billing_packages()["com.supercell.laser.starterpack1"]
        self.assertEqual(
            (starter["diamonds"], starter["bigBoxCount"], starter["xpLevelReq"]),
            (80, 1, 5),
        )

    def test_catalog_rejects_unsafe_free_box_and_hero_power_items(self):
        invalid_items = [
            {"offerId": 0, "amount": 1, "value": 0, "target": None},
            {"offerId": 8, "amount": 20, "value": 40, "target": None},
            {"offerId": 8, "amount": 20, "value": 0, "target": [16, 0]},
        ]
        for item in invalid_items:
            with self.subTest(item=item), self.assertRaises(ValueError):
                ShopCatalog.validate_item(item)

    def test_removed_shop_modules_stay_removed(self):
        for name in (
            "Logic.Shop",
            "Utils.OfferGenerator",
            "Entries.LogicGemOffer",
        ):
            with self.subTest(name=name):
                self.assertIsNone(importlib.util.find_spec(name))
        self.assertIs(packets[10151], GoogleBillingRequestMessage)


class ShopStateTests(ShopAccountTestCase):
    def test_daily_generation_is_stable_persistent_and_account_isolated(self):
        first = ShopService.get_state(self.player)
        self.assertEqual(len(first["offers"]), 2)
        self.assertEqual(first, ShopService.get_state(self.player))
        self.assertEqual(first, self.reload().progression["shop"])
        second, _ = self.make_account(2, "second-shop-token")
        second_state = ShopService.get_state(second)
        ShopService.clear_tickers(self.player)
        self.assertTrue(all(
            offer["seen"] for offer in self.reload().progression["shop"]["offers"]
        ))
        self.assertFalse(any(
            offer["seen"] for offer in self.reload(second).progression["shop"]["offers"]
        ))
        self.assertEqual(len(second_state["offers"]), 2)

    def test_new_day_resets_daily_offers_and_preserves_billing_history(self):
        state = ShopService.get_state(self.player)
        state["offers"][0]["purchased"] = True
        state["billing"]["transactions"]["abc"] = {"product": "pack"}
        ShopService._save_state(self.player, state)
        with patch("Logic.ShopService.time.time", return_value=NOW + 86400):
            refreshed = ShopService.get_state(self.player)
        self.assertNotEqual(refreshed["day"], state["day"])
        self.assertFalse(any(offer["purchased"] for offer in refreshed["offers"]))
        self.assertEqual(refreshed["billing"]["transactions"]["abc"], {"product": "pack"})
        self.assertEqual(refreshed, self.reload().progression["shop"])

    def test_expired_offer_is_removed_without_touching_other_offers(self):
        state = self.install([
            self.offer(key="expired", expiresAt=NOW - 1),
            self.offer(key="active", expiresAt=NOW + 100),
        ])
        self.assertEqual(len(state["offers"]), 2)
        current = ShopService.get_state(self.player)
        self.assertEqual([offer["key"] for offer in current["offers"]], ["active"])
        self.assertEqual(current, self.reload().progression["shop"])

    def test_previous_state_is_relocated_without_losing_history(self):
        state = ShopService.get_state(self.player)
        state["offers"][0]["purchased"] = True
        state["offers"][0]["seen"] = True
        state["billing"]["transactions"]["receipt"] = {"product": "pack"}
        state["billing"]["bundles"]["starter"] = {"quantity": 1}
        progression = copy.deepcopy(self.player.progression)
        progression.pop(ShopService.STATE_KEY, None)
        progression["previous_shop"] = copy.deepcopy(state)
        self.assertTrue(DataBase.replaceValues(
            SimpleNamespace(player=self.player), {"progression": progression}
        ))
        self.player.progression = progression
        migrated = ShopService.get_state(self.player)
        self.assertTrue(migrated["offers"][0]["purchased"])
        self.assertTrue(migrated["offers"][0]["seen"])
        self.assertEqual(
            migrated["billing"]["transactions"]["receipt"], {"product": "pack"}
        )
        loaded = self.reload()
        self.assertNotIn("previous_shop", loaded.progression)
        self.assertEqual(loaded.progression[ShopService.STATE_KEY], migrated)
        progression = copy.deepcopy(loaded.progression)
        progression["previous_shop"] = copy.deepcopy(state)
        progression["previous_shop"]["offers"][0]["purchased"] = False
        self.assertTrue(DataBase.replaceValues(
            SimpleNamespace(player=loaded), {"progression": progression}
        ))
        loaded.progression = progression
        canonical = ShopService.get_state(loaded)
        self.assertTrue(canonical["offers"][0]["purchased"])
        reloaded = self.reload()
        self.assertNotIn("previous_shop", reloaded.progression)
        self.assertEqual(reloaded.progression[ShopService.STATE_KEY], canonical)

    def test_clear_tickers_decoder_and_persistence(self):
        self.install([self.offer()])
        payload = b"".join(vint(0) for _ in range(4))
        payload += b"".join(vint(value) for value in (7, 8, 9)) + b"x"
        command = LogicClearShopTickersCommand(None, self.player, payload)
        command.decode()
        self.assertEqual(command.read(), b"x")
        result = command.process()
        self.assertEqual(result, {"cleared": True, "count": 1})
        self.assertTrue(self.reload().progression["shop"]["offers"][0]["seen"])
        self.assertEqual(command.process(), {"cleared": False, "count": 1})


class ShopPurchaseTests(ShopAccountTestCase):
    def test_coin_offer_charges_once_and_replay_is_persistent(self):
        self.update({"gems": 100, "gold": 100})
        self.install([self.offer()])
        result = ShopService.purchase(self.player, 0, rng=random.Random(1))
        self.assertEqual(result["rewards"], [{"type": 1, "amount": 50}])
        self.assertEqual(result["storedBoxes"], [])
        self.assertEqual((self.player.gems, self.player.gold), (90, 150))
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual((self.player.gems, self.player.gold), (90, 150))
        loaded = self.reload()
        self.assertEqual((loaded.gems, loaded.gold), (90, 150))
        self.assertTrue(loaded.progression["shop"]["offers"][0]["purchased"])
        with self.assertRaises(RewardError):
            ShopService.purchase(loaded, 0)
        self.assertEqual((loaded.gems, loaded.gold), (90, 150))

    def test_bundle_applies_three_items_in_one_transaction(self):
        self.update({"gems": 100, "gold": 10, "tickets": 0, "tokensdoubler": 0})
        self.install([self.offer(
            key="bundle",
            items=[
                {"offerId": 1, "amount": 50, "value": 0, "target": None},
                {"offerId": 9, "amount": 500, "value": 0, "target": None},
                {"offerId": 7, "amount": 2, "value": 0, "target": None},
            ],
            price=25,
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(len(result["rewards"]), 3)
        self.assertEqual(result["storedBoxes"], [])
        self.assertEqual(self.player.gems, 75)
        self.assertEqual(self.player.gold, 60)
        self.assertEqual(self.player.tokensdoubler, 500)
        self.assertEqual(self.player.tickets, 2)
        loaded = self.reload()
        self.assertEqual((loaded.gems, loaded.gold, loaded.tokensdoubler, loaded.tickets), (75, 60, 500, 2))

    def test_insufficient_funds_and_invalid_reward_are_atomic(self):
        self.update({"gems": 100, "gold": 100})
        self.install([self.offer(price=101)])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual((self.player.gems, self.player.gold), (100, 100))
        self.install([self.offer(
            price=10,
            items=[{"offerId": 11, "amount": 1, "value": 0, "target": None}],
        )])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual((self.player.gems, self.player.gold), (100, 100))
        stored = self.reload().progression["shop"]["offers"][0]
        self.assertFalse(stored["purchased"])

    def test_box_offer_ids_store_the_nost_box_types_without_opening(self):
        native = {10: ("brawl_boxes", 100), 12: ("big_boxes", 10)}
        for offer_id, expected in ((0, 10), (6, 10), (10, 11), (14, 12), (15, 10)):
            with self.subTest(offer_id=offer_id):
                self.player, self.owner = self.make_account(
                    1000 + offer_id, f"box-offer-{offer_id}"
                )
                self.update({"brawlBoxes": 0})
                before = BoxInventory.count(self.player, expected)
                balance = None
                if expected in native:
                    attribute, cost = native[expected]
                    balance = getattr(self.player, attribute)
                self.install([self.offer(
                    price=0,
                    items=[{
                        "offerId": offer_id,
                        "amount": 3,
                        "value": 1 if offer_id == 0 else 0,
                        "target": None,
                    }],
                )])
                with patch("Logic.BoxService.generate_rewards") as generate:
                    result = ShopService.purchase(self.player, 0, rng=random.Random(1))
                generate.assert_not_called()
                self.assertEqual(result["rewards"], [])
                self.assertEqual(result["storedBoxes"], [{
                    "boxType": expected, "amount": 3,
                }])
                self.assertEqual(BoxInventory.count(self.player, expected), before + 3)
                loaded = self.reload()
                self.assertEqual(BoxInventory.count(loaded, expected), before + 3)
                if expected in native:
                    self.assertEqual(getattr(loaded, attribute), balance + 3 * cost)
                    self.assertEqual(loaded.progression["boxInventory"]["boxes"][str(expected)], 0)
                else:
                    self.assertEqual(loaded.progression["boxInventory"]["boxes"][str(expected)], 3)

    def test_mega_boxes_and_thousand_power_points_are_fully_delivered(self):
        self.update({"gems": 500, "brawlersUpgradePoints": {"0": 0}})
        self.install([self.offer(
            key="mega-and-power",
            price=100,
            items=[
                {"offerId": 10, "amount": 2, "value": 0, "target": None},
                {"offerId": 8, "amount": 1000, "value": 2000, "target": [16, 0]},
            ],
        )])
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = ShopService.purchase(self.player, 0)
        generate.assert_not_called()
        self.assertEqual(self.player.gems, 400)
        self.assertEqual(self.player.brawlers_upgradium["0"], 1000)
        self.assertEqual(BoxInventory.count(self.player, 11), 2)
        self.assertEqual(result["storedBoxes"], [{"boxType": 11, "amount": 2}])
        self.assertEqual(result["rewards"], [{
            "type": 5, "amount": 1000, "brawler": 0,
        }])
        loaded = self.reload()
        self.assertEqual(loaded.gems, 400)
        self.assertEqual(loaded.brawlers_upgradium["0"], 1000)
        self.assertEqual(BoxInventory.count(loaded, 11), 2)
        with self.assertRaises(RewardError):
            ShopService.purchase(loaded, 0)
        self.assertEqual(BoxInventory.count(loaded, 11), 2)
        self.assertEqual(loaded.brawlers_upgradium["0"], 1000)

    def test_purchase_command_aggregates_items_and_never_opens_the_box(self):
        self.update({"gems": 500, "brawlersUpgradePoints": {"0": 0}})
        self.install([self.offer(
            price=100,
            items=[
                {"offerId": 10, "amount": 1, "value": 0, "target": None},
                {"offerId": 8, "amount": 1000, "value": 2000, "target": [16, 0]},
            ],
        )])
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = 0
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = command.process()
        generate.assert_not_called()
        self.assertEqual(len(client.packets), 1)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 24111)
        reader = BSMessageReader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 1])
        self.assertEqual(reader.read_Vint(), 1000)
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (16, 0))
        self.assertEqual([reader.read_Vint() for _ in range(3)], [6, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(13)], [0] * 13)
        self.assertEqual(reader.read(), b"")
        self.assertEqual(result["storedBoxes"], [{"boxType": 11, "amount": 1}])

    def test_box_only_mega_purchase_waits_for_explicit_opening(self):
        self.install([self.offer(
            price=0,
            items=[{"offerId": 10, "amount": 4, "value": 0, "target": None}],
        )])
        client = CaptureClient()
        command = LogicPurchaseOfferCommand(client, self.player, b"")
        command.offer_index = 0
        result = command.process()
        self.assertEqual(client.packets, [])
        self.assertEqual(result["responses"], [])
        self.assertEqual(BoxInventory.count(self.player, 11), 4)
        stored = ShopService.get_state(self.player)
        self.assertEqual(stored["offers"][-1]["storedBox"], 11)
        self.assertNotIn("storedBox", self.reload().progression["shop"]["offers"][-1])

    def test_mixed_bundle_stores_then_opens_mega_box_with_native_v13_wire(self):
        self.update({"gems": 500, "gold": 0, "brawlBoxes": 0, "tokensdoubler": 0})
        self.install([self.offer(
            key="resource-bundle",
            price=99,
            items=[
                {"offerId": 1, "amount": 500, "value": 0, "target": None},
                {"offerId": 9, "amount": 500, "value": 0, "target": None},
                {"offerId": 10, "amount": 1, "value": 0, "target": None},
            ],
        )])
        purchase_client = CaptureClient()
        purchase = LogicPurchaseOfferCommand(purchase_client, self.player, b"")
        purchase.offer_index = 0
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = purchase.process()
        generate.assert_not_called()
        self.assertEqual(result["storedBoxes"], [{"boxType": 11, "amount": 1}])
        self.assertEqual((self.player.gems, self.player.gold, self.player.tokensdoubler), (401, 500, 500))
        self.assertEqual(BoxInventory.count(self.player, 11), 1)
        self.assertEqual(len(purchase_client.packets), 1)
        packet_id, _, payload = packet_parts(purchase_client.packets[0])
        self.assertEqual(packet_id, 24111)
        reader = BSMessageReader(payload)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 2])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [500, 0, 7, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [500, 0, 2, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(13)], [0] * 13)
        self.assertEqual(reader.read(), b"")

        loaded = self.reload()
        self.assertEqual(BoxInventory.count(loaded, 11), 1)
        open_client = CaptureClient()
        opening = LogicPurchaseBoxCommand(open_client, loaded, b"")
        opening.box_id = 3
        native_rewards = [
            {"name": "Coins", "amount": 172, "target": 0},
            {"name": "UpgradePoints", "amount": 50, "target": 0},
            {"name": "Brawler", "amount": 4, "target": 0},
        ]
        with patch("Logic.BoxService.generate_rewards", return_value=native_rewards):
            opened = opening.process()
        self.assertEqual(opened["openingSource"], "inventory")
        self.assertEqual(BoxInventory.count(loaded, 11), 0)
        self.assertEqual((loaded.gems, loaded.gold, loaded.tokensdoubler), (401, 672, 500))
        packet_id, _, payload = packet_parts(open_client.packets[0])
        self.assertEqual(packet_id, 24111)
        self.assertEqual(payload, bytes.fromhex(
            "8b030b010003ac020007000032100006000001100401000000"
        ))
        persisted = self.reload(loaded)
        self.assertEqual((persisted.gems, persisted.gold, persisted.tokensdoubler), (401, 672, 500))
        self.assertEqual(BoxInventory.count(persisted, 11), 0)
        self.assertEqual(persisted.BrawlersUnlockedState["4"], 1)

    def test_shop_power_points_never_silently_truncate_or_partially_commit(self):
        self.update({"gems": 500, "brawlersUpgradePoints": {"0": 500}})
        self.install([self.offer(
            price=100,
            items=[
                {"offerId": 10, "amount": 1, "value": 0, "target": None},
                {"offerId": 8, "amount": 1000, "value": 2000, "target": [16, 0]},
            ],
        )])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual(self.player.gems, 500)
        self.assertEqual(self.player.brawlers_upgradium["0"], 500)
        self.assertEqual(BoxInventory.count(self.player, 11), 0)
        loaded = self.reload()
        self.assertEqual(loaded.gems, 500)
        self.assertEqual(loaded.brawlers_upgradium["0"], 500)
        self.assertFalse(loaded.progression["shop"]["offers"][0]["purchased"])

    def test_power_points_require_a_valid_unlocked_data_reference(self):
        self.update({"gems": 100})
        item = {"offerId": 8, "amount": 25, "value": 50, "target": [16, 1]}
        self.install([self.offer(items=[item])])
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 0)
        self.assertEqual(self.player.gems, 100)
        states = dict(self.player.BrawlersUnlockedState)
        states["1"] = 1
        self.update({"UnlockedBrawlers": states})
        result = ShopService.purchase(self.player, 0, selected_brawler=2)
        self.assertEqual(result["rewards"][0], {
            "type": 5, "amount": 25, "brawler": 1,
        })
        self.assertEqual(self.player.brawlers_upgradium["1"], 25)
        self.assertNotEqual(self.player.brawlers_upgradium.get("2"), 25)
        self.assertEqual(self.reload().brawlers_upgradium["1"], 25)

    def test_wildcard_power_uses_the_selected_brawler_and_type_nine(self):
        self.update({"gems": 100})
        states = dict(self.player.BrawlersUnlockedState)
        states["1"] = 1
        self.update({"UnlockedBrawlers": states})
        self.install([self.offer(
            items=[{"offerId": 12, "amount": 25, "value": 0, "target": None}],
        )])
        result = ShopService.purchase(self.player, 0, selected_brawler=1)
        self.assertEqual(result["rewards"], [{
            "type": 9, "amount": 25, "brawler": 1,
        }])
        self.assertEqual(self.reload().brawlers_upgradium["1"], 25)

    def test_brawler_default_skin_nondefault_skin_and_star_power(self):
        self.update({"gems": 100})
        self.install([self.offer(
            price=0,
            items=[{"offerId": 3, "amount": 1, "value": 0, "target": [16, 1]}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"][0]["type"], 6)
        self.assertEqual(self.player.BrawlersUnlockedState["1"], 1)
        default_skin = next(
            skin for skin in Skins.get_skins_id()
            if Skins.getBrawler(skin) == 2 and Skins.getIsDefaultSkin(skin)
        )
        self.install([self.offer(
            price=0,
            items=[{"offerId": 4, "amount": 1, "value": default_skin, "target": None}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"][0]["brawler"], 2)
        self.assertEqual(self.player.BrawlersUnlockedState["2"], 1)
        self.install([self.offer(
            price=0,
            items=[{"offerId": 4, "amount": 1, "value": 0, "target": [29, 29]}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"], [{
            "type": 7, "amount": 1, "skin": 29,
        }])
        self.assertIn(29, self.player.UnlockedSkins["Skins"])
        star_power = Cards.get_brawler_star_power(0)
        self.install([self.offer(
            price=0,
            items=[{"offerId": 5, "amount": 1, "value": 0, "target": [16, 0]}],
        )])
        result = ShopService.purchase(self.player, 0)
        self.assertEqual(result["rewards"], [{
            "type": 8, "amount": 1, "brawler": 0,
        }])
        self.assertEqual(self.player.Brawler_starPower["0"], star_power)
        loaded = self.reload()
        self.assertEqual(loaded.BrawlersUnlockedState["1"], 1)
        self.assertEqual(loaded.BrawlersUnlockedState["2"], 1)
        self.assertIn(29, loaded.UnlockedSkins["Skins"])
        self.assertEqual(loaded.Brawler_starPower["0"], star_power)

    def test_purchase_command_always_reads_nullable_data_reference(self):
        null_payload = b"".join(vint(0) for _ in range(5)) + vint(0) + b"x"
        null_command = LogicPurchaseOfferCommand(None, self.player, null_payload)
        null_command.decode()
        self.assertEqual(null_command.target_reference, (0, -1))
        self.assertEqual(null_command.read(), b"x")
        target_payload = b"".join(vint(0) for _ in range(5))
        target_payload += vint(16) + vint(1) + b"x"
        target_command = LogicPurchaseOfferCommand(None, self.player, target_payload)
        target_command.decode()
        self.assertEqual(target_command.target_reference, (16, 1))
        self.assertEqual(target_command.read(), b"x")

    def test_buy_item_keeps_three_rewards_and_thirteen_tail_fields(self):
        command = LogicBuyItem(None, self.player, [
            {"type": 1, "amount": 50},
            {"type": 5, "amount": 25, "brawler": 1},
            {"type": 7, "amount": 1, "skin": 29},
        ])
        command.encode()
        reader = BSMessageReader(command.buffer)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [203, 0, 1, 100, 3])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [50, 0, 7, 0, 0])
        self.assertEqual([reader.read_Vint() for _ in range(5)], [25, 16, 1, 6, 0])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual([reader.read_Vint() for _ in range(5)], [1, 0, 9, 29, 29])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual([reader.read_Vint() for _ in range(13)], [0] * 13)
        self.assertEqual(reader.read(), b"")


class ShopHomeWireTests(ShopAccountTestCase):
    def encode_offers(self):
        writer = OwnHomeDataMessage(None, self.player)
        ShopService.encode_home(writer, self.player, NOW)
        reader = OwnHomeDataReader(writer.buffer)
        offers = self.read_offers(reader)
        self.assertEqual(reader.read(), b"")
        return offers

    def test_generated_offers_use_amount_value_and_neutral_bundle_fields(self):
        offers = self.encode_offers()
        self.assertEqual(len(offers), 2)
        self.assertEqual(offers[0]["items"], [(0, 1, (0, -1), 1)])
        power = offers[1]
        power_item = power["items"][0]
        self.assertEqual((power_item[0], power_item[1], power_item[3]), (8, 20, 40))
        self.assertEqual(power_item[2][0], 16)
        self.assertIn(power_item[2][1], Characters.get_brawlers_id())
        self.assertEqual(power["numeric"][:2], [1, 40])
        self.assertEqual([offer["originalPrice"] for offer in offers], [0, 0])
        self.assertEqual([offer["daily"] for offer in offers], [True, True])
        for offer in offers:
            self.assertEqual(offer["numeric"][3:], [0, 100])
            self.assertFalse(offer["purchased"])
            self.assertEqual(offer["auxiliary"], 0)

    def test_diagnostic_log_does_not_change_home_bytes(self):
        with patch("Logic.ShopService.Config.GetValue", return_value={
            "ShowPacketsInLog": False,
        }), patch("builtins.print") as disabled_log:
            expected = self.encode_offers()
        disabled_log.assert_not_called()
        with patch("Logic.ShopService.Config.GetValue", return_value={
            "ShowPacketsInLog": True,
        }), patch("builtins.print") as enabled_log:
            actual = self.encode_offers()
        self.assertEqual(actual, expected)
        lines = [call.args[0] for call in enabled_log.call_args_list]
        self.assertEqual(len(lines), 3)
        self.assertIn("ShopState account=1", lines[0])
        self.assertIn("count=2", lines[0])
        payloads = [
            json.loads(line.split("ShopOffer ", 1)[1])
            for line in lines[1:]
        ]
        self.assertEqual([payload["index"] for payload in payloads], [0, 1])
        self.assertEqual(payloads[0]["items"], [{
            "offerId": 0, "amount": 1, "value": 1, "target": None,
        }])
        self.assertEqual(payloads[1]["currency"], 1)
        self.assertEqual(payloads[1]["cost"], 40)
        self.assertEqual(payloads[1]["timer"], payloads[0]["timer"])
        self.assertEqual([payload["daily"] for payload in payloads], [True, True])
        for payload in payloads:
            self.assertEqual(payload["percentage"], 100)
            self.assertEqual(payload["auxiliary"], 0)
            self.assertEqual(payload["newTag"], 0)
            self.assertFalse(payload["purchased"])

    def test_clear_tickers_changes_only_new_tag_state(self):
        self.install([self.offer(seen=False, purchased=True, daily=False, display=1)])
        before = self.encode_offers()
        ShopService.clear_tickers(self.player, NOW)
        after = self.encode_offers()
        self.assertEqual(before[0]["numeric"][:3], after[0]["numeric"][:3])
        self.assertEqual((before[0]["numeric"][3], after[0]["numeric"][3]), (0, 1))
        self.assertEqual(before[0]["numeric"][4], after[0]["numeric"][4])
        for key in ("items", "purchased", "auxiliary", "daily", "originalPrice", "title"):
            self.assertEqual(before[0][key], after[0][key])

    def test_r28_state_encodes_without_resetting_purchases(self):
        state = ShopService.get_state(self.player, NOW)
        state["offers"][1].update({
            "seen": True,
            "purchased": True,
            "daily": True,
            "reroll": 2,
            "claim": 3,
        })
        ShopService._save_state(self.player, state)
        offers = self.encode_offers()
        decoded = offers[1]
        self.assertEqual(len(offers), 2)
        self.assertEqual(decoded["items"][0][0], 8)
        self.assertEqual(decoded["items"][0][1], 20)
        self.assertEqual(decoded["items"][0][3], 40)
        self.assertEqual(decoded["numeric"][3:], [1, 100])
        self.assertTrue(decoded["purchased"])
        self.assertEqual(decoded["auxiliary"], 0)
        self.assertTrue(decoded["daily"])
        self.assertEqual(decoded["originalPrice"], 0)
        self.assertTrue(self.reload().progression["shop"]["offers"][1]["purchased"])

    def test_legacy_free_box_and_null_hero_power_migrate_without_replays(self):
        state = ShopService.get_state(self.player, NOW)
        state["offers"][0]["items"][0]["value"] = 0
        state["offers"][0]["purchased"] = True
        state["offers"][1]["purchased"] = True
        state["offers"][1].update({
            "items": [{"offerId": 8, "amount": 200, "value": 0, "target": None}],
            "currency": 0,
            "price": 30,
            "originalPrice": 40,
            "seen": True,
            "purchased": True,
            "reroll": 2,
            "claim": 3,
        })
        state["billing"]["transactions"]["legacy"] = {"product": "pack"}
        ShopService._save_state(self.player, state)
        offers = self.encode_offers()
        self.assertEqual(offers[0]["items"], [(0, 1, (0, -1), 1)])
        power = offers[1]
        self.assertEqual(power["items"][0][:2], (8, 20))
        self.assertEqual(power["items"][0][2][0], 16)
        self.assertEqual(power["items"][0][3], 40)
        self.assertEqual(power["numeric"][:2], [1, 40])
        for index in (0, 1):
            self.assertTrue(offers[index]["purchased"])
        stored = self.reload().progression["shop"]
        self.assertNotIn("reroll", stored["offers"][1])
        self.assertNotIn("claim", stored["offers"][1])
        self.assertEqual(stored["billing"]["transactions"]["legacy"], {"product": "pack"})
        with self.assertRaises(RewardError):
            ShopService.purchase(self.player, 1)

    def test_real_offer_vector_preserves_every_following_home_byte(self):
        offer = self.offer(
            title="BUNDLE",
            seen=True,
            purchased=True,
            daily=False,
            display=1,
            originalPrice=20,
            items=[{"offerId": 8, "amount": 25, "value": 7, "target": [16, 1]}],
        )
        self.install([offer])
        with patch.object(EventSlots, "Timer", lambda self: 49020):
            real_message = OwnHomeDataMessage(None, self.player)
            real_message.encode()
            with patch(
                "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
                lambda writer, player: writer.v(0),
            ):
                empty_message = OwnHomeDataMessage(None, self.player)
                empty_message.encode()
        reader = OwnHomeDataReader(real_message.buffer)
        offer_start = self.seek_offers(reader)
        offers = self.read_offers(reader)
        offer_end = reader.tell()
        self.assertEqual(len(offers), 1)
        decoded = offers[0]
        self.assertEqual(decoded["items"], [(8, 25, (16, 1), 7)])
        self.assertEqual(decoded["numeric"], [0, 10, 3600, 1, 100])
        self.assertTrue(decoded["purchased"])
        self.assertEqual(decoded["auxiliary"], 0)
        self.assertFalse(decoded["daily"])
        self.assertEqual(decoded["originalPrice"], 20)
        self.assertEqual(decoded["title"], "BUNDLE")
        self.assertEqual(
            empty_message.buffer,
            real_message.buffer[:offer_start] + b"\x00" + real_message.buffer[offer_end:],
        )
        self.assertEqual([reader.v() for _ in range(6)], [0] * 6)
        self.assertEqual((reader.v(), reader.v()), (16, 0))

    def test_offer_matches_independent_lib_golden_bytes(self):
        self.install([self.offer(
            title="A",
            expiresAt=NOW + 63,
            seen=False,
            purchased=True,
            daily=True,
        )])
        message = OwnHomeDataMessage(None, self.player)
        with patch.object(EventSlots, "Timer", lambda self: 49020):
            message.encode()
        reader = OwnHomeDataReader(message.buffer)
        offer_start = self.seek_offers(reader)
        decoded = self.read_offers(reader)[0]
        offer_end = reader.tell()
        self.assertEqual(
            message.buffer[offer_start:offer_end].hex(),
            "010101320000000a3f00a401010001000000000141",
        )
        self.assertEqual(decoded["numeric"], [0, 10, 63, 0, 100])
        self.assertTrue(decoded["purchased"])
        self.assertTrue(decoded["daily"])
        self.assertEqual(decoded["originalPrice"], 0)
        self.assertEqual(decoded["title"], "A")
        self.assertEqual([reader.v() for _ in range(6)], [0] * 6)
        self.assertEqual((reader.v(), reader.v()), (16, 0))

    def test_null_item_reference_occupies_exactly_one_vint(self):
        self.install([self.offer(title="")])
        message = OwnHomeDataMessage(None, self.player)
        with patch.object(EventSlots, "Timer", lambda self: 49020):
            message.encode()
        reader = OwnHomeDataReader(message.buffer)
        self.seek_offers(reader)
        decoded = self.read_offers(reader)[0]
        self.assertEqual(decoded["items"], [(1, 50, (0, -1), 0)])
        self.assertEqual([reader.v() for _ in range(6)], [0] * 6)


class BillingTests(ShopAccountTestCase):
    def values(self, product, token):
        return [product, token, "", "", "", ""]

    def request(self, values):
        writer = Writer(None)
        for value in values:
            writer.writeString(value)
        client = CaptureClient()
        message = GoogleBillingRequestMessage(client, self.player, writer.buffer)
        message.decode()
        self.assertEqual(message.values, values)
        self.assertEqual(message.read(), b"")
        result = message.process()
        return client, result

    def test_gem_pack_response_and_distinct_transactions(self):
        self.update({"gems": 0})
        values = self.values("com.supercell.laser.gempack0", "token-1")
        client, result = self.request(values)
        self.assertTrue(result["accepted"])
        self.assertEqual(self.player.gems, 30)
        self.assertEqual(len(client.packets), 2)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 20152)
        reader = BSMessageReader(payload)
        self.assertEqual(reader.read_string(), "com.supercell.laser.gempack0")
        self.assertEqual(len(reader.read_string()), 64)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read(), b"")
        replay_client, replay = self.request(values)
        self.assertFalse(replay["accepted"])
        self.assertEqual(packet_parts(replay_client.packets[0])[0], 20121)
        self.assertEqual(len(replay_client.packets), 1)
        self.assertEqual(self.player.gems, 30)
        other_client, other = self.request(self.values(
            "com.supercell.laser.gempack0", "token-2"
        ))
        self.assertTrue(other["accepted"])
        self.assertEqual(self.player.gems, 60)
        self.assertEqual(self.reload().gems, 60)
        self.assertEqual(len(other_client.packets), 2)

    def test_starter_pack_uses_bundle_response_and_csv_box_count(self):
        self.update({"gems": 0})
        self.player.experience_level = 35
        values = self.values("com.supercell.laser.starterpack1", "starter-1")
        with patch("Logic.BoxService.generate_rewards") as generate:
            client, result = self.request(values)
        generate.assert_not_called()
        self.assertTrue(result["accepted"])
        self.assertEqual(self.player.gems, 80)
        self.assertEqual(len(client.packets), 3)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 28363)
        reader = BSMessageReader(payload)
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (2, 1))
        self.assertEqual(reader.read(), b"")
        item_payload = packet_parts(client.packets[1])[2]
        self.assertEqual(BSMessageReader(item_payload).read_Vint(), 203)
        resource = BSMessageReader(packet_parts(client.packets[2])[2])
        self.assertEqual(
            [resource.read_Vint() for _ in range(8)],
            [207, 5000009, 10, 0, 0, 0, 0, 0],
        )
        self.assertEqual(resource.read(), b"")
        loaded = self.reload()
        self.assertEqual(loaded.gems, 80)
        self.assertEqual(BoxInventory.count(loaded, 12), 1)
        self.assertEqual(BoxInventory.count(loaded, 11), 0)
        bundles = loaded.progression["shop"]["billing"]["bundles"]
        self.assertIn("com.supercell.laser.starterpack1", bundles)
        replay_client, replay = self.request(self.values(
            "com.supercell.laser.starterpack1", "starter-2"
        ))
        self.assertFalse(replay["accepted"])
        self.assertEqual(packet_parts(replay_client.packets[0])[0], 20121)
        self.assertEqual(self.player.gems, 80)

    def test_xmas_bundle_uses_type_three_and_two_csv_boxes(self):
        self.update({"gems": 0})
        with patch("Logic.BoxService.generate_rewards") as generate:
            result = BillingService.purchase(self.player, self.values(
                "com.supercell.laser.xmas2018pack", "xmas-1"
            ))
        generate.assert_not_called()
        self.assertTrue(result["isBundle"])
        self.assertEqual(result["package"]["type"], 3)
        self.assertEqual(result["package"]["starterPackNumber"], 0)
        self.assertEqual(result["package"]["bigBoxCount"], 2)
        self.assertEqual(self.player.gems, 170)
        self.assertEqual(result["rewards"], [{"type": 2, "amount": 170}])
        self.assertEqual(result["storedBoxes"], [{"boxType": 12, "amount": 2}])
        self.assertEqual(result["responses"][-1], {
            "kind": "resource", "resource": 5000009, "amount": 20,
        })
        loaded = self.reload()
        self.assertEqual(loaded.gems, 170)
        self.assertEqual(BoxInventory.count(loaded, 12), 2)
        self.assertEqual(BoxInventory.count(loaded, 11), 0)

    def test_level_requirement_and_unknown_product_do_not_change_economy(self):
        self.update({"gems": 12})
        self.player.experience_level = 0
        with self.assertRaises(RewardError):
            BillingService.purchase(self.player, self.values(
                "com.supercell.laser.starterpack2", "locked"
            ))
        self.assertEqual(self.player.gems, 12)
        client, result = self.request(self.values("unknown.product", "unknown"))
        self.assertFalse(result["accepted"])
        self.assertEqual(self.player.gems, 12)
        packet_id, _, payload = packet_parts(client.packets[0])
        self.assertEqual(packet_id, 20121)
        reader = BSMessageReader(payload)
        self.assertEqual(reader.read_int(), 1)
        self.assertTrue(reader.read_string())
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read(), b"")
        self.assertEqual(self.reload().gems, 12)

    def test_billing_response_encoders_match_txt_primitive_types(self):
        processed = GoogleBillingProcessedByServerMessage(None, self.player, "p", "t", 0)
        processed.encode()
        reader = BSMessageReader(processed.buffer)
        self.assertEqual((reader.read_string(), reader.read_string(), reader.read_int()), ("p", "t", 0))
        self.assertEqual(reader.read(), b"")
        bundle = BuyBundleBillingPackResponseMessage(None, self.player, 3, 0)
        bundle.encode()
        self.assertEqual(bundle.buffer, vint(3) + vint(0))
        failed = BillingRequestFailedMessage(None, self.player, "erro", 1)
        failed.encode()
        reader = BSMessageReader(failed.buffer)
        self.assertEqual((reader.read_int(), reader.read_string(), reader.read_int()), (1, "erro", 0))
        self.assertEqual(reader.read(), b"")


if __name__ == "__main__":
    unittest.main()
