import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic.EventRotation import EventRotation
from Logic.GameRoomService import GameRoomError, GameRoomService
from Logic.MessageValidation import read_data_reference
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Gameroom.TeamChangeMemberSettingsMessage import TeamChangeMemberSettingsMessage
from Packets.Messages.Client.Gameroom.TeamChatMessage import TeamChatMessage
from Packets.Messages.Client.Gameroom.TeamCreateMessage import TeamCreateMessage
from Packets.Messages.Client.Home.GoHomeFromOfflinePractiseMessage import GoHomeFromOfflinePractiseMessage
from Packets.Messages.Client.Gameroom.TeamJoinMessage import TeamJoinMessage
from Packets.Messages.Client.Gameroom.TeamKickMessage import TeamKickMessage
from Packets.Messages.Client.Gameroom.TeamLeaveMessage import TeamLeaveMessage
from Packets.Messages.Client.Gameroom.TeamMemberStatusMessage import TeamMemberStatusMessage
from Packets.Messages.Client.Gameroom.TeamPostAdMessage import TeamPostAdMessage
from Packets.Messages.Client.Gameroom.TeamSetMemberReadyMessage import TeamSetMemberReadyMessage
from Packets.Messages.Client.Gameroom.TeamSetRankedLocationMessage import TeamSetRankedLocationMessage
from Packets.Messages.Client.Gameroom.TeamToggleMemberSideMessage import TeamToggleMemberSideMessage
from Packets.Messages.Client.Gameroom.TeamTogglePractiseMessage import TeamTogglePractiseMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))

    def payload(self, index=-1):
        packet = self.packets[index]
        self.message_id = int.from_bytes(packet[:2], "big")
        self.message_length = int.from_bytes(packet[2:5], "big")
        if self.message_length != len(packet) - 7:
            raise AssertionError("Invalid packet length")
        return packet[7:]


def payload(*values, boolean=None, data_reference=None, text=None, ints=()):
    writer = Writer(None)
    for value in values:
        writer.writeVint(value)
    if data_reference is not None:
        if data_reference[0]:
            writer.writeScId(*data_reference)
        else:
            writer.writeVint(0)
    if boolean is not None:
        writer.writeBoolean(boolean)
    if ints:
        for value in ints:
            writer.writeInt(value)
    if text is not None:
        writer.writeString(text)
    return writer.buffer


class GameRoomTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.players = [self.make_account(index) for index in range(1, 4)]

    def make_account(self, low_id):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = "room-token-%d" % low_id
        player.name = "Room %d" % low_id
        player.brawler_id = 0
        player.skin_id = 0
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def reload(self, source):
        player = Players(SimpleNamespace())
        player.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
        return player

    def test_factory_uses_native_room_command_ids(self):
        self.assertIs(packets[14351], TeamJoinMessage)
        self.assertIs(packets[14356], TeamTogglePractiseMessage)
        self.assertIs(packets[14357], TeamToggleMemberSideMessage)
        self.assertIs(packets[14360], TeamPostAdMessage)
        self.assertIs(packets[14361], TeamMemberStatusMessage)
        self.assertEqual(len([key for key in packets if key == 14363]), 1)

    def test_room_resolves_legacy_default_skin_for_each_selected_brawler(self):
        owner, second, _ = self.players
        for player, brawler_id in ((owner, 6), (second, 1)):
            player.brawler_id = brawler_id
            player.skin_id = 0
            self.assertTrue(DataBase.replaceValues(
                SimpleNamespace(player=player),
                {"brawlerID": brawler_id, "skinID": 0},
            ))
        room = GameRoomService.create(owner, 1, -64, 0, False)
        room = GameRoomService.join(second, room["id"])
        self.assertEqual(
            [(member["brawler_id"], member["skin_id"]) for member in room["members"]],
            [(6, 12), (1, 1)],
        )
        self.assertEqual(Skins.get_default_skin(6), 12)
        message = TeamGameroomDataMessage(None, owner, room)
        message.encode()
        reader = BSMessageReader(message.buffer)
        reader.read_Vint()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_int()
        reader.read_int()
        reader.read_Vint()
        reader.read_boolean()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_Vint()
        self.assertEqual(read_data_reference(reader), (15, room["map_id"]))
        self.assertEqual(reader.read_Vint(), 2)
        for brawler_id, skin_id in ((6, 12), (1, 1)):
            reader.read_boolean()
            reader.read_int()
            reader.read_int()
            reader.read_string()
            reader.read_Vint()
            self.assertEqual(read_data_reference(reader), (16, brawler_id))
            self.assertEqual(read_data_reference(reader), (29, skin_id))
            for _ in range(4):
                reader.read_Vint()
            reader.read_boolean()
            reader.read_Vint()
            reader.read_Vint()
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (0, 0))
        self.assertEqual(reader.read(), b"")

    def test_native_room_wire_and_complete_lifecycle(self):
        owner, second, third = self.players
        owner_client = CaptureClient()
        create = TeamCreateMessage(owner_client, owner, payload(1, -64, 1, boolean=False))
        create.decode()
        self.assertEqual((create.map_slot, create.requested_map, create.room_type), (1, -64, 1))
        room = create.process()
        room_id = room["id"]
        self.assertEqual(room["map_id"], EventRotation.resolve_slot(owner, 1)["map_id"])
        self.assertEqual(int.from_bytes(owner_client.packets[0][:2], "big"), 24124)
        self.assertEqual(owner.room_id, room_id)

        second_client = CaptureClient()
        join = TeamJoinMessage(second_client, second, payload(0, room_id, 0, data_reference=(0, 0)))
        join.decode()
        room = join.process()
        self.assertEqual(room["player_count"], 2)
        self.assertEqual([member["team"] for member in room["members"]], [0, 0])
        restored_second = self.reload(second)
        self.assertEqual(restored_second.room_id, room_id)
        self.assertEqual(GameRoomService.for_player(restored_second)["player_count"], 2)

        message = TeamGameroomDataMessage(None, owner, room)
        message.encode()
        reader = BSMessageReader(message.buffer)
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(reader.read_Vint(), 6)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room_id))
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual((reader.read_byte(), reader.read_byte()), (0, 1))
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (0, 0))
        self.assertEqual(read_data_reference(reader), (15, room["map_id"]))
        self.assertEqual(reader.read_Vint(), 2)
        for index, member in enumerate(room["members"]):
            self.assertEqual(reader.read_byte(), int(member["host"]))
            self.assertEqual((reader.read_int(), reader.read_int()), (0, member["low_id"]))
            self.assertEqual(reader.read_string(), member["name"])
            self.assertEqual(reader.read_Vint(), 0)
            self.assertEqual(read_data_reference(reader), (16, member["brawler_id"]))
            self.assertEqual(read_data_reference(reader), (29, member["skin_id"]))
            self.assertEqual(reader.read_Vint(), member["trophies"])
            self.assertEqual(reader.read_Vint(), member["highest_trophies"])
            self.assertEqual(reader.read_Vint(), member["power_level"])
            self.assertEqual(reader.read_Vint(), 3)
            self.assertEqual(reader.read_byte(), 0)
            self.assertEqual(reader.read_Vint(), member["team"])
            self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (0, 0))
        self.assertEqual(reader.read(), b"")

        settings = TeamChangeMemberSettingsMessage(
            CaptureClient(), second, payload(0, data_reference=(29, 1))
        )
        settings.decode()
        room = settings.process()
        member = next(item for item in room["members"] if item["low_id"] == second.low_id)
        self.assertEqual((member["brawler_id"], member["skin_id"]), (1, 1))

        with self.assertRaises(GameRoomError):
            GameRoomService.toggle_practice(second)
        practise = TeamTogglePractiseMessage(CaptureClient(), owner, b"")
        practise.decode()
        room = practise.process()
        self.assertTrue(room["practice"])
        ad = TeamPostAdMessage(CaptureClient(), owner, payload(0))
        ad.decode()
        room = ad.process()
        self.assertFalse(room["advertise_band"])

        side = TeamToggleMemberSideMessage(
            CaptureClient(), owner, payload(1, ints=(0, second.low_id)) + payload(1)
        )
        side.decode()
        self.assertEqual(side.targets, [(0, second.low_id)])
        room = side.process()
        self.assertEqual(room["members"][1]["team"], 1)

        ranked = TeamSetRankedLocationMessage(CaptureClient(), owner, payload(0, 2))
        ranked.decode()
        room = ranked.process()
        self.assertEqual(room["game_mode"], "BattleRoyale")
        self.assertEqual(room["capacity"], 10)
        self.assertEqual([member["team"] for member in room["members"]], [0, 0])

        first_ready = TeamSetMemberReadyMessage(CaptureClient(), owner, payload(boolean=True) + payload(0))
        first_ready.decode()
        first_result = first_ready.process()
        self.assertFalse(first_result["started"])
        second_ready_client = CaptureClient()
        second_ready = TeamSetMemberReadyMessage(second_ready_client, second, payload(boolean=True) + payload(0))
        second_ready.decode()
        second_result = second_ready.process()
        self.assertTrue(second_result["started"])
        self.assertEqual([int.from_bytes(packet[:2], "big") for packet in second_ready_client.packets], [24124, 24130])
        started_room_reader = BSMessageReader(second_ready_client.payload(0))
        self.assertEqual(started_room_reader.read_Vint(), 0)
        started_room_reader.read_boolean()
        started_room_reader.read_Vint()
        started_room_reader.read_int()
        started_room_reader.read_int()
        self.assertEqual(started_room_reader.read_Vint(), 0)
        starting_reader = BSMessageReader(second_ready_client.payload(1))
        self.assertEqual(starting_reader.read_Vint(), 0)
        self.assertEqual(starting_reader.read_Vint(), 0)
        self.assertEqual(starting_reader.readScId(), (15, second_result["room"]["map_id"]))
        self.assertEqual(starting_reader.read(1), b"")
        with self.assertRaises(GameRoomError):
            GameRoomService.join(third, room_id)
        replay_client = CaptureClient()
        replay = TeamSetMemberReadyMessage(replay_client, second, payload(boolean=True) + payload(0))
        replay.decode()
        self.assertFalse(replay.process()["started"])
        self.assertEqual([int.from_bytes(packet[:2], "big") for packet in replay_client.packets], [24124])

        status = TeamMemberStatusMessage(CaptureClient(), second, payload(5))
        status.decode()
        room = status.process()
        self.assertEqual(room["members"][1]["status"], 5)
        chat_client = CaptureClient()
        chat = TeamChatMessage(chat_client, second, payload(text="ready"))
        chat.decode()
        chat_result = chat.process()
        self.assertEqual(chat_result["chat"]["message"], "ready")
        self.assertEqual(GameRoomService.chats(room_id)[0]["message"], "ready")
        chat_payload = chat_client.payload()
        self.assertEqual(chat_client.message_id, 24131)
        chat_reader = BSMessageReader(chat_payload)
        self.assertEqual(chat_reader.read_Vint(), 0)
        self.assertEqual(chat_reader.read_Vint(), room_id)
        self.assertEqual(chat_reader.read_Vint(), 1)
        self.assertEqual(chat_reader.read_Vint(), 2)
        self.assertEqual(chat_reader.read_Vint(), 0)
        self.assertEqual(chat_reader.read_Vint(), chat_result["chat"]["id"])
        self.assertEqual(chat_reader.read_Vint(), 0)
        self.assertEqual(chat_reader.read_Vint(), second.low_id)
        self.assertEqual(chat_reader.read_string(), second.name)
        self.assertEqual(chat_reader.read_Vint(), 0)
        self.assertGreaterEqual(chat_reader.read_Vint(), 0)
        self.assertEqual(chat_reader.read_byte(), 0)
        self.assertEqual(chat_reader.read_string(), "ready")
        self.assertEqual(chat_reader.read(1), b"")

        return_client = CaptureClient()
        go_home = GoHomeFromOfflinePractiseMessage(return_client, second, b"\x01")
        go_home.decode()
        returned = go_home.process()
        self.assertEqual(returned["id"], room_id)
        self.assertEqual(returned["owner_id"], owner.low_id)
        self.assertEqual(returned["player_count"], 2)
        self.assertEqual(returned["state"], 0)
        self.assertEqual([member["ready"] for member in returned["members"]], [False, False])
        self.assertEqual(second.room_id, room_id)
        self.assertEqual(int.from_bytes(return_client.packets[-1][:2], "big"), 24124)

        leave_second = TeamLeaveMessage(CaptureClient(), second, b"")
        leave_second.decode()
        room = leave_second.process()
        self.assertEqual(second.room_id, 0)
        self.assertEqual(room["player_count"], 2 if room and len(room["members"]) == 2 else 1)
        room = GameRoomService.join(second, room_id)
        room = GameRoomService.join(third, room_id)
        self.assertEqual(room["player_count"], 3)

        kick = TeamKickMessage(CaptureClient(), owner, payload(0, second.low_id))
        kick.decode()
        room = kick.process()
        self.assertEqual(room["player_count"], 2)
        self.assertEqual(self.reload(second).room_id, 0)
        room = GameRoomService.leave(owner)
        self.assertEqual(room["owner_id"], third.low_id)
        self.assertTrue(room["members"][0]["host"])
        self.assertIsNone(GameRoomService.leave(third))
        with self.assertRaises(GameRoomError):
            GameRoomService.get(room_id)

    def test_invalid_payloads_and_unauthorized_changes_do_not_mutate(self):
        owner, second, third = self.players
        room = GameRoomService.create(owner, 1, -64, 0, False)
        GameRoomService.join(second, room["id"])
        before = GameRoomService.get(room["id"])
        with self.assertRaises(GameRoomError):
            GameRoomService.kick(second, owner.low_id)
        with self.assertRaises(GameRoomError):
            GameRoomService.set_location(second, 0)
        with self.assertRaises(ValueError):
            TeamCreateMessage(CaptureClient(), third, payload(1, -64, 0, boolean=False) + b"\x00").decode()
        with self.assertRaises(ValueError):
            TeamSetMemberReadyMessage(CaptureClient(), owner, b"\x02\x00").decode()
        self.assertEqual(GameRoomService.get(room["id"])["members"], before["members"])


if __name__ == "__main__":
    unittest.main()
