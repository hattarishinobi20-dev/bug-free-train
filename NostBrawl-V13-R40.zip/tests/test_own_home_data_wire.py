import csv
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Logic.EventRotation import EventRotation
from Logic.EventSlots import EventSlots
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Utils.Reader import BSMessageReader


class OwnHomeDataReader(BSMessageReader):
    """Independent bit/VInt reader for the complete OwnHomeData envelope."""

    def __init__(self, payload):
        super().__init__(payload)
        self.bit_index = 0
        self.bit_byte = 0

    def align(self):
        self.bit_index = 0

    def v(self):
        self.align()
        return self.read_Vint()

    def b(self):
        if self.bit_index == 0:
            self.bit_byte = self.read_byte()
        value = bool(self.bit_byte & (1 << self.bit_index))
        self.bit_index = (self.bit_index + 1) & 7
        return value

    def i(self):
        self.align()
        return self.read_int()

    def s(self):
        self.align()
        return self.read_string()

    def long(self):
        self.align()
        raw = self._read_exact(8)
        return int.from_bytes(raw[:4], "big"), int.from_bytes(raw[4:], "big")

    def array(self):
        return [self.v() for _ in range(self.v())]

    def references(self):
        return [(self.v(), self.v()) for _ in range(self.v())]

    def brawler_values(self):
        return [(self.v(), self.v(), self.v()) for _ in range(self.v())]


def fixed_home_events(_player):
    values = ((7, 2, 10), (32, 0, 10), (24, 0, 10), (0, 0, 10), (30, 0, 2))
    return [
        {"slot": slot, "map_id": map_id, "modifier": modifier, "tokens": tokens, "claimed": False}
        for slot, (map_id, modifier, tokens) in enumerate(values, 1)
    ]


class OwnHomeDataWireTests(unittest.TestCase):
    def test_complete_packet_has_no_missing_or_trailing_fields(self):
        player = SimpleNamespace(
            high_id=1,
            low_id=42,
            name="Wire",
            trophies=999,
            highest_trophies=999,
            trophy_road=7,
            exp_points=11,
            profile_icon=2,
            brawlers_skins={"0": 29, "1": 0},
            UnlockedSkins={"Skins": [29, 0]},
            tokensAnim=1,
            trophiesAnim=2,
            bigTokensAnim=3,
            tokensdoubler=1000,
            brawler_id=0,
            battle_tokens=200,
            brawlers_id=[0, 1],
            card_unlock_id=[10, 12],
            BrawlersUnlockedState={"0": 1, "1": 0},
            brawlers_trophies={"0": 12, "1": 13},
            brawlers_trophies_in_rank={"0": 22, "1": 23},
            brawlers_upgradium={"0": 32, "1": 33},
            Brawler_level={"0": 2, "1": 9},
            Brawler_starPower={"0": 76, "1": 80},
            progression={"brawlerNewTag": {"0": 0, "1": 1}},
            gems=969,
            gold=100,
            brawl_boxes=899,
            big_boxes=4,
            star_points=5,
            player_experience=77,
            tutorial=2,
        )
        message = OwnHomeDataMessage(None, player)
        with patch.object(EventSlots, "Timer", lambda self: 49020), \
             patch.object(EventRotation, "snapshot", side_effect=fixed_home_events), \
             patch.object(EventRotation, "seconds_to_next_day", lambda: 49020), \
             patch(
                 "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
                 lambda writer, player: writer.v(0),
             ):
            message.encode()
        fixture = Path(__file__).resolve().parent / "fixtures" / "own_home_data.bin"
        self.assertEqual(message.buffer, fixture.read_bytes())
        reader = OwnHomeDataReader(message.buffer)

        self.assertEqual([reader.v() for _ in range(2)], [0, 0])
        self.assertEqual(
            [reader.v() for _ in range(5)], [999, 999, 0, 7, 77]
        )
        self.assertEqual((reader.v(), reader.v()), (28, 2))
        self.assertEqual(reader.v(), 0)
        self.assertEqual(reader.references(), [(29, 29), (29, 0)])
        self.assertEqual(reader.references(), [(29, 29)])

        self.assertFalse(reader.b())
        self.assertEqual(
            [reader.v() for _ in range(6)], [0, 1, 2, 3, 0, 0]
        )
        self.assertFalse(reader.b())
        self.assertEqual(reader.v(), 0)
        self.assertFalse(reader.b())
        self.assertEqual([reader.v(), reader.v()], [1000, 0])
        self.assertEqual([reader.b() for _ in range(4)], [False] * 4)
        self.assertEqual([reader.v() for _ in range(3)], [0, 0, 0])
        self.assertFalse(reader.b())
        self.assertEqual([reader.v() for _ in range(6)], [0, 0, 0, 0, 0, 0])
        self.assertEqual(reader.v(), 0)
        self.assertEqual((reader.v(), reader.v()), (16, 0))

        self.assertEqual(
            [reader.v() for _ in range(12)],
            [2019049, 100, 10, 30, 3, 80, 10, 50, 1000, 500, 50, 999900],
        )
        self.assertEqual(reader.array(), [0, 30, 80, 170, 350, 0])
        slots = reader.array()
        self.assertEqual(slots, list(range(6)))

        expected_events = (
            (7, 10, 2),
            (32, 10, 0),
            (24, 10, 0),
            (0, 10, 0),
            (30, 2, 0),
        )
        self.assertEqual(reader.v(), len(expected_events))
        encoded_maps = []
        for index, (map_id, tokens, modifier) in enumerate(expected_events, 1):
            self.assertEqual(
                [reader.v() for _ in range(8)],
                [index, index, 0, 49020, tokens, 15, map_id, 1],
            )
            self.assertEqual(reader.s(), "")
            self.assertEqual(reader.v(), 0)
            self.assertEqual(reader.b(), bool(modifier))
            if modifier:
                self.assertEqual(reader.v(), modifier)
            self.assertEqual(reader.v(), 0)
            encoded_maps.append(map_id)
        with open(
            PROJECT_ROOT / "GameAssets" / "csv_logic" / "locations.csv",
            encoding="utf-8-sig",
            newline="",
        ) as csv_file:
            locations = list(csv.DictReader(csv_file))[1:]
        for map_id in encoded_maps:
            self.assertLess(map_id, len(locations))
            self.assertFalse(locations[map_id]["Disabled"])
        self.assertEqual(reader.v(), 0)
        self.assertEqual(reader.array(), [20, 35, 75, 140, 290, 480, 800, 1250])
        self.assertEqual(reader.array(), [1, 2, 3, 4, 5, 10, 15, 20])
        self.assertEqual(reader.array(), [10, 30, 80])
        self.assertEqual(reader.array(), [6, 20, 60])
        self.assertEqual(reader.array(), [20, 50, 140])
        self.assertEqual(reader.array(), [150, 400, 1200])

        self.assertEqual(reader.v(), 0)
        self.assertEqual([reader.v() for _ in range(5)], [200, 20, 8640, 10, 5])
        self.assertEqual([reader.b() for _ in range(3)], [False] * 3)
        self.assertEqual([reader.v(), reader.v()], [0, 0])
        self.assertTrue(reader.b())
        self.assertEqual(reader.v(), 0)

        self.assertEqual(reader.long(), (1, 42))
        self.assertEqual([reader.v(), reader.v()], [0, 0])
        self.assertFalse(reader.b())
        self.assertEqual(reader.v(), 0)

        for _ in range(3):
            self.assertEqual([reader.v(), reader.v()], [1, 42])
        self.assertEqual(reader.s(), "Wire")
        self.assertTrue(reader.b())
        self.assertEqual(reader.i(), 0xFFFFFFFF)
        self.assertEqual(reader.v(), 8)

        commodities = [
            (reader.v(), reader.v(), reader.v()) for _ in range(reader.v())
        ]
        self.assertEqual(commodities, [
            (23, 10, 1), (23, 12, 0), (23, 0, 5),
            (5, 1, 899), (5, 8, 100), (5, 9, 4),
        ])
        self.assertEqual(reader.brawler_values(), [(16, 0, 12), (16, 1, 13)])
        self.assertEqual(reader.brawler_values(), [(16, 0, 22), (16, 1, 23)])
        self.assertEqual(reader.v(), 0)
        self.assertEqual(reader.brawler_values(), [(16, 0, 32), (16, 1, 33)])
        self.assertEqual(reader.brawler_values(), [(16, 0, 2), (16, 1, 9)])
        self.assertEqual(reader.v(), 0)                        
        self.assertEqual(reader.v(), 0)                     
        self.assertEqual([reader.v() for _ in range(3)], [969, 969, 77])
        self.assertEqual([reader.v() for _ in range(7)], [0] * 7)
        self.assertEqual([reader.v(), reader.v()], [2, 0])
        self.assertEqual(reader.tell(), len(message.buffer))
        self.assertEqual(reader.read(), b"")


if __name__ == "__main__":
    unittest.main()
