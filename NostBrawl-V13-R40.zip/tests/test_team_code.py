import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Logic.TeamCode import TeamCode
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Gameroom.TeamJoinOrCreateRoomMessage import TeamJoinOrCreateRoomMessage
from Utils.Writer import Writer


def string(value):
    writer = Writer(None)
    writer.writeString(value)
    return writer.buffer


class TeamCodeTests(unittest.TestCase):
    def test_native_vectors(self):
        self.assertEqual(TeamCode.to_code(0, 0), "X")
        self.assertEqual(TeamCode.to_code(0, 1), "XAA")
        self.assertEqual(TeamCode.to_id("X"), (0, 0))
        self.assertEqual(TeamCode.to_id("XAA"), (0, 1))

    def test_roundtrip_preserves_logic_long(self):
        for high_id, low_id in (
            (0, 0), (0, 1), (0, 255), (0, 256), (0, 65535),
            (0, 2147483647), (1, 1), (255, 2147483647),
        ):
            with self.subTest(high_id=high_id, low_id=low_id):
                code = TeamCode.to_code(high_id, low_id)
                self.assertTrue(code.startswith("X"))
                self.assertLess(len(code), 14)
                self.assertEqual(TeamCode.to_id(code), (high_id, low_id))

    def test_invalid_codes_are_rejected(self):
        for code in ("", "X!", "X0", "XAA" * 5):
            with self.subTest(code=code):
                with self.assertRaises(ValueError):
                    TeamCode.to_id(code)
        for high_id, low_id in ((-1, 0), (256, 0), (0, -1), (0, 2147483648)):
            with self.subTest(high_id=high_id, low_id=low_id):
                with self.assertRaises(ValueError):
                    TeamCode.to_code(high_id, low_id)


class TeamJoinOrCreateRoomTests(unittest.TestCase):
    def test_factory_and_exact_payload(self):
        self.assertIs(packets[14371], TeamJoinOrCreateRoomMessage)
        message = TeamJoinOrCreateRoomMessage(None, SimpleNamespace(), string("XAA"))
        message.decode()
        self.assertEqual(message.code, "XAA")
        with self.assertRaises(ValueError):
            TeamJoinOrCreateRoomMessage(
                None, SimpleNamespace(), string("XAA") + b"\x00"
            ).decode()

    def test_zero_creates_and_positive_id_joins(self):
        player = SimpleNamespace(low_id=1)
        room = {"id": 77, "members": []}
        with patch(
            "Packets.Messages.Client.Gameroom.TeamJoinOrCreateRoomMessage.GameRoomService.create",
            return_value=room,
        ) as create, patch(
            "Packets.Messages.Client.Gameroom.TeamJoinOrCreateRoomMessage.GameRoomGateway.deliver"
        ) as deliver:
            message = TeamJoinOrCreateRoomMessage(None, player, string("X"))
            message.decode()
            self.assertIs(message.process(), room)
            create.assert_called_once_with(player, 0, -64, 0, False)
            deliver.assert_called_once_with(None, player, room)

        with patch(
            "Packets.Messages.Client.Gameroom.TeamJoinOrCreateRoomMessage.GameRoomService.join",
            return_value=room,
        ) as join, patch(
            "Packets.Messages.Client.Gameroom.TeamJoinOrCreateRoomMessage.GameRoomGateway.deliver"
        ) as deliver:
            code = TeamCode.to_code(0, 77)
            message = TeamJoinOrCreateRoomMessage(None, player, string(code))
            message.decode()
            self.assertEqual(TeamCode.to_id(message.code), (0, 77))
            self.assertIs(message.process(), room)
            join.assert_called_once_with(player, 77)
            deliver.assert_called_once_with(None, player, room)


if __name__ == "__main__":
    unittest.main(verbosity=2)
