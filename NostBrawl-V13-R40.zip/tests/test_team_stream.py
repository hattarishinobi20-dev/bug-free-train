import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Packets.Messages.Server.Gameroom.TeamChatServerMessage import TeamChatServerMessage
from Utils.Writer import Writer


class TeamStreamTests(unittest.TestCase):
    def test_chat_type_two_matches_native_base_and_text_layout(self):
        chat = {
            "room_id": 7,
            "id": 3,
            "player_id": 42,
            "player_name": "Name",
            "created_at": 100,
            "message": "oi",
        }
        message = TeamChatServerMessage(None, SimpleNamespace(), chat)
        with patch("Packets.Messages.Server.Gameroom.TeamChatServerMessage.time.time", return_value=110):
            message.encode()

        expected = Writer(None)
        for value in (0, 7, 1, 2, 0, 3, 0, 42):
            expected.writeVint(value)
        expected.writeString("Name")
        expected.writeVint(0)
        expected.writeVint(10)
        expected.writeBoolean(False)
        expected.writeString("oi")
        self.assertEqual(message.buffer, expected.buffer)
        self.assertEqual(
            message.buffer.hex(),
            "000701020003002a000000044e616d65000a00000000026f69",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
