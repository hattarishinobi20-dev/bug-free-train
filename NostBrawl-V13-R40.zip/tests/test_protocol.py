import json
import os
import socket
import sqlite3
import struct
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Core import NaCl19
from Core.Crypto import Crypto, CryptoError, Nonce
from Database.DatabaseManager import DataBase
from Files.CsvLogic.Cards import Cards
from Logic.EventSlots import EventSlots
from Logic.LeaderboardService import LeaderboardService
from Logic.NotificationFactory import NotificationFactory
from Logic.Player import Players
from Packets.Commands.Client.LogicClaimRankUpRewardCommand import LogicClaimRankUpRewardCommand
from Packets.Commands.Client.LogicNewEventCommand import LogicNewEventCommand
from Packets.Commands.Client.LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand
from Packets.LogicCommandManager import EndClientTurn
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Battle.OnPlay import OnPlay
from Packets.Messages.Client.Login.ClientHelloMessage import ClientHelloMessage
from Packets.Messages.Client.Login.LoginMessage import LoginMessage
from Packets.Messages.Client.SetDeviceToken import SetDeviceToken
from Packets.Messages.Client.SetNameMessage import SetNameMessage
from Packets.Messages.Server.Battle.MatchMakingCancelledMessage import MatchMakingCancelledMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Leaderboard.TopGlobalPlayersDataMessage import GetLeaderboardGlobalOkMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from Utils.Helpers import Helpers
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


FIXTURES = Path(__file__).resolve().parent / "fixtures"


def int32(value):
    return struct.pack(">I", value)


def vint(value):
    writer = Writer(None)
    writer.writeVint(value)
    return writer.buffer


def string(value=None):
    if value is None:
        return b"\xff\xff\xff\xff"
    encoded = value.encode("utf-8")
    return int32(len(encoded)) + encoded


def packet(packet_id, payload=b"", version=0):
    return (
        struct.pack(">H", packet_id)
        + len(payload).to_bytes(3, "big")
        + struct.pack(">H", version)
        + payload
    )


def login_payload(low_id=0, token="", major=13, minor=283, build=1):
    return (
        int32(0)
        + int32(low_id)
        + string(token)
        + int32(major)
        + int32(minor)
        + int32(build)
        + string("fingerprint")
        + int32(0)
        + string("open-udid")
        + string("android-id")
        + string("android-version")
    )


def battle_end_payload(map_id=7):
    writer = Writer(None)
    for value in (0, 16, 1, map_id, 15, 6):
        writer.writeVint(value)
    for index in range(6):
        writer.writeVint(16)
        writer.writeVint(index)
        if index == 0:
            writer.writeVint(29)
        writer.writeVint(0)
        writer.writeVint(index % 2)
        writer.writeByte(1 if index == 0 else 0)
        writer.writeString("Local" if index == 0 else f"Bot {index}")
    return writer.buffer


def notification_claim_payload(notification_index=1):
    writer = Writer(None)
    for value in (0, 0, 0, 1, 528, 0, 0, 0, 0, notification_index):
        writer.writeVint(value)
    return writer.buffer


def notification_delete_payload(action=8):
    writer = Writer(None)
    for value in (0, 137, 0, 1, 514, 136, 136, -64, -64, action):
        writer.writeVint(value)
    return writer.buffer + b"\xff" * 4


def receive_exact(sock, length):
    data = bytearray()
    while len(data) < length:
        chunk = sock.recv(length - len(data))
        if not chunk:
            raise ConnectionError("Socket closed while reading test packet")
        data.extend(chunk)
    return bytes(data)


def receive_packet(sock):
    header = receive_exact(sock, 7)
    packet_id = int.from_bytes(header[:2], "big")
    length = int.from_bytes(header[2:5], "big")
    version = int.from_bytes(header[5:7], "big")
    return packet_id, version, receive_exact(sock, length)


def fake_player():
    return SimpleNamespace(
        high_id=0,
        low_id=0,
        token="",
        device=SimpleNamespace(),
        maintenance=False,
        maintenance_time=0,
        patch=False,
        patch_sha="fingerprint",
        patch_url="",
        update_url="",
        region="BR",
        err_code=0,
        logged_in=False,
        online=0,
    )


class ClientHelloTests(unittest.TestCase):
    def test_empty_hello_sends_only_server_hello(self):
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        client.settimeout(1)

        player = fake_player()
        message = ClientHelloMessage(server, player, b"")
        message.decode()
        message.process()

        packet_id, version, payload = receive_packet(client)
        self.assertEqual(packet_id, 20100)
        self.assertEqual(version, 0)
        self.assertEqual(len(payload), 28)
        self.assertEqual(int.from_bytes(payload[:4], "big"), 24)
        self.assertEqual(payload[-13:], bytes.fromhex("00446f6e277420747279203a29"))

    def test_v13_hello_fields_are_decoded(self):
        server, client = socket.socketpair()
        self.addCleanup(server.close)
        self.addCleanup(client.close)
        payload = (
            int32(0) + int32(0) + int32(13) + int32(283) + int32(1)
            + string("sha") + int32(0) + int32(0)
        )
        player = fake_player()
        message = ClientHelloMessage(server, player, payload)
        message.decode()
        self.assertEqual((message.major, message.minor, message.build), (13, 283, 1))
        self.assertEqual(message.fingerprint_sha, "sha")
        self.assertEqual(player.client_major, 13)


class LoginOkCompatibilityTests(unittest.TestCase):
    def test_login_ok_matches_v13_reference(self):
        player = fake_player()
        player.high_id = 1
        player.low_id = 2
        player.token = "token"

        ours = LoginOkMessage(None, player)
        ours.encode()
        expected = (FIXTURES / "loginok_v13.bin").read_bytes()
        self.assertEqual(ours.buffer, expected)


class WriterCompatibilityTests(unittest.TestCase):
    def test_signed_integers_use_cpp_twos_complement_layout(self):
        writer = Writer(None)
        writer.writeInt(-1)
        writer.writeInt(-2, 2)
        writer.writeInt(1)
        self.assertEqual(
            writer.buffer,
            b"\xff\xff\xff\xff\xff\xfe\x00\x00\x00\x01",
        )

    def test_directed_send_uses_recipient_crypto_and_clean_framing(self):
        class DirectedMessage(Writer):
            def __init__(self, client, player):
                super().__init__(client)
                self.id = 20999
                self.version = 0
                self.player = player

            def encode(self):
                self.writeVint(500)
                self.writeString("ok")

        class TargetCrypto:
            def __init__(self):
                self.calls = []

            def encrypt(self, packet_id, payload):
                self.calls.append((packet_id, payload))
                return b"secret:" + payload

        class UnexpectedSenderCrypto:
            def encrypt(self, packet_id, payload):
                raise AssertionError("the sender crypto must not encrypt a directed packet")

        recipient_server, recipient_client = socket.socketpair()
        self.addCleanup(recipient_server.close)
        self.addCleanup(recipient_client.close)
        target_crypto = TargetCrypto()
        player = SimpleNamespace(
            crypto=UnexpectedSenderCrypto(),
            ClientDict={
                "ClientCounts": 1,
                "Clients": {
                    "42": {
                        "SocketInfo": recipient_server,
                        "Crypto": target_crypto,
                    }
                },
            },
        )
        message = DirectedMessage(None, player)
        raw_payload = vint(500) + string("ok")

                                                                         
                                                                        
        self.assertTrue(message.sendWithLowID(42))
        self.assertTrue(message.sendWithLowID(42))
        for _ in range(2):
            self.assertEqual(
                receive_packet(recipient_client),
                (20999, 0, b"secret:" + raw_payload),
            )
        self.assertEqual(target_crypto.calls, [(20999, raw_payload)] * 2)

        recipient_client.setblocking(False)
        with self.assertRaises(BlockingIOError):
            recipient_client.recv(1)
        self.assertFalse(message.sendWithLowID(404))


class OwnHomeDataCompatibilityTests(unittest.TestCase):
    def setUp(self):
        shop_patch = patch(
            "Packets.Messages.Server.Home.OwnHomeDataMessage.ShopService.encode_home",
            lambda writer, player: writer.writeVint(0),
        )
        shop_patch.start()
        self.addCleanup(shop_patch.stop)

    def test_home_level_uses_persisted_experience_not_legacy_points(self):
        player = Players(SimpleNamespace())
        player.player_experience = 99999
        player.exp_points = 0
        message = OwnHomeDataMessage(None, player)
        message.encode()
        reader = BSMessageReader(message.buffer)
        daily_values = [reader.read_Vint() for _ in range(7)]
        self.assertEqual(daily_values[-1], 99999)

    def test_real_v13_player_has_consistent_array_counts(self):
        player = Players(SimpleNamespace())
        message = OwnHomeDataMessage(None, player)
        message.encode()
        self.assertEqual(player.player_experience, 99999)
        self.assertGreater(len(message.buffer), 100)
        self.assertEqual(len(player.brawlers_id), 21)
        self.assertEqual(len(player.card_unlock_id), 21)


class DeviceTokenTests(unittest.TestCase):
    def test_v12_device_token_is_registered_and_fully_decoded(self):
        self.assertIs(packets[10113], SetDeviceToken)
        token = bytes(range(131))
        payload = int32(len(token)) + token + int32(7)
        self.assertEqual(len(payload), 139)
        message = SetDeviceToken(None, SimpleNamespace(), payload)
        message.decode()
        self.assertEqual(message.device_token, token)
        self.assertEqual(message.value, 7)
        self.assertEqual(message.read(), b"")
        self.assertIsNone(message.process())


class CryptoCompatibilityTests(unittest.TestCase):
    def test_reference_ciphertext_vectors(self):
        crypto = Crypto({"Enabled": True})
        login = (FIXTURES / "crypto_login.bin").read_bytes()
        self.assertEqual(crypto.decrypt(10101, login), b"raw-login-payload")
        self.assertEqual(bytes(crypto.decryptNonce), bytes(range(24, 48)))

        crypto.encryptNonce = Nonce(bytes(range(48, 72)))
        crypto.shared_en = bytes(range(72, 104))
        self.assertEqual(
            crypto.encrypt(20104, b"login-ok"),
            (FIXTURES / "crypto_loginok.bin").read_bytes(),
        )
        self.assertEqual(
            crypto.encrypt(24101, b"own-home"),
            (FIXTURES / "crypto_ownhome.bin").read_bytes(),
        )
        self.assertEqual(
            crypto.decrypt(
                10108, (FIXTURES / "crypto_keepalive.bin").read_bytes()
            ),
            b"keepalive",
        )

    def test_raw_mode_and_tampered_ciphertext(self):
        raw = Crypto({"Enabled": False})
        self.assertEqual(raw.decrypt(10101, b"plain"), b"plain")
        self.assertEqual(raw.encrypt(20104, b"plain"), b"plain")

        crypto = Crypto({"Enabled": True})
        login = bytearray((FIXTURES / "crypto_login.bin").read_bytes())
        login[-1] ^= 1
        with self.assertRaises(CryptoError):
            crypto.decrypt(10101, bytes(login))


class SQLiteAccountTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(
            DataBase, "_database_path", lambda: self.database_path
        )
        path_patch.start()
        self.addCleanup(path_patch.stop)

    def make_player(self, low_id=1001, token="sqlite-token"):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = "SQLite Player"
        return player

    def test_account_round_trip_and_json_updates(self):
        player = self.make_player()
        owner = SimpleNamespace(player=player)

        self.assertEqual(DataBase.createAccount(owner), 1001)
        self.assertEqual(player.player_experience, 99999)
        self.assertTrue(Path(self.database_path).is_file())
        self.assertEqual(DataBase.checkID(owner, 1001), 0)
        self.assertEqual(DataBase.checkID(owner, 1002), 1)

        player.brawlers_trophies["0"] = 321
        player.UnlockedSkins["Skins"].append(7)
        self.assertTrue(
            DataBase.replaceValue(
                owner, "brawlersTrophies", player.brawlers_trophies
            )
        )
        self.assertTrue(
            DataBase.replaceValue(owner, "UnlockedSkins", player.UnlockedSkins)
        )
        self.assertTrue(DataBase.replaceOtherValue(owner, 1001, "gold", 456))
        self.assertTrue(DataBase.replaceValue(owner, "playerExp", 54321))

        loaded = self.make_player()
        loaded_owner = SimpleNamespace(player=loaded)
        self.assertTrue(DataBase.loadAccount(loaded_owner))
        self.assertEqual(loaded.name, "SQLite Player")
        self.assertEqual(loaded.low_id, 1001)
        self.assertEqual(loaded.brawlers_trophies["0"], 321)
        self.assertEqual(loaded.UnlockedSkins, {"Skins": [7]})
        self.assertEqual(loaded.gold, 456)
        self.assertEqual(loaded.player_experience, 54321)
        loaded.exp_points = 0
        home = OwnHomeDataMessage(None, loaded)
        home.encode()
        home_reader = BSMessageReader(home.buffer)
        daily_values = [home_reader.read_Vint() for _ in range(7)]
        self.assertEqual(daily_values[-1], 54321)

        rows = DataBase.loadById(owner, 1001)
        self.assertEqual(len(rows), 1)
        self.assertEqual(len(rows[0]), 40)                                   
        self.assertEqual(DataBase.loadMembersById(owner, 1001)[4], 1001)
        self.assertEqual(DataBase.getLeaders(owner)[0][0], 1001)

        missing = self.make_player(token="missing-token")
        self.assertFalse(DataBase.loadAccount(SimpleNamespace(player=missing)))

    def test_name_and_brawler_selection_survive_second_load(self):
        player = self.make_player()
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)

        server, client = socket.socketpair()
        try:
            rename = SetNameMessage(
                client, player, string("Persisted") + b"\x01"
            )
            rename.decode()
            rename.process()
            self.assertEqual(receive_packet(server)[0], 24111)
        finally:
            server.close()
            client.close()

        for brawler_id in player.brawlers_id:
            self.assertIsNotNone(
                Cards.get_spg_by_brawler_id(owner, brawler_id, 4),
                f"Brawler {brawler_id} has no valid V13 star power",
            )

        player.BrawlersUnlockedState["20"] = 1
        DataBase.replaceValue(
            owner, "UnlockedBrawlers", player.BrawlersUnlockedState
        )
        selection = LogicSelectSkinCommand(None, player, b"")
        player.skin_id = 0
        player.brawler_id = 20
        selection.process()
        self.assertEqual(player.starpower, 104)

        loaded = self.make_player()
        loaded_owner = SimpleNamespace(player=loaded)
        self.assertTrue(DataBase.loadAccount(loaded_owner))
        self.assertEqual(loaded.name, "Persisted")
        self.assertEqual(loaded.brawler_id, 20)
        self.assertEqual(loaded.starpower, 104)
        self.assertEqual(loaded.brawlers_skins["20"], 0)

    def test_legacy_experience_is_migrated_exactly_once(self):
        with closing(sqlite3.connect(self.database_path)) as connection:
            connection.executescript(DataBase.PLAYER_SCHEMA)
            connection.execute(
                "INSERT INTO players (token, name, lowID, playerExp) "
                "VALUES (?, ?, ?, ?)",
                ("legacy-exp", "Legacy", 1003, 17),
            )
            connection.commit()

        resolved_path = str(Path(self.database_path).resolve())
        self.addCleanup(DataBase._initialized_paths.discard, resolved_path)
        player = Players(SimpleNamespace())
        player.token = "legacy-exp"
        owner = SimpleNamespace(player=player)
        self.assertTrue(DataBase.loadAccount(owner))
        self.assertEqual(player.player_experience, 99999)

        with closing(sqlite3.connect(self.database_path)) as connection:
            saved = connection.execute(
                "SELECT playerExp FROM players WHERE lowID = 1003"
            ).fetchone()[0]
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            self.assertEqual((saved, version), (99999, 1))
            connection.execute(
                "UPDATE players SET playerExp = 100020 WHERE lowID = 1003"
            )
            connection.commit()

        DataBase._initialized_paths.discard(resolved_path)
        reloaded = Players(SimpleNamespace())
        reloaded.token = "legacy-exp"
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=reloaded)))
        self.assertEqual(reloaded.player_experience, 100020)

    def test_zero_power_levels_are_normalized_on_reload(self):
        player = self.make_player(low_id=1002, token="power-token")
        self.assertEqual(player.Brawler_level["0"], 1)
        player.Brawler_level = {
            key: 0 for key in player.Brawler_level
        }
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)

        loaded = Players(SimpleNamespace())
        loaded.token = player.token
        loaded_owner = SimpleNamespace(player=loaded)
        self.assertTrue(DataBase.loadAccount(loaded_owner))
        self.assertEqual(loaded.Brawler_level["0"], 1)
        self.assertTrue(all(level >= 1 for level in loaded.Brawler_level.values()))

    def test_update_rejects_unknown_columns(self):
        owner = SimpleNamespace(player=self.make_player())
        with self.assertRaises(ValueError):
            DataBase.replaceValue(owner, "name; DROP TABLE players", "x")


class ClientActionTests(unittest.TestCase):
    def test_on_play_never_invalidates_the_login(self):
        player = fake_player()
        message = OnPlay(None, player, b"\x00\x00\x00\x01")
        message.decode()
        with patch.object(MatchMakingCancelledMessage, "send") as cancelled, \
             patch.object(LoginFailedMessage, "send") as login_failed:
            message.process()

        self.assertEqual(player.map_id, 15)
        self.assertEqual(player.mmplayers, 1)
        cancelled.assert_called_once()
        login_failed.assert_not_called()

    def test_event_action_rejects_unknown_slot_without_legacy_slots(self):
        player = Players(SimpleNamespace())
        message = LogicNewEventCommand(None, player, b"")
        message.event_index = 10
        with patch.object(
            EventSlots, "loadEvents",
            side_effect=AssertionError("legacy event JSON must not be read"),
        ):
            with self.assertRaises(ValueError):
                message.process()

    def test_end_client_turn_with_zero_commands_is_accepted(self):
        payload = vint(0) + vint(123) + vint(0) + vint(0) + b"\x00\x00\x00\x00"
        message = EndClientTurn(None, fake_player(), payload)
        message.decode()
        self.assertEqual(message.command_count, 0)
        self.assertIsNone(message.commandID)
        message.process()

    def test_short_end_client_turn_does_not_disconnect_session(self):
                                                                        
                                                                    
        payload = vint(0) + vint(1) + vint(0) + vint(1) + vint(506) + b"\x00\x00\x00"
        self.assertEqual(len(payload), 9)                                     
        message = EndClientTurn(None, fake_player(), payload)
        message.decode()
        with patch.object(LogicSelectSkinCommand, "process") as process:
            message.process()
        process.assert_not_called()

    def test_end_client_turn_still_dispatches_valid_command(self):
        payload = vint(0) + vint(1) + vint(0) + vint(1) + vint(509)
        payload += b"".join(vint(value) for value in (1, 1, -1, -1))
        payload += b"\xff" * 4
        message = EndClientTurn(None, fake_player(), payload)
        message.decode()
        with patch.object(LogicPurchaseDoubleCoinsCommand, "process") as process:
            message.process()
        process.assert_called_once_with(message)

    def test_unavailable_reward_does_not_invalidate_login(self):
        player = Players(SimpleNamespace())
        player.trophy_road = 0
        command = LogicClaimRankUpRewardCommand(None, player, b"")
        command.brawlerID = 0
        with patch.object(LoginFailedMessage, "send") as login_failed:
            command.process()
        login_failed.assert_not_called()


class LoginFlowTests(unittest.TestCase):
    def run_login(self, player, payload, database_events):
        message = LoginMessage(None, player, payload)
        message.decode()
        with patch.object(LoginOkMessage, "send", lambda self: database_events.append("loginok")), \
             patch.object(OwnHomeDataMessage, "send", lambda self: database_events.append("ownhome")), \
             patch.object(DataBase, "replaceValue", lambda self, column, value: True), \
             patch.object(NotificationFactory, "ensure_star_shelly", lambda player: False), \
             patch.object(NotificationFactory, "ensure_wizard_barley", lambda player: False), \
             patch.object(LoginFailedMessage, "send", lambda self: database_events.append("failed")):
            result = message.process()
        return result

    def test_new_account_is_created_before_success_packets(self):
        events = []
        player = fake_player()
        with patch.object(Helpers, "randomID", lambda self: 1234), \
             patch.object(Helpers, "randomStringDigits", lambda self: "new-token"), \
             patch.object(DataBase, "createAccount", lambda self: events.append("create")):
            result = self.run_login(player, login_payload(), events)

        self.assertTrue(result)
        self.assertTrue(player.logged_in)
        self.assertEqual(player.online, 1)
        self.assertEqual((player.low_id, player.token), (1234, "new-token"))
        self.assertEqual(events, ["create", "loginok", "ownhome"])

    def test_existing_account_is_loaded_before_success_packets(self):
        events = []
        player = fake_player()
        player.low_id = 1234
        player.token = "saved-token"

        def load_account(message):
            events.append("load")
            return True

        with patch.object(DataBase, "loadAccount", load_account):
            result = self.run_login(
                player, login_payload(low_id=1234, token="saved-token"), events
            )

        self.assertTrue(result)
        self.assertEqual(events, ["load", "loginok", "ownhome"])

    def test_wrong_version_stops_before_database_and_home(self):
        events = []
        player = fake_player()
        with patch.object(DataBase, "createAccount") as create:
            result = self.run_login(player, login_payload(major=26), events)
        self.assertFalse(result)
        self.assertFalse(player.logged_in)
        self.assertEqual(events, ["failed"])
        create.assert_not_called()

    def test_missing_existing_account_is_rejected(self):
        events = []
        player = fake_player()
        player.low_id = 1234
        player.token = "bad-token"
        with patch.object(DataBase, "loadAccount", lambda self: False):
            result = self.run_login(
                player, login_payload(low_id=1234, token="bad-token"), events
            )
        self.assertFalse(result)
        self.assertEqual(events, ["failed"])


class ServerMaintenanceTests(unittest.TestCase):
    def test_rotation_does_not_start_legacy_daily_refresh(self):
        from main import Server

        self.assertFalse(hasattr(Server, "daily_timer"))


class LeaderboardCompatibilityTests(unittest.TestCase):
    def test_global_player_leaderboard_matches_v13_reference(self):
        player = SimpleNamespace(low_id=55113832, region="PT")
        entries = [{
            "low_id": 55113832,
            "name": "ABC",
            "trophies": 0,
            "profile_icon": 0,
            "name_color": 0,
            "club_id": 0,
            "club_name": "",
            "player_experience": 0,
            "online": 0,
        }]
        with patch.object(
            LeaderboardService, "players", lambda brawler_id=None: entries
        ):
            message = GetLeaderboardGlobalOkMessage(None, player)
            message.encode()
        self.assertEqual(
            message.buffer,
            (FIXTURES / "leaderboard_v13.bin").read_bytes(),
        )


class PlayerIsolationTests(unittest.TestCase):
    def test_mutable_brawler_and_skin_data_is_not_shared(self):
        first = Players(SimpleNamespace())
        second = Players(SimpleNamespace())

        first.brawlers_trophies["0"] = 777
        first.brawlers_skins["0"] = 12
        first.UnlockedSkins["Skins"].append(12)

        self.assertNotEqual(second.brawlers_trophies["0"], 777)
        self.assertNotEqual(second.brawlers_skins["0"], 12)
        self.assertNotIn(12, second.UnlockedSkins["Skins"])


class TcpFlowTests(unittest.TestCase):
    def test_tcp_flow_and_second_login_use_real_sqlite(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.crypto_settings = {"Enabled": False}
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            server_side, client_side = socket.socketpair()
            client_side.settimeout(2)
            self.addCleanup(client_side.close)

            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: 4242), \
                 patch.object(Helpers, "randomStringDigits", lambda self: "tcp-token"), \
                 patch.object(Helpers, "randomClubID", lambda self: 555555), \
                 patch.object(EventSlots, "Timer", lambda self: 49020), \
                 patch("Logic.NotificationFactory.time.time", return_value=1000):
                thread = ClientThread(server_side, ("local", 0), server)
                thread.start()

                                                                               
                hello = packet(10100)
                for byte in hello:
                    client_side.sendall(bytes([byte]))
                self.assertEqual(receive_packet(client_side)[0], 20100)

                login = packet(10101, login_payload())
                cut_points = [1, 2, 5, 9, 17, 31, len(login)]
                previous = 0
                for cut in cut_points:
                    client_side.sendall(login[previous:cut])
                    previous = cut

                login_ok = receive_packet(client_side)
                own_home = receive_packet(client_side)
                self.assertEqual((login_ok[0], login_ok[1]), (20104, 1))
                self.assertEqual(own_home[0], 24101)
                self.assertGreater(len(own_home[2]), 100)
                home_reader = BSMessageReader(own_home[2])
                daily_values = [home_reader.read_Vint() for _ in range(7)]
                self.assertEqual(daily_values[-1], 99999)
                star_shelly = bytes.fromhex("019e01b485d41b")
                wizard_barley = bytes.fromhex("019e01bb85d41b")
                login_notifications = bytes.fromhex(
                    "029e01b485d41b9e01bb85d41b"
                )
                self.assertIn(
                    int32(0) + int32(4242) + login_notifications,
                    own_home[2],
                )

                                                                             
                                                                            
                client_side.sendall(packet(10108))
                keepalive_ok = receive_packet(client_side)
                self.assertEqual((keepalive_ok[0], keepalive_ok[2]), (20108, b""))

                client_side.sendall(packet(10212, string("Ok") + vint(1)))
                renamed = receive_packet(client_side)
                self.assertEqual(renamed[0], 24111)
                self.assertEqual(renamed[2], vint(201) + string("Ok") + vint(1))
                client_side.sendall(packet(14109, b"\x01"))
                returned_home = receive_packet(client_side)
                self.assertEqual(returned_home[0], 24101)
                self.assertEqual(len(returned_home[2]), len(own_home[2]) - 3)
                self.assertIn(string("Ok"), returned_home[2])
                self.assertNotIn(string("Guest"), returned_home[2])

                create_payload = string("TCP Club") + string("Desc")
                create_payload += b"".join(vint(value) for value in (8, 1, 1, 0))
                client_side.sendall(packet(14301, create_payload))
                self.assertEqual(
                    [receive_packet(client_side)[0] for _ in range(3)],
                    [24333, 24399, 24311],
                )
                edit_payload = string("TCP Edited")
                edit_payload += b"".join(vint(value) for value in (8, 1, 1, 0))
                client_side.sendall(packet(14316, edit_payload))
                self.assertEqual(
                    [receive_packet(client_side)[0] for _ in range(2)],
                    [24333, 24399],
                )
                client_side.sendall(packet(10108))
                self.assertEqual(receive_packet(client_side)[0], 20108)

                with patch("builtins.print") as printed:
                    client_side.close()
                    thread.join(2)
                self.assertFalse(thread.is_alive())
                self.assertTrue(
                    any("client EOF" in str(call) for call in printed.call_args_list)
                )

                with closing(sqlite3.connect(database_path)) as connection:
                    saved = connection.execute(
                        "SELECT token, online, name, playerExp, clubID, clubRole "
                        "FROM players WHERE lowID = 4242"
                    ).fetchone()
                    membership = connection.execute(
                        "SELECT role FROM club_members "
                        "WHERE club_id = 555555 AND player_id = 4242"
                    ).fetchone()
                    club_description = connection.execute(
                        "SELECT description FROM clubs WHERE id = 555555"
                    ).fetchone()
                self.assertEqual(saved, ("tcp-token", 0, "Ok", 99999, 555555, 2))
                self.assertEqual(membership, (2,))
                self.assertEqual(club_description, ("TCP Edited",))

                                                                             
                                                                           
                second_server, second_client = socket.socketpair()
                second_client.settimeout(2)
                self.addCleanup(second_client.close)
                second_thread = ClientThread(second_server, ("local", 0), server)
                second_thread.start()
                second_client.sendall(packet(10100))
                self.assertEqual(receive_packet(second_client)[0], 20100)
                second_client.sendall(
                    packet(
                        10101,
                        login_payload(low_id=4242, token="tcp-token"),
                    )
                )
                self.assertEqual(receive_packet(second_client)[0], 20104)
                second_home = receive_packet(second_client)
                self.assertEqual(second_home[0], 24101)
                self.assertEqual(second_home[2], returned_home[2])
                my_alliance = receive_packet(second_client)
                self.assertEqual(my_alliance[0], 24399)
                alliance_reader = BSMessageReader(my_alliance[2])
                self.assertEqual(
                    [alliance_reader.read_Vint() for _ in range(4)],
                    [1, 1, 25, 2],
                )
                self.assertEqual(
                    (alliance_reader.read_int(), alliance_reader.read_int()),
                    (0, 555555),
                )
                self.assertEqual(alliance_reader.read_string(), "TCP Club")
                self.assertEqual(
                    [alliance_reader.read_Vint() for _ in range(7)],
                    [8, 1, 1, 1, 999, 0, 0],
                )
                self.assertEqual(alliance_reader.read_string(), "RU")
                self.assertEqual(alliance_reader.read_Vint(), 1)
                self.assertEqual(alliance_reader.read(), b"")
                alliance_stream = receive_packet(second_client)
                self.assertEqual(alliance_stream[0], 24311)
                self.assertEqual(BSMessageReader(alliance_stream[2]).read_Vint(), 1)
                second_client.sendall(packet(14403, vint(1) + vint(1)))
                leaderboard = receive_packet(second_client)
                self.assertEqual(leaderboard[0], 24403)
                leaderboard_reader = BSMessageReader(leaderboard[2])
                self.assertEqual(
                    [leaderboard_reader.read_Vint(), leaderboard_reader.read_Vint()],
                    [1, 0],
                )
                self.assertEqual(leaderboard_reader.read_string(), "BR")
                self.assertEqual(leaderboard_reader.read_Vint(), 1)
                second_client.sendall(packet(14110, battle_end_payload()))
                battle_result = receive_packet(second_client)
                self.assertEqual(battle_result[0], 23456)
                second_client.sendall(packet(14102, notification_claim_payload()))
                skin_reward = receive_packet(second_client)
                self.assertEqual(skin_reward[0], 24111)
                reward_reader = BSMessageReader(skin_reward[2])
                self.assertEqual(
                    [reward_reader.read_Vint() for _ in range(17)],
                    [203, 0, 1, 100, 1, 1, 0, 9, 29, 52, 0, 0, 0, 1, 0, 0, 0],
                )
                self.assertEqual(reward_reader.read(), b"")
                second_client.sendall(
                    packet(14102, notification_delete_payload())
                )
                wizard_reward = receive_packet(second_client)
                self.assertEqual(wizard_reward[0], 24111)
                wizard_reader = BSMessageReader(wizard_reward[2])
                self.assertEqual(
                    [wizard_reader.read_Vint() for _ in range(17)],
                    [203, 0, 1, 100, 1, 1, 0, 9, 29, 59, 0, 0, 0, 1, 0, 0, 0],
                )
                self.assertEqual(wizard_reader.read(), b"")
                second_client.sendall(packet(14109, b"\x01"))
                claimed_home = receive_packet(second_client)
                self.assertEqual(claimed_home[0], 24101)
                self.assertNotIn(star_shelly, claimed_home[2])
                self.assertNotIn(wizard_barley, claimed_home[2])
                self.assertIn(
                    int32(0) + int32(4242) + vint(0), claimed_home[2]
                )
                second_client.sendall(packet(10108))
                self.assertEqual(receive_packet(second_client)[0], 20108)
                second_client.close()
                second_thread.join(2)
                self.assertFalse(second_thread.is_alive())

                with closing(sqlite3.connect(database_path)) as connection:
                    count = connection.execute(
                        "SELECT COUNT(*) FROM players WHERE lowID = 4242"
                    ).fetchone()[0]
                    reward_row = connection.execute(
                        "SELECT UnlockedSkins, Notifications "
                        "FROM players WHERE lowID = 4242"
                    ).fetchone()
                self.assertEqual(count, 1)
                unlocked_skins = json.loads(reward_row[0])["Skins"]
                self.assertEqual(unlocked_skins.count(52), 1)
                self.assertEqual(unlocked_skins.count(59), 1)
                notifications = json.loads(reward_row[1])
                self.assertEqual(notifications["0"]["Type"], 94)
                self.assertEqual(notifications["0"]["SkinID"], 52)
                self.assertTrue(notifications["0"]["Read"])
                self.assertEqual(notifications["1"]["Type"], 94)
                self.assertEqual(notifications["1"]["SkinID"], 59)
                self.assertTrue(notifications["1"]["Read"])


class GemPersistenceTcpTests(unittest.TestCase):
    def test_spent_gems_survive_full_reconnect_and_second_home(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.crypto_settings = {"Enabled": False}
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            server_side, client_side = socket.socketpair()
            client_side.settimeout(3)
            self.addCleanup(client_side.close)

            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: 4244), \
                 patch.object(Helpers, "randomStringDigits", lambda self: "persistent-token"):
                thread = ClientThread(server_side, ("local", 0), server)
                thread.start()
                client_side.sendall(packet(10100))
                self.assertEqual(receive_packet(client_side)[0], 20100)
                client_side.sendall(packet(10101, login_payload()))
                login_ok = receive_packet(client_side)
                self.assertEqual(receive_packet(client_side)[0], 24101)

                identity = BSMessageReader(login_ok[2])
                self.assertEqual(identity.read_int(), 0)
                low_id = identity.read_int()
                self.assertEqual(identity.read_int(), 0)
                self.assertEqual(identity.read_int(), low_id)
                token = identity.read_string()
                self.assertEqual((low_id, token), (4244, "persistent-token"))

                turn_payload = (
                    vint(0) + vint(1) + vint(0) + vint(1) + vint(521)
                    + vint(1) + vint(1) + vint(-1) + vint(-1) + vint(2)
                    + b"\xff" * 4
                )
                client_side.sendall(packet(14102, turn_payload))
                client_side.sendall(packet(10108))
                self.assertEqual(receive_packet(client_side)[0], 20108)

                with closing(sqlite3.connect(database_path)) as connection:
                    saved = connection.execute(
                        "SELECT gems, gold FROM players WHERE lowID = 4244"
                    ).fetchone()
                self.assertEqual(saved, (859, 1300))

                client_side.close()
                thread.join(3)
                self.assertFalse(thread.is_alive())

                second_server, second_client = socket.socketpair()
                second_client.settimeout(3)
                self.addCleanup(second_client.close)
                second_thread = ClientThread(second_server, ("local", 0), server)
                second_thread.start()
                second_client.sendall(packet(10100))
                self.assertEqual(receive_packet(second_client)[0], 20100)

                observed = []
                original_send = OwnHomeDataMessage.send

                def capture_home(message):
                    observed.append({
                        "low_id": message.player.low_id,
                        "gems": message.player.gems,
                        "gold": message.player.gold,
                    })
                    return original_send(message)

                with patch.object(OwnHomeDataMessage, "send", capture_home):
                    second_client.sendall(
                        packet(10101, login_payload(low_id=low_id, token=token))
                    )
                    self.assertEqual(receive_packet(second_client)[0], 20104)
                    self.assertEqual(receive_packet(second_client)[0], 24101)

                self.assertEqual(observed, [{
                    "low_id": 4244, "gems": 859, "gold": 1300,
                }])
                second_client.close()
                second_thread.join(3)
                self.assertFalse(second_thread.is_alive())

                with closing(sqlite3.connect(database_path)) as connection:
                    account_count = connection.execute(
                        "SELECT COUNT(*) FROM players WHERE lowID = 4244"
                    ).fetchone()[0]
                self.assertEqual(account_count, 1)


class GameRoomTcpFlowTests(unittest.TestCase):
    def read_room(self, payload):
        reader = BSMessageReader(payload)
        state = reader.read_Vint()
        practice = reader.read_boolean()
        capacity = reader.read_Vint()
        reader.read_int()
        room_id = reader.read_int()
        reader.read_Vint()
        reader.read_boolean()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        reader.read_Vint()
        members = []
        for _ in range(reader.read_Vint()):
            host = reader.read_boolean()
            reader.read_int()
            low_id = reader.read_int()
            name = reader.read_string()
            reader.read_Vint()
            for _ in range(2):
                reader.read_Vint()
                reader.read_Vint()
            for _ in range(4):
                reader.read_Vint()
            ready = reader.read_boolean()
            reader.read_Vint()
            reader.read_Vint()
            members.append({
                "id": low_id,
                "name": name,
                "host": host,
                "ready": ready,
            })
        invites = []
        for _ in range(reader.read_Vint()):
            reader.read_int()
            sender_id = reader.read_int()
            reader.read_int()
            recipient_id = reader.read_int()
            name = reader.read_string()
            invite_type = reader.read_Vint()
            status = reader.read_Vint()
            invites.append((sender_id, recipient_id, name, invite_type, status))
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read(), b"")
        return {
            "id": room_id,
            "state": state,
            "practice": practice,
            "capacity": capacity,
            "members": members,
            "invites": invites,
        }

    def test_two_accounts_invite_accept_and_return_over_tcp(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.crypto_settings = {"Enabled": False}
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)
        sessions = []
        threads = []

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            account_ids = iter((5101, 5102))
            tokens = iter(("room-owner-token", "room-guest-token"))
            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: next(account_ids)), \
                 patch.object(Helpers, "randomStringDigits", lambda self: next(tokens)):
                def open_session():
                    server_side, client_side = socket.socketpair()
                    client_side.settimeout(3)
                    sessions.append(client_side)
                    thread = ClientThread(server_side, ("local", 0), server)
                    threads.append(thread)
                    thread.start()
                    client_side.sendall(packet(10100))
                    self.assertEqual(receive_packet(client_side)[0], 20100)
                    client_side.sendall(packet(10101, login_payload()))
                    self.assertEqual(receive_packet(client_side)[0], 20104)
                    self.assertEqual(receive_packet(client_side)[0], 24101)
                    return client_side

                try:
                    owner = open_session()
                    guest = open_session()
                    create = b"".join(vint(value) for value in (0, 7, 0)) + b"\x00"
                    owner.sendall(packet(14350, create))
                    created_packet = receive_packet(owner)
                    self.assertEqual(created_packet[0], 24124)
                    created = self.read_room(created_packet[2])
                    self.assertGreater(created["id"], 0)
                    self.assertEqual(
                        [member["id"] for member in created["members"]], [5101]
                    )

                    owner.sendall(packet(14365, vint(0) + vint(5102) + vint(7)))
                    invited_packet = receive_packet(owner)
                    self.assertEqual(invited_packet[0], 24124)
                    invited = self.read_room(invited_packet[2])
                    self.assertEqual(len(invited["invites"]), 1)
                    self.assertEqual(invited["invites"][0][:2], (5101, 5102))
                    self.assertEqual(receive_packet(guest)[0], 24589)

                    response = vint(7) + int32(0) + int32(created["id"]) + b"\x01"
                    guest.sendall(packet(14479, response))
                    owner_accepted = receive_packet(owner)
                    guest_accepted = receive_packet(guest)
                    self.assertEqual(owner_accepted[0], 24124)
                    self.assertEqual(guest_accepted[0], 24124)
                    owner_room = self.read_room(owner_accepted[2])
                    guest_room = self.read_room(guest_accepted[2])
                    self.assertEqual(owner_room["id"], created["id"])
                    self.assertEqual(guest_room["id"], created["id"])
                    self.assertEqual(
                        [member["id"] for member in guest_room["members"]],
                        [5101, 5102],
                    )
                    self.assertEqual(guest_room["invites"], [])

                    guest.sendall(packet(14109, b"\x01"))
                    returned_packet = receive_packet(guest)
                    self.assertEqual(returned_packet[0], 24124)
                    returned = self.read_room(returned_packet[2])
                    self.assertEqual(returned["id"], created["id"])
                    self.assertEqual(
                        [member["id"] for member in returned["members"]],
                        [5101, 5102],
                    )
                    guest.sendall(packet(10108))
                    self.assertEqual(receive_packet(guest)[0], 20108)
                    guest.sendall(packet(14367, int32(0) + int32(created["id"])))
                    error_packet = receive_packet(guest)
                    self.assertEqual(error_packet[0], 24129)
                    self.assertEqual(error_packet[2], vint(1) + vint(1))
                    guest.sendall(packet(10108))
                    self.assertEqual(receive_packet(guest)[0], 20108)

                    with closing(sqlite3.connect(database_path)) as connection:
                        members = connection.execute(
                            "SELECT low_id FROM game_room_members "
                            "WHERE room_id = ? ORDER BY low_id",
                            (created["id"],),
                        ).fetchall()
                    self.assertEqual(members, [(5101,), (5102,)])
                finally:
                    for session in sessions:
                        session.close()
                    for thread in threads:
                        thread.join(3)
                    self.assertTrue(all(not thread.is_alive() for thread in threads))


    def test_join_or_create_by_code_survives_reconnect(self):
        from Logic.TeamCode import TeamCode
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.crypto_settings = {"Enabled": False}
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)
        sessions = []
        threads = []

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            account_ids = iter((5201, 5202))
            tokens = iter(("code-owner-token", "code-guest-token"))
            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: next(account_ids)), \
                 patch.object(Helpers, "randomStringDigits", lambda self: next(tokens)):
                def open_session(low_id=0, token=""):
                    server_side, client_side = socket.socketpair()
                    client_side.settimeout(3)
                    sessions.append(client_side)
                    thread = ClientThread(server_side, ("local", 0), server)
                    threads.append(thread)
                    thread.start()
                    client_side.sendall(packet(10100))
                    self.assertEqual(receive_packet(client_side)[0], 20100)
                    client_side.sendall(packet(10101, login_payload(low_id, token)))
                    self.assertEqual(receive_packet(client_side)[0], 20104)
                    self.assertEqual(receive_packet(client_side)[0], 24101)
                    return client_side

                try:
                    owner = open_session()
                    guest = open_session()
                    owner.sendall(packet(14371, string("X")))
                    created_packet = receive_packet(owner)
                    self.assertEqual(created_packet[0], 24124)
                    created = self.read_room(created_packet[2])
                    self.assertGreater(created["id"], 0)
                    self.assertEqual(
                        [member["id"] for member in created["members"]], [5201]
                    )
                    code = TeamCode.to_code(0, created["id"])
                    self.assertEqual(TeamCode.to_id(code), (0, created["id"]))

                    guest.sendall(packet(14371, string("X!")))
                    self.assertEqual(receive_packet(guest)[0], 24129)
                    guest.sendall(packet(10108))
                    self.assertEqual(receive_packet(guest)[0], 20108)

                    guest.sendall(packet(14371, string(code)))
                    guest_packet = receive_packet(guest)
                    owner_packet = receive_packet(owner)
                    self.assertEqual(guest_packet[0], 24124)
                    self.assertEqual(owner_packet[0], 24124)
                    guest_room = self.read_room(guest_packet[2])
                    owner_room = self.read_room(owner_packet[2])
                    self.assertEqual(guest_room["id"], created["id"])
                    self.assertEqual(owner_room["id"], created["id"])
                    self.assertEqual(
                        [member["id"] for member in guest_room["members"]],
                        [5201, 5202],
                    )

                    with closing(sqlite3.connect(database_path)) as connection:
                        saved = connection.execute(
                            "SELECT roomID FROM players WHERE lowID = 5202"
                        ).fetchone()
                        members = connection.execute(
                            "SELECT low_id FROM game_room_members "
                            "WHERE room_id = ? ORDER BY low_id", (created["id"],)
                        ).fetchall()
                    self.assertEqual(saved, (created["id"],))
                    self.assertEqual(members, [(5201,), (5202,)])

                    guest.close()
                    threads[1].join(3)
                    self.assertFalse(threads[1].is_alive())
                    owner_update = receive_packet(owner)
                    self.assertEqual(owner_update[0], 24124)
                    remaining = self.read_room(owner_update[2])
                    self.assertEqual(
                        [member["id"] for member in remaining["members"]], [5201]
                    )

                    reconnected = open_session(5202, "code-guest-token")
                    reconnected.sendall(packet(14109, b"\x01"))
                    self.assertEqual(receive_packet(reconnected)[0], 24101)
                    reconnected.sendall(packet(14371, string(code)))
                    rejoined_packet = receive_packet(reconnected)
                    self.assertEqual(rejoined_packet[0], 24124)
                    rejoined = self.read_room(rejoined_packet[2])
                    self.assertEqual(rejoined["id"], created["id"])
                    self.assertEqual(
                        [member["id"] for member in rejoined["members"]],
                        [5201, 5202],
                    )
                    owner_rejoined = receive_packet(owner)
                    self.assertEqual(owner_rejoined[0], 24124)
                    self.assertEqual(
                        [member["id"] for member in self.read_room(owner_rejoined[2])["members"]],
                        [5201, 5202],
                    )
                finally:
                    for session in sessions:
                        session.close()
                    for thread in threads:
                        thread.join(3)
                    self.assertTrue(all(not thread.is_alive() for thread in threads))


class EncryptedTcpFlowTests(unittest.TestCase):
    def test_real_login_home_and_keepalive_over_v13_crypto(self):
        from main import ClientThread, Server

        server = Server("127.0.0.1", 0)
        server.Clients = {"ClientCounts": 0, "Clients": {}}
        self.addCleanup(server.server.close)

        with tempfile.TemporaryDirectory() as directory:
            database_path = str(Path(directory) / "players.db")
            server_side, client_side = socket.socketpair()
            client_side.settimeout(2)
            self.addCleanup(client_side.close)

            with patch.object(DataBase, "_database_path", lambda: database_path), \
                 patch.object(Helpers, "randomID", lambda self: 4243), \
                 patch.object(Helpers, "randomStringDigits", lambda self: "crypto-token"):
                thread = ClientThread(server_side, ("local", 0), server)
                thread.start()

                connection = client_side
                connection.sendall(packet(10100))
                self.assertEqual(receive_packet(connection)[:2], (20100, 0))

                client = Crypto({"Enabled": True})
                session_key = bytes(range(24))
                client_nonce = bytes(range(24, 48))
                nonce = Nonce(
                    clientKey=client.client_pk,
                    serverKey=client.server_key,
                )
                encrypted_login = client.client_pk + NaCl19.secretbox(
                    session_key + client_nonce + login_payload(),
                    bytes(nonce),
                    client.shared_key,
                )
                login_packet = packet(10101, encrypted_login)
                connection.sendall(login_packet[:13])
                connection.sendall(login_packet[13:67])
                connection.sendall(login_packet[67:])

                login_ok_id, _, login_ok = receive_packet(connection)
                home_id, _, home = receive_packet(connection)
                self.assertEqual(login_ok_id, 20104)
                self.assertEqual(home_id, 24101)

                login_nonce = Nonce(
                    client_nonce,
                    clientKey=client.client_pk,
                    serverKey=client.server_key,
                )
                session = NaCl19.secretbox_open(
                    login_ok, bytes(login_nonce), client.shared_key
                )
                server_nonce = session[:24]
                shared_en = session[24:56]
                self.assertGreater(len(session[56:]), 100)

                home_nonce = Nonce(server_nonce)
                home_nonce.increment()
                raw_home = NaCl19.secretbox_open(
                    home, bytes(home_nonce), shared_en
                )
                self.assertGreater(len(raw_home), 100)

                next_client_nonce = Nonce(client_nonce)
                next_client_nonce.increment()
                analytics_payload = string("Economy") + string('{"test":true}')
                analytics = NaCl19.secretbox(
                    analytics_payload, bytes(next_client_nonce), shared_en
                )
                connection.sendall(packet(10110, analytics))

                                                                          
                                                                            
                                                                     
                next_client_nonce.increment()
                short_turn_payload = (
                    vint(0) + vint(1) + vint(0) + vint(1) + vint(506)
                    + b"\x00\x00\x00"
                )
                self.assertEqual(len(short_turn_payload), 9)
                short_turn = NaCl19.secretbox(
                    short_turn_payload, bytes(next_client_nonce), shared_en
                )
                self.assertEqual(len(short_turn), 25)
                connection.sendall(packet(14102, short_turn))

                next_client_nonce.increment()
                keepalive = NaCl19.secretbox(
                    b"", bytes(next_client_nonce), shared_en
                )
                connection.sendall(packet(10108, keepalive))
                keepalive_ok_id, _, keepalive_ok = receive_packet(connection)
                self.assertEqual(keepalive_ok_id, 20108)
                self.assertEqual(len(keepalive_ok), 16)
                home_nonce.increment()
                self.assertEqual(
                    NaCl19.secretbox_open(
                        keepalive_ok, bytes(home_nonce), shared_en
                    ),
                    b"",
                )

                connection.close()
                thread.join(2)
                self.assertFalse(thread.is_alive())
                self.assertEqual(server.Clients["ClientCounts"], 0)

                with closing(sqlite3.connect(database_path)) as check:
                    saved = check.execute(
                        "SELECT token, online, progression FROM players WHERE lowID = 4243"
                    ).fetchone()
                self.assertEqual(saved[:2], ("crypto-token", 0))
                progression = json.loads(saved[2])
                self.assertNotIn("shopOffers", progression)
                self.assertEqual(len(progression["shop"]["offers"]), 2)
                self.assertEqual(progression["shop"]["billing"], {
                    "transactions": {}, "bundles": {},
                })


if __name__ == "__main__":
    unittest.main(verbosity=2)
