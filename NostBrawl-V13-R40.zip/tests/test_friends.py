import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.FriendService import FriendService
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Friend.AcceptFriendMessage import AcceptFriendMessage
from Packets.Messages.Client.Friend.AddFriend import AddFriend
from Packets.Messages.Client.Friend.AskForAddableFriendsMessage import AskForAddableFriendsMessage
from Packets.Messages.Client.Friend.AskForFriendSuggestionsMessage import AskForFriendSuggestionsMessage
from Packets.Messages.Client.Friend.FacebookConnect import FacebookConnect
from Packets.Messages.Client.Friend.RemoveFriendMessage import RemoveFriendMessage
from Packets.Messages.Client.Friend.UnlinkFacebookAcount import UnlinkFacebookAcount
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage
from Packets.Messages.Server.Friend.FriendSuggestionsMessage import FriendSuggestionsMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))

    def payload(self, index=-1):
        packet = self.packets[index]
        message_id = int.from_bytes(packet[:2], "big")
        length = int.from_bytes(packet[2:5], "big")
        if length != len(packet) - 7:
            raise AssertionError("Invalid packet length")
        return message_id, packet[7:]


def int_payload(*values, strings=()):
    writer = Writer(None)
    for value in values:
        writer.writeInt(value)
    for value in strings:
        writer.writeString(value)
    return writer.buffer


def facebook_payload(facebook_id, token):
    writer = Writer(None)
    writer.writeVint(0)
    writer.writeString(facebook_id)
    writer.writeString(token)
    return writer.buffer


def read_friend(reader):
    result = {"high_id": reader.read_int(), "low_id": reader.read_int()}
    result["strings"] = [reader.read_string() for _ in range(4)]
    result["ints"] = [reader.read_int() for _ in range(6)]
    result["has_club"] = reader.read_byte()
    if result["has_club"]:
        result["club"] = {
            "high_id": reader.read_int(),
            "low_id": reader.read_int(),
            "before_name": reader.read_int(),
            "name": reader.read_string(),
            "after_name": [reader.read_int(), reader.read_int()],
        }
    result["final_string"] = reader.read_string()
    result["profile_icon"] = reader.read_int()
    result["final_int"] = reader.read_int()
    return result


class FriendTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.players = [self.make_account(index) for index in range(1, 4)]
        self.clients = [CaptureClient() for _ in range(3)]
        for index, player in enumerate(self.players):
            player.ClientDict = {"Clients": {}}
            for other_index, other in enumerate(self.players):
                if other_index != index:
                    player.ClientDict["Clients"][str(other.low_id)] = {
                        "SocketInfo": self.clients[other_index],
                        "Crypto": None,
                    }

    def make_account(self, low_id):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = "friend-token-%d" % low_id
        player.name = "Friend %d" % low_id
        player.profile_icon = low_id
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def reload(self, source):
        player = Players(SimpleNamespace())
        player.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
        return player

    def test_factory_and_native_friend_decoders(self):
        self.assertIs(packets[10501], AcceptFriendMessage)
        self.assertIs(packets[10502], AddFriend)
        self.assertIs(packets[10503], AskForAddableFriendsMessage)
        self.assertIs(packets[10506], RemoveFriendMessage)
        with self.assertRaises(ValueError):
            AddFriend(self.clients[0], self.players[0], int_payload(0, 2)).decode()
        with self.assertRaises(ValueError):
            AcceptFriendMessage(
                self.clients[1], self.players[1], int_payload(0, 1, 0)
            ).decode()
        with self.assertRaises(ValueError):
            RemoveFriendMessage(
                self.clients[0], self.players[0], int_payload(0, 2, 0)
            ).decode()
        self.assertEqual(FriendService.friends(self.players[0]), [])

    def test_request_accept_remove_notifications_and_relogin(self):
        first, second, _ = self.players
        message = AddFriend(self.clients[0], first, int_payload(0, 2, 0, 0))
        message.decode()
        result = message.process()
        self.assertEqual(result["state"], FriendService.OUTGOING)
        self.assertEqual(FriendService.friends(first)[0]["state"], 2)
        self.assertEqual(FriendService.friends(second)[0]["state"], 3)
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20106)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(read_friend(reader)["ints"][0], 2)
        self.assertEqual(reader.read(1), b"")
        message_id, raw = self.clients[1].payload()
        self.assertEqual(message_id, 20106)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(read_friend(reader)["ints"][0], 3)
        self.assertEqual(reader.read(1), b"")

        duplicate = AddFriend(self.clients[0], first, int_payload(0, 2, 0, 0))
        duplicate.decode()
        duplicate.process()
        self.assertEqual(len(FriendService.friends(first)), 1)
        accept = AcceptFriendMessage(self.clients[1], second, int_payload(0, 1))
        accept.decode()
        accept.process()
        self.assertEqual(FriendService.friends(first)[0]["state"], 4)
        self.assertEqual(FriendService.friends(second)[0]["state"], 4)
        reloaded = self.reload(first)
        self.assertEqual([(entry["low_id"], entry["state"]) for entry in FriendService.friends(reloaded)], [(2, 4)])

        remove = RemoveFriendMessage(self.clients[0], first, int_payload(0, 2))
        remove.decode()
        remove.process()
        self.assertEqual(FriendService.friends(first), [])
        self.assertEqual(FriendService.friends(second), [])
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20106)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_byte(), 1)
        read_friend(reader)
        self.assertEqual(reader.read(1), b"")

    def test_friend_list_suggestions_and_club_wire(self):
        first, second, third = self.players
        with DataBase._connection() as connection:
            connection.execute(
                "INSERT INTO clubs(id, name, badge_id) VALUES(55, 'Native Friends', 12)"
            )
            connection.execute(
                "INSERT INTO club_members(club_id, player_id, role) VALUES(55, 2, 2)"
            )
            connection.execute("UPDATE players SET clubID = 55, clubRole = 2 WHERE lowID = 2")
        add = AddFriend(self.clients[0], first, int_payload(0, 2, 0, 0))
        add.decode()
        add.process()
        FriendListMessage(self.clients[0], first).send()
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20105)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 1)
        self.assertEqual(reader.read_byte(), 1)
        self.assertEqual(reader.read_int(), 1)
        entry = read_friend(reader)
        self.assertEqual(reader.read(1), b"")
        self.assertEqual(entry["low_id"], 2)
        self.assertEqual(entry["strings"], ["Friend 2", "", "", ""])
        self.assertEqual(entry["ints"], [2, second.trophies, 0, 0, 0, 0])
        self.assertEqual(entry["club"]["low_id"], 55)
        self.assertEqual(entry["club"]["name"], "Native Friends")
        self.assertEqual(entry["profile_icon"], 28000002)

        entries = FriendService.suggestions(first)
        self.assertEqual([entry["low_id"] for entry in entries], [3])
        FriendSuggestionsMessage(self.clients[0], first, entries).send()
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20199)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(read_friend(reader)["low_id"], 3)
        self.assertEqual(reader.read(1), b"")
        AskForFriendSuggestionsMessage(self.clients[2], third, b"").process()
        self.assertEqual(self.clients[2].payload()[0], 20199)

    def test_addable_friends_and_facebook_persistence(self):
        first, second, _ = self.players
        connect = FacebookConnect(
            self.clients[1], second, facebook_payload("facebook-second", "secret-token")
        )
        connect.decode()
        connect.process()
        reloaded_second = self.reload(second)
        self.assertEqual(reloaded_second.FacebookID, "facebook-second")
        self.assertEqual(reloaded_second.FacebookToken, "secret-token")
        self.assertEqual(reloaded_second.IsFacebookLinked, 1)

        writer = Writer(None)
        writer.writeInt(1)
        writer.writeString("facebook-second")
        writer.writeInt(0)
        ask = AskForAddableFriendsMessage(self.clients[0], first, writer.buffer)
        ask.decode()
        entries = ask.process()
        self.assertEqual([entry["low_id"] for entry in entries], [2])
        message_id, raw = self.clients[0].payload()
        self.assertEqual(message_id, 20107)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_int(), 1)
        self.assertEqual(reader.read_int(), 0)
        self.assertEqual(reader.read_int(), 2)
        self.assertEqual(reader.read_string(), "Friend 2")
        self.assertEqual(reader.read_int(), 1)
        self.assertEqual(reader.read_string(), "facebook-second")
        self.assertEqual(reader.read_string(), "")
        self.assertEqual(reader.read(1), b"")

        unlink = UnlinkFacebookAcount(
            self.clients[1], second, facebook_payload("facebook-second", "secret-token")
        )
        unlink.decode()
        unlink.process()
        self.assertEqual(FriendService.addable(first, ["facebook-second"], []), [])
        self.assertEqual(self.reload(second).FacebookID, "")

    def test_legacy_friend_ids_migrate_once_to_reciprocal_relations(self):
        first, second, _ = self.players
        first.Friends = {"0": {"lowID": 2}, "1": {"lowID": 2}}
        DataBase.replaceValue(SimpleNamespace(player=first), "Friends", first.Friends)
        entries = FriendService.friends(first)
        self.assertEqual([(entry["low_id"], entry["state"]) for entry in entries], [(2, 4)])
        self.assertEqual(FriendService.friends(second)[0]["state"], 4)
        self.assertEqual(first.Friends, {})
        with DataBase._connection() as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM friend_relations").fetchone()[0], 2)
            stored = json.loads(connection.execute("SELECT Friends FROM players WHERE lowID = 1").fetchone()[0])
        self.assertEqual(stored, {})
        self.assertEqual(len(FriendService.friends(first)), 1)


if __name__ == "__main__":
    unittest.main()
