import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from Database.DatabaseManager import DataBase
from Logic.BattleEnd import BattleEndError, BattleEndService
from Logic.BattleResultAdapter import apply_battle_result_rewards
from Logic.Player import Players
from Packets.Messages.Client.Battle.AskForBattleEndMessage import AskForBattleEndMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))

    def payload(self, index=-1):
        packet = self.packets[index]
        self.message_id = int.from_bytes(packet[:2], "big")
        self.message_length = int.from_bytes(packet[2:5], "big")
        if self.message_length != len(packet) - 7:
            raise AssertionError("Invalid captured packet length")
        return packet[7:]


def make_battle(map_id=0, count=6, rank=1, result=0, submitted=16, names=None, first_brawler=None, first_skin=None):
    writer = Writer(None)
    for value in (result, submitted, rank, map_id, 15, count):
        writer.writeVint(value)
    for index in range(count):
        brawler = first_brawler if index == 0 and first_brawler is not None else index % 20
        skin = first_skin if index == 0 and first_skin is not None else (29 if index == 1 else 0)
        writer.writeScId(16, brawler)
        if index == 0 or skin:
            writer.writeScId(29, skin)
        else:
            writer.writeVint(0)
        writer.writeVint(index % 2)
        writer.writeByte(1 if index == 0 else 0)
        writer.writeString(names[index] if names else ("Local" if index == 0 else f"Bot {index}"))
    return writer.buffer


class BattleAccountTestCase(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.player = self.make_account(1, "battle-token")

    def make_account(self, low_id, token):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = token
        player.name = "Local"
        player.tutorial = 2
        player.player_experience = 0
        player.battle_tokens = 200
        player.tokensdoubler = 0
        player.brawl_boxes = 0
        player.big_boxes = 0
        player.trophies = 0
        player.highest_trophies = 0
        player.brawlers_trophies = {"0": 0}
        player.brawlers_trophies_in_rank = {"0": 0}
        owner = SimpleNamespace(player=player)
        DataBase.createAccount(owner)
        DataBase.replaceValues(owner, {
            "playerExp": 0,
            "battleTokens": 200,
            "tokensdoubler": 0,
            "brawlBoxes": 0,
            "bigBoxes": 0,
            "trophies": 0,
            "highest_trophies": 0,
            "brawlersTrophies": {"0": 0},
            "brawlersTrophiesForRank": {"0": 0},
        })
        return player

    def reload(self, player=None):
        source = player or self.player
        loaded = Players(SimpleNamespace())
        loaded.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=loaded)))
        return loaded

    def process(self, payload, player=None):
        player = player or self.player
        client = CaptureClient()
        message = AskForBattleEndMessage(client, player, payload)
        message.decode()
        result = message.process()
        return result, client, message


class BattleEndProtocolTests(BattleAccountTestCase):
    def test_v13_header_reads_map_before_location_reference(self):
        message = AskForBattleEndMessage(None, self.player, make_battle(map_id=7))
        message.decode()
        self.assertEqual(message.battle.map_id, 7)
        self.assertEqual(message.battle.location_id, 15)
        self.assertEqual(message.read(), b"")

    def test_decoder_preserves_participants_and_routes_all_v13_modes(self):
        cases = (
            (0, 6, 0, "BountyHunter"),
            (13, 10, 2, "BattleRoyale"),
            (28, 10, 5, "BattleRoyaleTeam"),
            (27, 3, 3, "Survival"),
            (21, 6, 4, "BossFight"),
            (57, 3, 6, "Raid"),
        )
        for map_id, count, mode, location_mode in cases:
            with self.subTest(mode=mode):
                payload = make_battle(map_id, count)
                message = AskForBattleEndMessage(None, self.player, payload)
                message.decode()
                battle = message.battle
                self.assertEqual(battle.game_mode, mode)
                self.assertEqual(battle.location_game_mode, location_mode)
                self.assertEqual(len(battle.participants), count)
                self.assertEqual(battle.participants[1].name, "Bot 1")
                self.assertEqual(battle.participants[1].skin_id, 29)
                self.assertEqual(message.read(), b"")

    def test_truncated_trailing_and_wrong_count_payloads_are_rejected(self):
        payload = make_battle()
        for invalid in (payload[:-1], payload + b"\x00", make_battle(count=3)):
            with self.subTest(size=len(invalid)):
                message = AskForBattleEndMessage(None, self.player, invalid)
                with self.assertRaises(BattleEndError):
                    message.decode()
        for payload in (
            make_battle(first_brawler=999),
            make_battle(first_skin=99999),
        ):
            with self.subTest(size=len(payload)):
                with self.assertRaises(BattleEndError):
                    AskForBattleEndMessage(None, self.player, payload).decode()
        with self.assertRaises(BattleEndError):
            AskForBattleEndMessage(None, self.player, make_battle(map_id=999)).decode()
        with self.assertRaises(BattleEndError):
            AskForBattleEndMessage(None, self.player, make_battle(map_id=13, count=10, rank=11)).decode()

    def test_process_replay_and_reload_do_not_duplicate_rewards(self):
        payload = make_battle()
        result, client, _ = self.process(payload)
        self.assertEqual(result["gameMode"], 0)
        client.payload()
        self.assertEqual(client.message_id, 23456)
        first_packet = client.packets[0]
        self.assertEqual((self.player.trophies, self.player.brawl_boxes, self.player.big_boxes), (6, 20, 1))
        self.assertEqual(self.player.battle_tokens, 180)
        second_result, second_client, _ = self.process(payload)
        self.assertEqual(second_result["battleID"], result["battleID"])
        self.assertEqual(second_client.packets[0], first_packet)
        self.assertEqual((self.player.trophies, self.player.brawl_boxes, self.player.big_boxes), (6, 20, 1))

        loaded = self.reload()
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (6, 20, 1))
        _, reload_client, _ = self.process(payload, loaded)
        self.assertEqual(reload_client.packets[0], first_packet)
        self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (6, 20, 1))
        reloaded_again = self.reload(loaded)
        self.assertEqual((reloaded_again.trophies, reloaded_again.brawl_boxes, reloaded_again.big_boxes), (6, 20, 1))

    def test_different_battle_inside_interval_is_rejected_without_mutation(self):
        self.process(make_battle(map_id=0))
        before = (self.player.trophies, self.player.brawl_boxes, self.player.big_boxes)
        client = CaptureClient()
        message = AskForBattleEndMessage(client, self.player, make_battle(map_id=1))
        message.decode()
        self.assertIsInstance(message.process(), str)
        self.assertEqual(client.packets, [])
        self.assertEqual((self.player.trophies, self.player.brawl_boxes, self.player.big_boxes), before)

    def test_result_payload_contains_dynamic_skins_names_and_no_trailing_bytes(self):
        payload = make_battle()
        _, client, _ = self.process(payload)
        reader = BSMessageReader(client.payload())
        self.assertEqual([reader.read_Vint() for _ in range(7)], [0, 0, 20, 6, 0, 0, 0])
        self.assertEqual(
            [reader.read_byte() for _ in range(6)],
            [1, 0, 0, 0, 0, 0],
        )
        self.assertEqual(reader.read_Vint(), 6)
        names = []
        for index in range(6):
            names.append(reader.read_string())
            is_player = reader.read_byte()
            self.assertEqual(is_player, 1 if index == 0 else 0)
            self.assertEqual(reader.read_byte(), index % 2)
            self.assertEqual(reader.read_byte(), 1 if index == 0 else 0)
            self.assertEqual((reader.read_Vint(), reader.read_Vint()), (16, index % 20))
            if index == 0:
                self.assertEqual((reader.read_Vint(), reader.read_Vint()), (29, 0))
            elif index == 1:
                self.assertEqual((reader.read_Vint(), reader.read_Vint()), (29, 29))
            else:
                self.assertEqual(reader.read_Vint(), 0)
            self.assertEqual(reader.read_Vint(), 0)
            self.assertEqual(reader.read_Vint(), 10 if index else 1)
            self.assertEqual(reader.read_byte(), is_player)
            if is_player:
                self.assertEqual(reader.read_int(), 0)
                self.assertEqual(reader.read_int(), 1)
        self.assertEqual(names, ["Local"] + [f"Bot {index}" for index in range(1, 6)])
        self.assertEqual(reader.read_Vint(), 2)
        self.assertEqual([reader.read_Vint() for _ in range(4)], [0, 18, 8, 10])
        self.assertEqual(reader.read_Vint(), 0)
        self.assertEqual(reader.read_Vint(), 2)
        self.assertEqual([reader.read_Vint() for _ in range(6)], [1, 0, 0, 5, 0, 0])
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (28, 0))
        self.assertEqual(reader.read_byte(), 0)
        self.assertEqual(reader.read(), b"")

    def test_solo_duo_and_special_modes_use_their_own_reward_rules(self):
        cases = (
            (13, 10, 2, 8, 0),
            (28, 10, 5, 7, 0),
            (27, 3, 3, 0, 0),
            (21, 6, 4, 0, 0),
            (57, 3, 6, 0, 0),
        )
        for index, (map_id, count, mode, trophies, tokens) in enumerate(cases, 10):
            with self.subTest(mode=mode):
                player = self.make_account(index, f"mode-{mode}")
                result, client, _ = self.process(make_battle(map_id, count), player)
                self.assertEqual(result["gameMode"], mode)
                reader = BSMessageReader(client.payload())
                self.assertEqual(reader.read_Vint(), mode)
                self.assertEqual(reader.read_Vint(), 1 if mode in (2, 5) else 0)
                self.assertEqual(reader.read_Vint(), tokens)
                self.assertEqual(reader.read_Vint(), trophies)
                self.assertEqual((player.trophies, player.brawl_boxes), (trophies, tokens))
                self.assertEqual(player.big_boxes, 1)
                loaded = self.reload(player)
                self.assertEqual((loaded.trophies, loaded.brawl_boxes, loaded.big_boxes), (trophies, tokens, 1))

    def test_token_cap_and_signed_trophy_loss_are_applied_correctly(self):
        self.player.battle_tokens = 5
        self.player.tokensdoubler = 100
        DataBase.replaceValues(SimpleNamespace(player=self.player), {
            "battleTokens": 5,
            "tokensdoubler": 100,
        })
        rewards = apply_battle_result_rewards(self.player, 0, "token-cap")
        self.assertEqual((rewards.token, rewards.doubledtokens, rewards.totaltokens), (5, 5, 10))
        self.assertEqual((self.player.battle_tokens, self.player.tokensdoubler, self.player.brawl_boxes), (0, 95, 10))

        player = self.make_account(30, "loss-token")
        player.battle_result = 1
        player.brawlers_trophies = {"0": 100}
        player.brawlers_trophies_in_rank = {"0": 100}
        player.trophies = 100
        player.highest_trophies = 100
        DataBase.replaceValues(SimpleNamespace(player=player), {
            "brawlersTrophies": {"0": 100},
            "brawlersTrophiesForRank": {"0": 100},
            "trophies": 100,
            "highest_trophies": 100,
        })
        _, client, _ = self.process(make_battle(result=1), player)
        reader = BSMessageReader(client.payload())
        reader.read_Vint()
        self.assertEqual(reader.read_Vint(), 1)
        reader.read_Vint()
        self.assertEqual(reader.read_Vint(), -2)
        self.assertEqual(player.brawlers_trophies["0"], 98)
        self.assertEqual(player.trophies, 98)


if __name__ == "__main__":
    unittest.main()
