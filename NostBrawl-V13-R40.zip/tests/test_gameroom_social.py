import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.chdir(PROJECT_ROOT)
sys.path.insert(0, str(PROJECT_ROOT))

from Database.DatabaseManager import DataBase
from Logic.GameRoomService import GameRoomError, GameRoomService
from Logic.Player import Players
from Packets.LogicMessageFactory import packets
from Packets.Messages.Client.Gameroom.SetTeamChatMutedMessage import SetTeamChatMutedMessage
from Packets.Messages.Client.Gameroom.TeamAllianceMemberInviteMessage import TeamAllianceMemberInviteMessage
from Packets.Messages.Client.Gameroom.TeamChatMessage import TeamChatMessage
from Packets.Messages.Client.Gameroom.TeamInvitationResponseMessage import TeamInvitationResponseMessage
from Packets.Messages.Client.Gameroom.TeamInviteMessage import TeamInviteMessage
from Packets.Messages.Client.Gameroom.TeamReportChatMessage import TeamReportChatMessage
from Packets.Messages.Client.Gameroom.TeamRequestJoinApproveMessage import TeamRequestJoinApproveMessage
from Packets.Messages.Client.Gameroom.TeamRequestJoinCancelMessage import TeamRequestJoinCancelMessage
from Packets.Messages.Client.Gameroom.TeamRequestJoinMessage import TeamRequestJoinMessage
from Packets.Messages.Client.Gameroom.TeamToggleSettingsMessage import TeamToggleSettingsMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamInviteStatusMessage import TeamInviteStatusMessage
from Utils.Reader import BSMessageReader
from Utils.Writer import Writer


class CaptureClient:
    def __init__(self):
        self.packets = []

    def sendall(self, data):
        self.packets.append(bytes(data))

    def payload(self, index=-1):
        packet = self.packets[index]
        message_id = int.from_bytes(packet[:2], "big")
        length = int.from_bytes(packet[2:5], "big")
        if length != len(packet) - 7:
            raise AssertionError("Invalid packet length")
        return message_id, packet[7:]


def vints(*values):
    writer = Writer(None)
    for value in values:
        writer.writeVint(value)
    return writer.buffer


def ints(*values):
    writer = Writer(None)
    for value in values:
        writer.writeInt(value)
    return writer.buffer


def boolean(value):
    writer = Writer(None)
    writer.writeBoolean(value)
    return writer.buffer


def string(value):
    writer = Writer(None)
    writer.writeString(value)
    return writer.buffer


def read_friend(reader):
    result = {"high_id": reader.read_int(), "low_id": reader.read_int()}
    result["strings"] = [reader.read_string() for _ in range(4)]
    result["ints"] = [reader.read_int() for _ in range(6)]
    if reader.read_boolean():
        reader.read_int()
        reader.read_int()
        reader.read_int()
        reader.read_string()
        reader.read_int()
        reader.read_int()
    reader.read_string()
    result["profile_icon"] = reader.read_int()
    reader.read_int()
    return result


class GameRoomSocialTests(unittest.TestCase):
    def setUp(self):
        self.temp_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)
        self.database_path = str(Path(self.temp_directory.name) / "players.db")
        path_patch = patch.object(DataBase, "_database_path", lambda: self.database_path)
        path_patch.start()
        self.addCleanup(path_patch.stop)
        self.players = [self.make_account(index) for index in range(1, 5)]
        self.clients = [CaptureClient() for _ in self.players]
        for index, player in enumerate(self.players):
            player.ClientDict = {"Clients": {}}
            for other_index, other in enumerate(self.players):
                if other_index != index:
                    player.ClientDict["Clients"][str(other.low_id)] = {
                        "SocketInfo": self.clients[other_index],
                        "Crypto": None,
                    }

    def make_account(self, low_id):
        player = Players(SimpleNamespace())
        player.low_id = low_id
        player.high_id = 0
        player.token = "social-room-token-%d" % low_id
        player.name = "Social %d" % low_id
        player.brawler_id = 0
        player.skin_id = 0
        DataBase.createAccount(SimpleNamespace(player=player))
        return player

    def reload(self, source):
        player = Players(SimpleNamespace())
        player.token = source.token
        self.assertTrue(DataBase.loadAccount(SimpleNamespace(player=player)))
        return player

    def test_factory_registers_native_social_messages(self):
        self.assertIs(packets[14365], TeamInviteMessage)
        self.assertIs(packets[14370], TeamAllianceMemberInviteMessage)
        self.assertIs(packets[14479], TeamInvitationResponseMessage)
        self.assertIs(packets[14880], TeamRequestJoinCancelMessage)
        self.assertIs(packets[14881], TeamRequestJoinMessage)
        self.assertIs(packets[14882], TeamRequestJoinApproveMessage)
        self.assertIs(packets[14778], SetTeamChatMutedMessage)

    def test_invite_accept_is_persistent_and_never_starts_a_battle(self):
        owner, recipient, _, _ = self.players
        owner_client, recipient_client = self.clients[:2]
        room = GameRoomService.create(owner, 1, -64, 0, False)
        invite = TeamInviteMessage(owner_client, owner, vints(0, recipient.low_id, 7))
        invite.decode()
        result = invite.process()
        self.assertEqual(result["invite"]["invite_type"], 7)
        self.assertEqual(recipient.room_id, 0)
        self.assertEqual(result["room"]["state"], 0)
        self.assertEqual(result["room"]["player_count"], 1)
        self.assertEqual(len(result["room"]["invites"]), 1)
        message_id, raw = recipient_client.payload()
        self.assertEqual(message_id, 24589)
        reader = BSMessageReader(raw)
        self.assertEqual(reader.read_Vint(), 7)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room["id"]))
        self.assertEqual(reader.read(), b"")
        self.assertEqual(len(GameRoomService.for_player(self.reload(owner))["invites"]), 1)

        payload = vints(7) + ints(0, room["id"]) + boolean(True)
        response = TeamInvitationResponseMessage(recipient_client, recipient, payload)
        response.decode()
        accepted = response.process()
        self.assertTrue(accepted["accepted"])
        self.assertEqual(accepted["room"]["player_count"], 2)
        self.assertEqual(accepted["room"]["invites"], [])
        self.assertEqual(recipient.room_id, room["id"])
        self.assertEqual(accepted["room"]["state"], 0)
        self.assertEqual(self.reload(recipient).room_id, room["id"])
        with self.assertRaises(GameRoomError):
            GameRoomService.accept_invite(recipient, room["id"], 7)

    def test_invite_reject_and_club_validation_do_not_add_members(self):
        owner, recipient, _, _ = self.players
        room = GameRoomService.create(owner, 1, -64, 0, False)
        GameRoomService.invite(owner, recipient.low_id, 3)
        payload = vints(3) + ints(0, room["id"]) + boolean(False)
        response = TeamInvitationResponseMessage(self.clients[1], recipient, payload)
        response.decode()
        rejected = response.process()
        self.assertFalse(rejected["accepted"])
        self.assertEqual(rejected["room"]["player_count"], 1)
        self.assertEqual(rejected["room"]["invites"], [])
        self.assertEqual(recipient.room_id, 0)
        with self.assertRaises(GameRoomError):
            GameRoomService.invite(owner, recipient.low_id, 1, club_only=True)

    def test_join_request_approve_reject_cancel_and_relogin(self):
        owner, _, requester, other = self.players
        room = GameRoomService.create(owner, 1, -64, 0, False)
        payload = ints(0, room["id"], 0, owner.low_id)
        request = TeamRequestJoinMessage(self.clients[2], requester, payload)
        request.decode()
        pending = request.process()
        self.assertEqual(pending["player_count"], 1)
        self.assertEqual(len(pending["join_requests"]), 1)
        self.assertEqual(requester.room_id, 0)
        self.assertEqual(len(GameRoomService.get(room["id"])["join_requests"]), 1)

        approval_payload = ints(0, requester.low_id) + boolean(True) + boolean(False)
        approval = TeamRequestJoinApproveMessage(self.clients[0], owner, approval_payload)
        approval.decode()
        approved = approval.process()
        self.assertTrue(approved["request"]["approved"])
        self.assertEqual(approved["room"]["player_count"], 2)
        self.assertEqual(approved["room"]["join_requests"], [])
        self.assertEqual(self.reload(requester).room_id, room["id"])
        GameRoomService.leave(requester)

        TeamRequestJoinMessage(self.clients[2], requester, payload).decode()
        request = TeamRequestJoinMessage(self.clients[2], requester, payload)
        request.decode()
        request.process()
        rejection_payload = ints(0, requester.low_id) + boolean(False) + boolean(False)
        rejection = TeamRequestJoinApproveMessage(self.clients[0], owner, rejection_payload)
        rejection.decode()
        rejected = rejection.process()
        self.assertFalse(rejected["request"]["approved"])
        self.assertEqual(rejected["room"]["player_count"], 1)
        self.assertEqual(self.reload(requester).room_id, 0)

        TeamRequestJoinMessage(self.clients[2], requester, payload).decode()
        request = TeamRequestJoinMessage(self.clients[2], requester, payload)
        request.decode()
        request.process()
        other_payload = ints(0, room["id"], 0, owner.low_id)
        other_request = TeamRequestJoinMessage(self.clients[3], other, other_payload)
        other_request.decode()
        other_request.process()
        cancel = TeamRequestJoinCancelMessage(self.clients[2], requester, b"")
        cancel.decode()
        cancelled = cancel.process()
        self.assertEqual([item["id"] for item in cancelled], [room["id"]])
        remaining = GameRoomService.get(room["id"])["join_requests"]
        self.assertEqual([item["player_id"] for item in remaining], [other.low_id])

    def test_report_settings_mute_and_status_wire(self):
        owner, member, _, _ = self.players
        room = GameRoomService.create(owner, 1, -64, 0, False)
        GameRoomService.join(member, room["id"])
        chat = TeamChatMessage(self.clients[1], member, string("denunciar"))
        chat.decode()
        chat_result = chat.process()["chat"]
        report_payload = ints(chat_result["id"], member.low_id)
        report = TeamReportChatMessage(self.clients[0], owner, report_payload)
        report.decode()
        report_id = report.process()
        duplicate = TeamReportChatMessage(self.clients[0], owner, report_payload)
        duplicate.decode()
        self.assertEqual(duplicate.process(), report_id)
        with DataBase._connection() as connection:
            count = connection.execute("SELECT COUNT(*) FROM game_room_chat_reports").fetchone()[0]
        self.assertEqual(count, 1)

        muted = SetTeamChatMutedMessage(self.clients[0], owner, boolean(True))
        muted.decode()
        self.assertTrue(muted.process())
        self.assertTrue(self.reload(owner).progression["teamChatMuted"])
        settings = TeamToggleSettingsMessage(self.clients[0], owner, boolean(False))
        settings.decode()
        self.assertFalse(settings.process()["advertise_friends"])

        status = TeamInviteStatusMessage(None, owner, 4, member.low_id)
        status.encode()
        reader = BSMessageReader(status.buffer)
        self.assertEqual(reader.read_int(), 4)
        self.assertTrue(reader.read_boolean())
        self.assertEqual((reader.read_int(), reader.read_int()), (0, member.low_id))
        self.assertEqual(reader.read(), b"")

    def test_team_data_serializes_invite_and_request_entries(self):
        owner, recipient, requester, _ = self.players
        room = GameRoomService.create(owner, 1, -64, 0, False)
        GameRoomService.invite(owner, recipient.low_id, 9)
        GameRoomService.request_join(requester, room["id"], owner.low_id)
        room = GameRoomService.get(room["id"])
        message = TeamGameroomDataMessage(None, owner, room)
        message.encode()
        reader = BSMessageReader(message.buffer)
        reader.read_Vint()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_int()
        reader.read_int()
        reader.read_Vint()
        reader.read_boolean()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_Vint()
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (15, room["map_id"]))
        self.assertEqual(reader.read_Vint(), 1)
        member = room["members"][0]
        reader.read_boolean()
        reader.read_int()
        reader.read_int()
        reader.read_string()
        reader.read_Vint()
        for _ in range(2):
            reader.read_Vint()
            reader.read_Vint()
        for _ in range(4):
            reader.read_Vint()
        reader.read_boolean()
        reader.read_Vint()
        reader.read_Vint()
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, owner.low_id))
        self.assertEqual((reader.read_int(), reader.read_int()), (0, recipient.low_id))
        self.assertEqual(reader.read_string(), recipient.name)
        self.assertEqual((reader.read_Vint(), reader.read_Vint()), (9, 0))
        self.assertEqual(reader.read_Vint(), 1)
        self.assertEqual((reader.read_int(), reader.read_int()), (0, room["id"]))
        self.assertEqual((reader.read_int(), reader.read_int()), (0, requester.low_id))
        self.assertEqual(read_friend(reader)["low_id"], requester.low_id)
        self.assertEqual(reader.read(), b"")


if __name__ == "__main__":
    unittest.main()
