# NostBrawl V13 R9

Servidor NostBrawl para Brawl Stars **13.283.1**, com transporte crypto V13, contas em SQLite3, envelope de home V13 e dados compatíveis da `LogicConfData`/`EventSlots` V18.

## Requisitos e execução

- Python 3.10 ou superior.
- Cliente 13.283.1 com patch compatível com as chaves do `config.json`.
- Nenhum servidor MySQL ou dependência Python externa obrigatória.

Extraia o conteúdo do ZIP em uma pasta e inicie por ela:

```bash
python3 main.py
```

Também é possível usar `bash start.sh` no Linux/macOS ou `start.bat` no Windows.

## Home e sessão

- `LoginMessage` cria ou carrega a conta antes de enviar as respostas de sucesso.
- `LoginOkMessage` entrega Account ID, Home ID e token da mesma conta persistida.
- `OwnHomeDataMessage` é a única home enviada pelo login e mantém o envelope V13 validado na revisão anterior.
- A home serializa gems, ouro, caixas, star points e progressão da conta, sem o array de 621 milestones do Pro.
- Os seis slots 0–5 e os cinco eventos ativos seguem a V18: mapas 7, 32, 24, 0 e 30, todos validados contra o catálogo V13.
- Cada evento usa índices duplicados 1-based, timer diário, tokens, SCID `15/mapa`, estado ativo e o campo booleano seguido do modificador V18.
- O primeiro evento mantém o modificador 2 configurado na V18; eventos configurados com modificador zero não recebem IDs aleatórios no envelope V13.
- A loja usa o timestamp 2019049, dobrador 50/1000 e os valores 500/50; os multiplicadores visuais permanecem 3/10 no V13, coerentes com as 3/10 iterações do gerador.
- `LobbyInfoMessage` permanece desativado por padrão.
- A crypto V13 permanece ativada por padrão; o modo raw existe apenas para diagnóstico com um cliente compatível.

## Caixas e recompensas V18

`Packets/Commands/Server/LogicBoxGenerator.py` contém o gerador separado. `Logic/BoxService.py` adapta os IDs do Nost e aplica o resultado por `RewardTransaction`.

| Caixa visual Nost | Iterações V18 | Máximo de alvos de PP |
| --- | ---: | ---: |
| Brawl Box, ID 10 | 1 | 2 |
| Big Box, ID 12 | 3 | 3 |
| Mega Box, ID 11 | 10 | 5 |

Cada iteração usa ouro de 30–60 e uma base de 12–26 pontos de carta. As rolagens de brawler usam 1–10000 e os limites cumulativos da V18:

| Raridade | Limite | Chance individual |
| --- | ---: | ---: |
| Lendário | 10 | 0,10% |
| Mítico | 25 | 0,15% |
| Épico | 70 | 0,45% |
| Super raro | 200 | 1,30% |
| Raro | 400 | 2,00% |

O port também inclui star powers, skins disponíveis no cliente V13 e bônus de 3–10 gems, 200 dobradores ou 3/5/7/10 tickets. As listas respeitam desbloqueios existentes e removem itens já sorteados durante a mesma abertura.

Diferentemente do código de referência, a adaptação não permite ouro ou cartas negativos quando várias recompensas especiais ocorrem juntas, não gera recompensa vazia por ausência de base de cartas e não grava conta durante `LogicBoxDataCommand.encode()`.

## Compra de skins

A compra permanece em `Logic/SkinPurchase.py`, separada da resposta e do gerador de caixas:

- 58 preços das tabelas V18, com fallback ao CSV para skins V13 não listadas;
- 11 dependências de skin prateada para liberar a dourada correspondente;
- validação de brawler, propriedade, saldo e correspondência skin/brawler;
- cobrança e desbloqueio na mesma transação SQLite;
- `LogicBuySkinCommand` no comando 507 e `LogicSkinDataCommand` para a entrega dedicada;
- skins obtidas em caixas não alteram a skin selecionada automaticamente.

## Trophy Road e progressão

- As 94 posições são lidas de `GameAssets/csv_logic/milestones.csv`, evitando uma segunda tabela divergente.
- As posições 7, 8 e 12 seguem os tipos definidos pelo CSV V13.
- Se o brawler oferecido já estiver desbloqueado, o resgate usa o fallback V18 para Brawl Box.
- O avanço e a recompensa são persistidos na mesma transação.
- Power points antigos são normalizados para 0–1410 no carregamento e a correção é gravada no SQLite.
- Posições antigas fora do intervalo V13 são normalizadas para 1–95; 95 representa a estrada concluída.
- O array de milestones não é inserido na home.
- A rotação da home foi substituída pela V18; o mapa 118 da tabela antiga não é utilizado.

## SQLite e valores iniciais

O banco padrão é `Database/players.db`. A coluna JSON `progression` preserva ofertas, eventos, animações e star points sem substituir as colunas originais.

Novas contas usam:

```json
{
  "BrawlBoxTokens": 999,
  "BigBoxTokens": 0,
  "Gems": 999,
  "Trophies": 999
}
```

`highest_trophies` também começa em 999. Contas existentes mantêm seus saldos e progressão; apenas os limites inválidos descritos acima são reparados.

As compras de caixas, ouro, dobradores, ofertas e skins debitam e creditam por transações que atualizam o SQLite antes de aplicar os valores ao objeto em memória. A suíte inclui uma compra real pelo comando 521 seguida de encerramento, nova conexão e segundo carregamento da mesma conta.

## Configuração de caixas

As opções abaixo ficam no `config.json` e são ativadas por padrão:

```json
{
  "BrawlersBox": true,
  "SkinsBox": true,
  "UniqueSkinsBox": true
}
```

Elas controlam apenas os respectivos tipos de recompensa especial. IDs ausentes no CSV V13 não são oferecidos.

## Testes

Execute:

```bash
python3 -m unittest discover -s tests -v
```

A suíte contém **90 testes** para:

- login, segundo login e transporte TCP raw/crypto;
- persistência de gems após compra e reconexão;
- envelope da home byte a byte e leitura independente até o final;
- slots, eventos, modificadores e valores compatíveis da `LogicConfData` V18, com validação dos mapas contra os CSVs;
- cinco limiares de raridade V18 e três tipos de bônus;
- iterações 1/3/10 e quantidades de alvos de PP;
- recompensas especiais simultâneas sem valores negativos;
- 120 bundles com seeds fixas e validação de valores não negativos;
- cap de PP, migração de dados inválidos e ausência de efeitos colaterais no gerador;
- compra de skins, preços, dependências e respostas 203;
- alinhamento da Trophy Road, fallback de brawler e seus 94 resgates;
- compras, ofertas, recompensas de batalha, leaderboard e comandos intercalados.

## Validação no APK

Os testes automatizados não substituem o teste no APK. No R6, o login e o rename funcionaram, mas a Trophy Road falhou antes de enviar qualquer comando 517. No teste real do R8, o usuário informou fechamento logo após entrar na home; o log confirmou `LoginOk`, `OwnHomeData` e EOF, sem exceção do servidor. O R9 remove os modificadores aleatórios dos eventos configurados com zero e restaura os multiplicadores visuais 3/10 do V13, mantendo os demais dados V18. Essa candidata ainda precisa ser validada no cliente 13.283.1. Se o fechamento persistir, é necessário capturar logcat/tombstone; o log do servidor não contém a falha nativa. A apresentação das recompensas e o saldo após voltar às telas também permanecem sujeitos ao reteste.

Batalha online completa, clubes e salas não foram expandidos nesta revisão.
