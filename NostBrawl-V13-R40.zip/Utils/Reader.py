from io import BufferedReader, BytesIO


class BSMessageReader(BufferedReader):
    def __init__(self, initial_bytes):
        super().__init__(BytesIO(initial_bytes))

    def _read_exact(self, length):
        data = self.read(length)
        if len(data) != length:
            raise ValueError(
                f"Unexpected end of message: wanted {length} bytes, got {len(data)}"
            )
        return data

    def read_byte(self):
        return int.from_bytes(self._read_exact(1), "big")

    def read_boolean(self):
        value = self.read_byte()
        if value not in (0, 1):
            raise ValueError("Booleano inválido")
        return bool(value)

    def ensure_end(self):
        if self.read(1):
            raise ValueError("Mensagem contém dados residuais")

    def read_Vint(self):
        n = self._read_varint(True)
        return (n >> 1) ^ (-(n & 1))

    def read_short(self, length=2):
        return int.from_bytes(self._read_exact(length), "big")

    def read_int(self, length=4):
        return int.from_bytes(self._read_exact(length), "big")

    def _read_varint(self, rotate: bool = True):
        result = 0
        shift = 0
        while True:
            if shift >= 35:
                raise ValueError("Variable integer is too long")

            byte = self.read_byte()
            if rotate and shift == 0:
                seventh = (byte & 0x40) >> 6
                msb = (byte & 0x80) >> 7
                n = byte << 1
                n = n & ~0x181
                byte = n | (msb << 7) | seventh
            result |= (byte & 0x7F) << shift
            shift += 7
            if not (byte & 0x80):
                break
        return result

    def read_rrsint32(self):
        n = self._read_varint(True)
        return (n >> 1) ^ (-(n & 1))

    def readScId(self):
        a = self.read_Vint()
        b = self.read_Vint() if a != 0 else -1
        return a, b

    def readLogicLong(self):
        return self.read_Vint(), self.read_Vint()

    def read_string(self):
        length = self.read_int()
        if length == 0xFFFFFFFF:
            return ""
        return self._read_exact(length).decode("utf-8")

    def peek_int(self, length=4):
        return int.from_bytes(self.peek(length)[:length], "big")
