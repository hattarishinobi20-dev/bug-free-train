import csv


class Cards:
    """Access V13 card data using the actual CSV column indexes."""

    @staticmethod
    def _rows(path):
        with open(path, "r", encoding="utf-8", newline="") as csv_file:
            return list(csv.reader(csv_file))[2:]

    @staticmethod
    def _brawler_name(brawler_id):
        try:
            brawler_id = int(brawler_id)
        except (TypeError, ValueError):
            return None

        rows = Cards._rows("GameAssets/csv_logic/characters.csv")
        if brawler_id < 0 or brawler_id >= len(rows):
            return None
        return rows[brawler_id][0]

    def get_spg_id():
                                                               
        return [
            card_id
            for card_id, row in enumerate(Cards._rows("GameAssets/csv_logic/cards.csv"))
            if len(row) > 4 and row[4] in ("4", "5")
        ]

    def get_spg_by_brawler_id(self, brawler_id, type):
        brawler_name = Cards._brawler_name(brawler_id)
        if brawler_name is None:
            return None

        expected_type = str(type)
        for card_id, row in enumerate(Cards._rows("GameAssets/csv_logic/cards.csv")):
            if (
                len(row) > 4
                and row[3] == brawler_name
                and row[4] == expected_type
            ):
                return card_id
        return None

    def get_unlocked_spg(self, brawler_id):
        brawler_name = Cards._brawler_name(brawler_id)
        if brawler_name is None:
            return []

        unlocked = []
        for card_id, row in enumerate(Cards._rows("GameAssets/csv_logic/cards.csv")):
            if (
                len(row) > 5
                and row[3] == brawler_name
                and row[4] in ("4", "5")
                and row[5].lower() != "true"
            ):
                unlocked.append(card_id)
        return unlocked

    def get_brawler_unlock():
        return [
            card_id
            for card_id, row in enumerate(Cards._rows("GameAssets/csv_logic/cards.csv"))
            if len(row) > 4 and row[4] == "0"
        ]

    @staticmethod
    def get_brawler_unlock_by_character(brawler_id):
        """Pro-compatible unlock card lookup using the V13 card table."""
        brawler_name = Cards._brawler_name(brawler_id)
        if brawler_name is None:
            return 0
        for card_id, row in enumerate(Cards._rows("GameAssets/csv_logic/cards.csv")):
            if len(row) > 4 and row[3] == brawler_name and row[4] == "0":
                return card_id
        return 0

    @staticmethod
    def get_brawler_star_power(brawler_id):
        brawler_name = Cards._brawler_name(brawler_id)
        if brawler_name is None:
            return 0
        for card_id, row in enumerate(Cards._rows("GameAssets/csv_logic/cards.csv")):
            if len(row) > 4 and row[3] == brawler_name and row[4] == "4":
                return card_id
        return 0

    @staticmethod
    def get_brawler_rarity(card_id):
        try:
            card_id = int(card_id)
        except (TypeError, ValueError):
            return None
        rows = Cards._rows("GameAssets/csv_logic/cards.csv")
        if card_id < 0 or card_id >= len(rows):
            return None
        row = rows[card_id]
        return row[10] if len(row) > 10 else None
