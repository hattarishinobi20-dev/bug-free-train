import csv


class Skins:
    """Pro skin helpers backed only by the V13 skins/characters CSVs."""

    @staticmethod
    def _rows(path):
        with open(path, "r", encoding="utf-8", newline="") as csv_file:
            return list(csv.reader(csv_file))[2:]

    @staticmethod
    def _skin(skin_id):
        try:
            skin_id = int(skin_id)
        except (TypeError, ValueError):
            raise ValueError("Invalid skin id") from None
        rows = Skins._rows("GameAssets/csv_logic/skins.csv")
        if skin_id < 0 or skin_id >= len(rows) or not rows[skin_id][2]:
            raise ValueError("Invalid skin id")
        return rows[skin_id]

    @staticmethod
    def get_skins_id():
        return [
            skin_id
            for skin_id, row in enumerate(
                Skins._rows("GameAssets/csv_logic/skins.csv")
            )
            if len(row) > 2 and row[2]
        ]

    @staticmethod
    def getBrawler(skin_id):
        target = Skins._skin(skin_id)[2]
        for brawler_id, row in enumerate(
            Skins._rows("GameAssets/csv_logic/characters.csv")
        ):
            if row and row[0] == target:
                return brawler_id
        raise ValueError("Skin has no character")

    @staticmethod
    def get_default_skin(brawler_id):
        try:
            brawler_id = int(brawler_id)
        except (TypeError, ValueError):
            raise ValueError("Invalid brawler id") from None
        characters = Skins._rows("GameAssets/csv_logic/characters.csv")
        if (
            brawler_id < 0 or brawler_id >= len(characters)
            or len(characters[brawler_id]) <= 22
            or characters[brawler_id][20] != "Hero"
        ):
            raise ValueError("Invalid brawler id")
        character = characters[brawler_id]
        for skin_id, row in enumerate(Skins._rows("GameAssets/csv_logic/skins.csv")):
            if len(row) > 2 and row[0] == character[22] and row[2] == character[0]:
                return skin_id
        raise ValueError("Brawler has no default skin")

    @staticmethod
    def resolve_skin(brawler_id, skin_id):
        try:
            brawler_id = int(brawler_id)
            skin_id = int(skin_id or 0)
            if Skins.getBrawler(skin_id) == brawler_id:
                return skin_id
        except (TypeError, ValueError):
            pass
        return Skins.get_default_skin(brawler_id)

    @staticmethod
    def getNonDefaultSkins():
        default_skins = {
            row[22]
            for row in Skins._rows("GameAssets/csv_logic/characters.csv")
            if len(row) > 22
        }
        return [
            skin_id
            for skin_id, row in enumerate(
                Skins._rows("GameAssets/csv_logic/skins.csv")
            )
            if len(row) > 2 and row[2] and row[0] not in default_skins
        ]

    @staticmethod
    def getSkinPrice(skin_id):
        row = Skins._skin(skin_id)
        try:
            return max(0, int(row[4] or 0))
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def getIsDefaultSkin(skin_id):
        name = Skins._skin(skin_id)[0]
        return any(
            len(row) > 22 and row[22] == name
            for row in Skins._rows("GameAssets/csv_logic/characters.csv")
        )
