import csv

from Files.CsvLogic.Skins import Skins


class Characters:
    @staticmethod
    def get_brawlers_id():
        with open(
            "GameAssets/csv_logic/characters.csv", "r", encoding="utf-8", newline=""
        ) as csv_file:
            rows = list(csv.reader(csv_file))[2:]
        return [
            brawler_id
            for brawler_id, row in enumerate(rows)
            if len(row) > 20
            and row[20] == "Hero"
            and row[2].lower() != "true"
            and row[1].lower() != "true"
        ]

    @staticmethod
    def get_brawler_id_by_name(name):
        with open(
            "GameAssets/csv_logic/characters.csv", "r", encoding="utf-8", newline=""
        ) as csv_file:
            rows = list(csv.reader(csv_file))[2:]
        for brawler_id, row in enumerate(rows):
            if (
                len(row) > 20
                and row[0] == name
                and row[20] == "Hero"
                and row[2].lower() != "true"
                and row[1].lower() != "true"
            ):
                return brawler_id
        raise ValueError(f"Brawler desconhecido: {name}")

    @staticmethod
    def get_brawler_by_skin_id(skin_id):
                                                                     
        return Skins.getBrawler(skin_id)
