class Boxes:
    @staticmethod
    def get_box_type(box_id):
        if box_id in (0, 5):
            return 10
        if box_id in (1, 4):
            return 12
        if box_id == 3:
            return 11
        if box_id in (10, 11, 12):
            return box_id
        raise ValueError(f"Caixa inválida: {box_id}")

    @staticmethod
    def get_generation_type(box_id):
        box_type = Boxes.get_box_type(box_id)
        return {10: 1, 12: 3, 11: 10}[box_type]
