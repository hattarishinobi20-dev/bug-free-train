import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path


class BattleEndError(ValueError):
    pass


def _read_data_reference(reader):
    csv_id = reader.read_Vint()
    if csv_id == 0:
        return 0, 0
    return csv_id, reader.read_Vint()


@dataclass(frozen=True)
class BattleParticipant:
    brawler_id: int
    skin_id: int
    team: int
    is_player: bool
    name: str


@dataclass(frozen=True)
class BattleEndData:
    battle_result: int
    submitted_result: int
    rank: int
    location_id: int
    map_id: int
    game_mode: int
    location_game_mode: str
    participants: tuple
    battle_id: str

    @property
    def local_index(self):
        for index, participant in enumerate(self.participants):
            if participant.is_player:
                return index
        return 0

    @property
    def local(self):
        return self.participants[self.local_index]


class BattleEndService:
    _location_rows = None
    _card_rows = {}
    SPECIAL_MODES = frozenset({3, 4, 6})

    @classmethod
    def _locations(cls):
        if cls._location_rows is None:
            path = Path(__file__).resolve().parents[1] / "GameAssets" / "csv_logic" / "locations.csv"
            with path.open("r", encoding="utf-8-sig", newline="") as location_file:
                cls._location_rows = list(csv.DictReader(location_file))[1:]
        return cls._location_rows

    @classmethod
    def _valid_card(cls, csv_name, card_id):
        if csv_name not in cls._card_rows:
            path = Path(__file__).resolve().parents[1] / "GameAssets" / "csv_logic" / f"{csv_name}.csv"
            with path.open("r", encoding="utf-8-sig", newline="") as card_file:
                cls._card_rows[csv_name] = list(csv.DictReader(card_file))[1:]
        return 0 <= int(card_id) < len(cls._card_rows[csv_name])

    @classmethod
    def game_mode(cls, map_id):
        rows = cls._locations()
        if not 0 <= map_id < len(rows):
            raise BattleEndError(f"Mapa V13 inválido: {map_id}")
        location_game_mode = rows[map_id].get("GameMode", "")
        mode = {
            "BattleRoyale": 2,
            "BattleRoyaleTeam": 5,
            "Survival": 3,
            "BossFight": 4,
            "Raid": 6,
        }.get(location_game_mode, 0)
        return mode, location_game_mode

    @classmethod
    def decode(cls, reader, initial_bytes):
        if len(initial_bytes) > 16384:
            raise BattleEndError("BattleEnd excede o tamanho permitido")
        try:
            battle_result = reader.read_Vint()
            submitted_result = reader.read_Vint()
            rank = reader.read_Vint()
            map_id = reader.read_Vint()
            location_id = reader.read_Vint()
            count = reader.read_Vint()
        except ValueError as error:
            raise BattleEndError("Cabeçalho BattleEnd incompleto") from error
        if battle_result not in (0, 1, 2):
            raise BattleEndError("Resultado BattleEnd inválido")
        if location_id not in (0, 15):
            raise BattleEndError("Referência de local inválida")
        if not 1 <= count <= 10:
            raise BattleEndError("Quantidade de participantes inválida")
        game_mode, location_game_mode = cls.game_mode(map_id)
        expected_counts = {
            2: {10},
            5: {10},
            3: {3},
            4: {6},
            6: {3},
        }
        if game_mode in expected_counts and count not in expected_counts[game_mode]:
            raise BattleEndError("Participantes incompatíveis com o modo")
        if game_mode == 2 and not 1 <= rank <= 10:
            raise BattleEndError("Rank solo inválido")
        if game_mode == 5 and not 1 <= rank <= 5:
            raise BattleEndError("Rank duo inválido")
        if game_mode == 0 and map_id != 20 and count != 6:
            raise BattleEndError("Partida 3v3 exige seis participantes")

        participants = []
        try:
            for index in range(count):
                brawler_reference, brawler_id = _read_data_reference(reader)
                skin_reference, skin_id = _read_data_reference(reader)
                if skin_reference not in (0, 29):
                    raise BattleEndError("Referência de skin inválida")
                team = reader.read_Vint()
                player_flag = reader.read_byte()
                name = reader.read_string() or ""
                if brawler_reference not in (0, 16):
                    raise BattleEndError("Referência de personagem inválida")
                if not cls._valid_card("characters", brawler_id) or not cls._valid_card("skins", skin_id):
                    raise BattleEndError("Personagem ou skin inexistente nos CSVs V13")
                if not 0 <= team <= 10 or player_flag not in (0, 1):
                    raise BattleEndError("Equipe ou marcador de jogador inválido")
                if len(name.encode("utf-8")) > 64:
                    raise BattleEndError("Nome de participante muito longo")
                participants.append(BattleParticipant(
                    brawler_id=brawler_id,
                    skin_id=skin_id,
                    team=team,
                    is_player=bool(player_flag),
                    name=name,
                ))
        except ValueError as error:
            if isinstance(error, BattleEndError):
                raise
            raise BattleEndError("Participante BattleEnd incompleto") from error
        if reader.read(1):
            raise BattleEndError("BattleEnd contém dados residuais")
        if not any(participant.is_player for participant in participants):
            participants[0] = BattleParticipant(
                brawler_id=participants[0].brawler_id,
                skin_id=participants[0].skin_id,
                team=participants[0].team,
                is_player=True,
                name=participants[0].name,
            )
        battle_id = hashlib.sha256(initial_bytes).hexdigest()
        return BattleEndData(
            battle_result=battle_result,
            submitted_result=submitted_result,
            rank=rank,
            location_id=location_id,
            map_id=map_id,
            game_mode=game_mode,
            location_game_mode=location_game_mode,
            participants=tuple(participants),
            battle_id=battle_id,
        )

    @staticmethod
    def apply_to_player(player, battle):
        local = battle.local
        player.battle_end = battle
        player.battle_end_id = battle.battle_id
        player.battle_participants = battle.participants
        player.players = len(battle.participants)
        player.battle_result = battle.battle_result
        player.rank = battle.rank
        player.map_id = battle.map_id
        player.locationID = battle.location_id
        player.brawler_id = local.brawler_id
        player.skin_id = local.skin_id
        player.team = local.team
        if battle.game_mode in BattleEndService.SPECIAL_MODES:
            player.result = 0
        else:
            tutorial = int(getattr(player, "tutorial", 2) or 0)
            player.result = 16 if tutorial == 2 and battle.location_id == 15 else 0
        for index in range(1, 10):
            participant_index = index if index < len(battle.participants) else None
            participant = battle.participants[participant_index] if participant_index is not None else None
            setattr(player, f"bot{index}", participant.brawler_id if participant else 0)
            setattr(player, f"bot{index}_n", participant.name if participant else "")
            setattr(player, f"bot{index}_team", participant.team if participant else 0)
        return battle
