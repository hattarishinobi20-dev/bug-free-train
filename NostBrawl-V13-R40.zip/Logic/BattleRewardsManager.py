"""Transactional Pro battle rewards in the Nost V13/SQLite data layout."""

import copy
import time

from Logic.Milestones import Milestones
from Logic.Rewards import RewardError, RewardTransaction


class BattleRewardsManager:
    HISTORY_SECONDS = 600
    HISTORY_LIMIT = 20
    SPECIAL_MODES = frozenset({3, 4, 6})

    def __init__(self, player, db=None):
        self.player = player
        self.db = db
        self.milestones = Milestones()

    @staticmethod
    def get_trophy_modifiers(trophies):
        ranges = [
            (0, 29, (0, 0, 6)), (30, 59, (-1, 0, 6)),
            (60, 99, (-2, 0, 6)), (100, 139, (-2, 0, 5)),
            (140, 219, (-3, 0, 5)), (220, 299, (-4, 0, 5)),
            (300, 499, (-5, 0, 5)), (500, 599, (-6, 0, 5)),
            (600, 699, (-7, 0, 4)), (700, 799, (-7, 0, 3)),
            (800, 899, (-8, 0, 3)), (900, float("inf"), (-9, 0, 2)),
        ]
        for low, high, modifiers in ranges:
            if low <= trophies <= high:
                return modifiers
        return (0, 0, 0)

    @staticmethod
    def get_solo_trophy_modifiers(trophies):
        ranges = [
            (0, 29, [8, 7, 6, 5, 5, 4, 3, 2, 1, 0]),
            (30, 59, [8, 7, 6, 4, 3, 2, 0, -1, -2, -4]),
            (60, 99, [8, 7, 5, 4, 3, 1, 0, -2, -3, -4]),
            (100, 139, [7, 6, 5, 3, 2, 1, -1, -2, -3, -4]),
            (140, 219, [7, 6, 4, 3, 2, 0, -1, -3, -4, -5]),
            (220, 299, [7, 6, 4, 3, 1, 0, -2, -3, -4, -5]),
            (300, 499, [7, 6, 4, 2, 1, -1, -2, -4, -6, -7]),
            (500, 599, [6, 5, 3, 2, 0, -2, -3, -4, -6, -7]),
            (600, 699, [5, 4, 3, 1, -1, -2, -3, -4, -6, -7]),
            (700, float("inf"), [5, 3, 2, 1, -1, -2, -4, -5, -6, -7]),
        ]
        for low, high, values in ranges:
            if low <= trophies <= high:
                return values
        return [0] * 10

    @staticmethod
    def get_duo_trophy_modifiers(trophies):
        ranges = [
            (0, 29, [7, 5, 4, 2, 0]), (30, 59, [7, 5, 2, -1, -3]),
            (60, 99, [7, 4, 2, -1, -4]), (100, 139, [6, 4, 1, -1, -4]),
            (140, 219, [6, 4, 1, -2, -5]), (220, 499, [6, 3, 0, -3, -6]),
            (500, 599, [6, 3, 0, -4, -6]), (600, 699, [4, 2, -1, -4, -6]),
            (700, 799, [3, 1, -1, -4, -6]), (800, 899, [3, 1, -2, -5, -7]),
            (900, float("inf"), [2, 0, -3, -5, -7]),
        ]
        for low, high, values in ranges:
            if low <= trophies <= high:
                return values
        return [0] * 5

    @staticmethod
    def _brawler_from_fields(player, fields):
        try:
            return int(fields["Heroes"][0]["Brawler"]["ID"][1])
        except (KeyError, IndexError, TypeError, ValueError):
            return int(getattr(player, "brawler_id", 0))

    @staticmethod
    def _normalize_result(result):
        normalized = copy.deepcopy(result)
        experience = normalized.get("exp_rewards_array", {})
        normalized["exp_rewards_array"] = {
            int(key): int(value) for key, value in experience.items()
        }
        return normalized

    def _cached_result(self, battle_id, game_mode):
        if not battle_id:
            return None
        progression = getattr(self.player, "progression", {})
        history = progression.get("battleEndHistory", {}) if isinstance(progression, dict) else {}
        entry = history.get(battle_id) if isinstance(history, dict) else None
        if not isinstance(entry, dict) or int(entry.get("gameMode", -1)) != game_mode:
            return None
        try:
            age = time.time() - float(entry["timestamp"])
            rewards = entry["rewards"]
        except (KeyError, TypeError, ValueError):
            return None
        if not 0 <= age <= self.HISTORY_SECONDS or not isinstance(rewards, dict):
            return None
        result = self._normalize_result(rewards)
        result["_replayed"] = True
        return result

    def _store_result(self, transaction, battle_id, game_mode, result):
        if not battle_id:
            return
        history = transaction.progression.get("battleEndHistory", {})
        history = copy.deepcopy(history) if isinstance(history, dict) else {}
        current_time = time.time()
        for key, entry in list(history.items()):
            try:
                expired = current_time - float(entry["timestamp"]) > self.HISTORY_SECONDS
            except (KeyError, TypeError, ValueError):
                expired = True
            if expired:
                history.pop(key, None)
        history[battle_id] = {
            "timestamp": int(current_time),
            "gameMode": int(game_mode),
            "rewards": copy.deepcopy(result),
        }
        while len(history) > self.HISTORY_LIMIT:
            history.pop(next(iter(history)))
        transaction.set_progression_value("battleEndHistory", history)

    def process_rewards(self, fields, battle_id=None):
        player = self.player
        game_mode = int(fields.get("GameMode", 0))
        cached = self._cached_result(battle_id, game_mode)
        if cached is not None:
            return cached

        rank = int(fields.get("Rank", getattr(player, "rank", 1)) or 0)
        victory = int(fields.get("Victory", getattr(player, "battle_result", 0)) or 0)
        base_result = int(fields.get("result", getattr(player, "result", 16)) or 0)
        brawler = self._brawler_from_fields(player, fields)
        key = str(brawler)
        tutorial = int(getattr(player, "tutorial", getattr(player, "tutorialState", 2)))
        is_tutorial_complete = tutorial == 2
        special = game_mode in self.SPECIAL_MODES

        trophies = getattr(player, "brawlers_trophies", {})
        highest = getattr(player, "brawlers_trophies_in_rank", {})
        old_trophies = int(trophies.get(key, 0) or 0)
        old_highest = int(highest.get(key, 0) or 0)
        old_experience = int(getattr(player, "player_experience", 0) or 0)
        old_battle_tokens = max(0, int(getattr(player, "battle_tokens", 0) or 0))

        has_star_key = False
        if game_mode == 2:
            if not 1 <= rank <= 10:
                raise RewardError("Rank solo inválido")
            rank_trophies = self.get_solo_trophy_modifiers(old_trophies)
            reward_index = rank - 1
            exp_rewards = [0, 1, 2, 3, 4, 5, 6, 9, 12, 15]
            token_rewards = [0, 2, 4, 6, 8, 12, 16, 22, 28, 34]
            has_star_key = rank <= 4
        elif game_mode == 5:
            if not 1 <= rank <= 5:
                raise RewardError("Rank duo inválido")
            rank_trophies = self.get_duo_trophy_modifiers(old_trophies)
            reward_index = rank - 1
            exp_rewards = [0, 2, 4, 8, 14]
            token_rewards = [0, 4, 8, 20, 32]
            has_star_key = rank <= 2
        elif special:
            if victory not in (0, 1, 2):
                raise RewardError("Resultado de evento inválido")
            rank_trophies = [0, 0, 0]
            reward_index = victory - 1
            exp_rewards = [0, 0, 0]
            token_rewards = [0, 0, 0]
            has_star_key = True
        else:
            if victory not in (0, 1, 2):
                raise RewardError("Resultado 3v3 inválido")
            rank_trophies = self.get_trophy_modifiers(old_trophies)
            reward_index = victory - 1
            exp_rewards = [4, 6, 8]
            token_rewards = [10, 15, 20]
            has_star_key = victory == 0

        trophies_gain = rank_trophies[reward_index] if is_tutorial_complete else 0
        experience = exp_rewards[reward_index] if is_tutorial_complete else 0
        requested_tokens = token_rewards[reward_index] if is_tutorial_complete else 0
        tokens_gain = min(requested_tokens, old_battle_tokens)
        remaining_battle_tokens = old_battle_tokens - tokens_gain

        try:
            is_player = bool(fields["Heroes"][0]["IsPlayer"])
        except (KeyError, IndexError, TypeError):
            is_player = True
        if is_player:
            if special:
                star_player_exp = 0
            else:
                experience += 10 if is_tutorial_complete else 0
                star_player_exp = 10 if is_tutorial_complete else 0
            exp_rewards_array = {0: experience, 8: star_player_exp}
        else:
            star_player_exp = 0
            exp_rewards_array = {0: experience}

        doubler = max(0, int(getattr(player, "tokensdoubler", 0) or 0))
        doubled_tokens = min(tokens_gain, doubler)
        remaining_tokens = doubler - doubled_tokens
        total_tokens = tokens_gain + doubled_tokens

        result_type = base_result
        if has_star_key and (base_result != 0 or special):
            result_type += 1
        if old_battle_tokens <= 0:
            result_type += 4
        if old_experience >= int(getattr(player, "max_experience", 145630)):
            result_type += 2
        if game_mode in (0, 1):
            if victory in (0, 2):
                starplayer = 1 if 0 <= result_type <= 15 else 5
            else:
                starplayer = 1
        else:
            starplayer = 1

        result = {
            "tokens_gain": tokens_gain,
            "requested_tokens": requested_tokens,
            "trophies_gain": trophies_gain,
            "doubled_tokens": doubled_tokens,
            "remaining_tokens": remaining_tokens,
            "total_tokens": total_tokens,
            "exp_rewards_array": exp_rewards_array,
            "brawler_trophies": old_trophies,
            "brawler_trophies_for_rank": old_highest,
            "experience": experience,
            "star_player_exp": star_player_exp,
            "hasStarKey": has_star_key,
            "brawler_id": brawler,
            "milestonesRewardRank": 0,
            "result": result_type,
            "starplayer": starplayer,
            "old_experience": old_experience,
            "old_battle_tokens": old_battle_tokens,
            "battle_tokens": remaining_battle_tokens,
        }
        if not is_tutorial_complete:
            if battle_id:
                transaction = RewardTransaction(player)
                self._store_result(transaction, battle_id, game_mode, result)
                transaction.commit()
            return result

        new_brawler_trophies = max(0, old_trophies + trophies_gain)
        trophies_gain = new_brawler_trophies - old_trophies
        result["trophies_gain"] = trophies_gain
        new_total_trophies = max(
            0, int(getattr(player, "trophies", 0) or 0) + trophies_gain
        )
        new_highest = max(old_highest, new_brawler_trophies)
        for milestone in self.milestones.rankTrophies:
            if old_trophies < milestone <= new_brawler_trophies:
                result["milestonesRewardRank"] = 10

        transaction = RewardTransaction(player)
        new_trophies = copy.deepcopy(trophies)
        new_trophies[key] = new_brawler_trophies
        transaction.set_value("brawlers_trophies", "brawlersTrophies", new_trophies)
        new_rank = copy.deepcopy(highest)
        new_rank[key] = new_highest
        transaction.set_value(
            "brawlers_trophies_in_rank", "brawlersTrophiesForRank", new_rank
        )
        transaction.set_value("trophies", "trophies", new_total_trophies)
        transaction.set_value(
            "highest_trophies", "highest_trophies",
            max(int(getattr(player, "highest_trophies", 0) or 0), new_total_trophies),
        )
        transaction.set_value(
            "player_experience", "playerExp", old_experience + experience + star_player_exp,
        )
        transaction.set_value("tokensdoubler", "tokensdoubler", remaining_tokens)
        transaction.set_value("battle_tokens", "battleTokens", remaining_battle_tokens)
        transaction.set_value(
            "brawl_boxes", "brawlBoxes",
            int(getattr(player, "brawl_boxes", 0) or 0) + total_tokens,
        )
        transaction.set_value(
            "big_boxes", "bigBoxes",
            int(getattr(player, "big_boxes", 0) or 0) + (1 if has_star_key else 0),
        )
        if not special:
            if game_mode == 2:
                transaction.set_value(
                    "solo_wins", "soloWins", int(getattr(player, "solo_wins", 0) or 0) + 1
                )
            elif game_mode == 5:
                transaction.set_value(
                    "duo_wins", "duoWins", int(getattr(player, "duo_wins", 0) or 0) + 1
                )
            else:
                transaction.set_value(
                    "ThreeVSThree_wins", "TvsTWins",
                    int(getattr(player, "ThreeVSThree_wins", 0) or 0) + 1,
                )
        transaction.set_progression_value("keyReward", total_tokens)
        transaction.set_progression_value("trophyReward", trophies_gain)
        transaction.set_progression_value("starKeyReward", 1 if has_star_key else 0)
        self._store_result(transaction, battle_id, game_mode, result)
        transaction.commit()
        return result
