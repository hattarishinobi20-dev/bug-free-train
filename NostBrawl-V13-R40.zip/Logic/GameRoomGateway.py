from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamGameStartingMessage import TeamGameStartingMessage
from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage


class GameRoomGateway:
    @staticmethod
    def deliver(client, player, room):
        TeamGameroomDataMessage(client, player, room).send()
        return GameRoomGateway.broadcast(player, room, {player.low_id})

    @staticmethod
    def broadcast(player, room, excluded=()):
        if room is None:
            return 0
        excluded = {int(value) for value in excluded}
        delivered = 0
        for member in room["members"]:
            low_id = member["low_id"]
            if low_id in excluded:
                continue
            message = TeamGameroomDataMessage(None, player, room)
            if message.sendWithLowID(low_id):
                delivered += 1
        return delivered

    @staticmethod
    def send_starting(player, room, client=None):
        delivered = 0
        if client is not None:
            TeamGameStartingMessage(client, player, room).send()
            delivered += 1
        for member in room["members"]:
            if client is not None and member["low_id"] == int(getattr(player, "low_id", 0)):
                continue
            message = TeamGameStartingMessage(None, player, room)
            if message.sendWithLowID(member["low_id"]):
                delivered += 1
        return delivered

    @staticmethod
    def send_left(player, low_id):
        return TeamLeftMessage(None, player).sendWithLowID(int(low_id))
