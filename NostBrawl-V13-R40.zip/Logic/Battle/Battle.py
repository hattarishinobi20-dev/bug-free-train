from Packets.Messages.Server.Battle.VisionUpdateMessage import VisionUpdateMessage
from Packets.Messages.Server.Battle.StartLoadingMessage import StartLoadingMessage
import time
from multiprocessing import Process


class Battle(Process):
    def __init__(self, client, player, state):
        Process.__init__(self)
        self.client = client
        self.player = player
        self.subTick = 0
        self.tick = 0
        self.started = 0
        self.state = state

    def run(self):
        self.startBattle()

    def startBattle(self):
        self.started = 1
        StartLoadingMessage(self.client, self.player).send()
        while self.started:
            self.tick += 1
            self.subTick = 0
            self.player.battleTick = self.tick
            try:
                VisionUpdateMessage(self.client, self.player).send()
                time.sleep(0.0515)
            except ConnectionResetError:
                break
