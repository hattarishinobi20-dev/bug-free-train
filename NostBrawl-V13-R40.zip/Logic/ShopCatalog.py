import csv
import json
from functools import lru_cache

from Files.CsvLogic.Characters import Characters
from Logic.Rewards import RewardError


class ShopCatalog:
    GOLD_OFFERS = (
        {"Amount": 150, "Cost": 20},
        {"Amount": 400, "Cost": 50},
        {"Amount": 1200, "Cost": 140},
        {"Amount": 2600, "Cost": 280},
    )
    TOKEN_DOUBLER = {"Amount": 1000, "Cost": 50}
    BOX_TYPES = {0: 10, 6: 10, 10: 11, 14: 12, 15: 10}
    CURRENCIES = {0: "gems", 1: "gold", 2: "starpoints"}

    @staticmethod
    def _integer(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _boolean(value):
        return str(value or "").strip().upper() == "TRUE"

    @classmethod
    @lru_cache(maxsize=1)
    def shop_items(cls):
        with open(
            "GameAssets/csv_client/shop_items.csv", "r", encoding="utf-8", newline=""
        ) as source:
            rows = list(csv.DictReader(source))[1:]
        result = {}
        for row in rows:
            offer_id = cls._integer(row.get("OfferType"), -1)
            if offer_id >= 0:
                result[offer_id] = row["Name"]
        return result

    @classmethod
    def validate_item(cls, item):
        if not isinstance(item, dict):
            raise ValueError("Invalid shop item")
        offer_id = cls._integer(item.get("offerId"), -1)
        if offer_id not in cls.shop_items():
            raise ValueError(f"Unknown offer item: {offer_id}")
        amount = cls._integer(item.get("amount"), -1)
        value = cls._integer(item.get("value"), -1)
        if amount < 1 or value < 0:
            raise ValueError("Invalid shop item amount")
        target = item.get("target")
        if target is not None:
            if not isinstance(target, (list, tuple)) or len(target) != 2:
                raise ValueError("Invalid shop item target")
            target = [int(target[0]), int(target[1])]
            if target[0] <= 0 or target[1] < 0:
                raise ValueError("Invalid shop item target")
        if offer_id == 0 and value != 1:
            raise ValueError("FreeBox requires Value 1")
        if offer_id == 8:
            if value < 1 or target is None or target[0] != 16:
                raise ValueError("HeroPower requires a brawler and extra data")
            if target[1] not in Characters.get_brawlers_id():
                raise ValueError("Invalid HeroPower brawler")
        if offer_id in (3, 5) and (target is None or target[0] != 16):
            raise ValueError("Brawler offer requires a character reference")
        if offer_id in (2, 3, 4, 5) and amount != 1:
            raise ValueError("Unique rewards require Amount 1")
        return {
            "offerId": offer_id,
            "value": value,
            "target": target,
            "amount": amount,
        }

    @classmethod
    @lru_cache(maxsize=1)
    def daily_definitions(cls):
        with open("JSON/shop.json", "r", encoding="utf-8") as source:
            config = json.load(source)
        daily = config.get("daily", [])
        if not daily:
            raise ValueError("The shop catalog is empty")
        for definition in daily:
            cls.validate_definition(definition)
        return config

    @classmethod
    def validate_definition(cls, definition):
        items = definition.get("items", [])
        if not 1 <= len(items) <= 3:
            raise ValueError("An offer requires between one and three items")
        definition["items"] = [cls.validate_item(item) for item in items]
        currency = cls._integer(definition.get("currency"), -1)
        price = cls._integer(definition.get("price"), -1)
        original = cls._integer(definition.get("originalPrice", price), -1)
        if currency not in cls.CURRENCIES or price < 0 or original < price:
            raise ValueError("Invalid offer price")
        if not str(definition.get("key", "")):
            raise ValueError("An offer requires a stable key")
        display = cls._integer(definition.get("display"), 0)
        if display not in (0, 1):
            raise ValueError("Invalid offer display")
        definition["currency"] = currency
        definition["price"] = price
        definition["originalPrice"] = original
        definition["display"] = display
        return definition

    @classmethod
    @lru_cache(maxsize=1)
    def billing_packages(cls):
        with open(
            "GameAssets/csv_client/billing_packages.csv",
            "r",
            encoding="utf-8",
            newline="",
        ) as source:
            rows = list(csv.DictReader(source))[1:]
        packages = {}
        for row in rows:
            name = row.get("Name", "")
            package_type = cls._integer(row.get("Type"), 0)
            diamonds = cls._integer(row.get("Diamonds"), 0)
            if not name or package_type not in (1, 2, 3) or diamonds < 1:
                continue
            packages[name] = {
                "name": name,
                "tid": row.get("TID", ""),
                "type": package_type,
                "disabled": cls._boolean(row.get("Disabled")),
                "android": cls._boolean(row.get("ExistsAndroid")),
                "diamonds": diamonds,
                "order": cls._integer(row.get("Order"), 0),
                "starterPackNumber": cls._integer(row.get("StarterPackNumber"), 0),
                "bigBoxCount": cls._integer(row.get("BigBoxCount"), 0),
                "xpLevelReq": cls._integer(row.get("XpLevelReq"), 0),
            }
        return packages

    @classmethod
    def billing_package(cls, values):
        matches = []
        for value in values:
            if value in cls.billing_packages():
                package = cls.billing_packages()[value]
                if package not in matches:
                    matches.append(package)
        if len(matches) != 1:
            raise RewardError("Pacote de billing desconhecido ou ambíguo")
        package = matches[0]
        if package["disabled"] or not package["android"]:
            raise RewardError("Pacote de billing indisponível")
        return package
