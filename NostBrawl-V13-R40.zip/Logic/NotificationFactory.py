import copy
import time

from Files.CsvLogic.Skins import Skins


class NotificationFactory:
    SKIN_REWARD_TYPE = 94
    SKIN_GLOBAL_ID = 29000000
    STAR_SHELLY_SKIN_ID = 52
    STAR_SHELLY_TEXT = (
        "You have unlocked a new skin! Thank you for playing Brawl Stars in 2018"
    )
    WIZARD_BARLEY_SKIN_ID = 59
    WIZARD_BARLEY_TEXT = (
        "You have unlocked a new skin! Thank you for registering your Supercell ID"
    )

    @staticmethod
    def _integer(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    @classmethod
    def _entries(cls, notifications):
        if isinstance(notifications, dict):
            values = [notifications[key] for key in sorted(notifications, key=str)]
        elif isinstance(notifications, (list, tuple)):
            values = list(notifications)
        else:
            return []
        entries = []
        for value in values:
            if not isinstance(value, dict):
                continue
            notification_type = cls._integer(
                value.get("Type", value.get("ID", value.get("type", 0)))
            )
            if notification_type != cls.SKIN_REWARD_TYPE:
                continue
            if "SkinID" in value:
                skin_id = cls._integer(value.get("SkinID"), -1)
            else:
                skin_id = cls._integer(value.get("sd"), -1)
                if skin_id >= cls.SKIN_GLOBAL_ID:
                    skin_id -= cls.SKIN_GLOBAL_ID
            if skin_id < 0:
                continue
            entries.append((value, skin_id))
        return entries

    @classmethod
    def encode(cls, writer, notifications, now=None):
        entries = [
            (notification, skin_id)
            for notification, skin_id in cls._entries(notifications)
            if not bool(notification.get("Read", notification.get("nrd", False)))
        ]
        writer.v(len(entries))
        for _, skin_id in entries:
            writer.v(cls.SKIN_REWARD_TYPE)
            writer.v(cls.SKIN_GLOBAL_ID + skin_id)

    @classmethod
    def _prepare_skin(cls, player, skin_id, text):
        skin_id = cls._integer(skin_id, -1)
        Skins.getSkinPrice(skin_id)
        current = getattr(player, "Notifications", {})
        if not isinstance(current, dict):
            current = {}
        notifications = copy.deepcopy(current)
        numeric_keys = [cls._integer(key, -1) for key in notifications]
        next_key = str(max(numeric_keys + [-1]) + 1)
        indices = [
            cls._integer(value.get("Index", 0))
            for value in notifications.values()
            if isinstance(value, dict)
        ]
        notification = {
            "Type": cls.SKIN_REWARD_TYPE,
            "Index": max(indices + [0]) + 1,
            "Read": False,
            "Time": time.time(),
            "Text": str(text),
            "SkinID": skin_id,
        }
        notifications[next_key] = notification
        return notifications, notification

    @classmethod
    def add_skin(cls, player, skin_id, text="Voucher gift"):
        notifications, notification = cls._prepare_skin(player, skin_id, text)
        from Database.DatabaseManager import DataBase
        low_id = cls._integer(getattr(player, "low_id", 0))
        if low_id <= 0 or not DataBase._update_value(
            "lowID", low_id, "Notifications", notifications
        ):
            raise RuntimeError("Não foi possível persistir a notificação")
        player.Notifications = notifications
        return copy.deepcopy(notification)

    @classmethod
    def ensure_skin(cls, player, skin_id, text):
        skin_id = cls._integer(skin_id, -1)
        for _, existing_skin in cls._entries(
            getattr(player, "Notifications", {})
        ):
            if existing_skin == skin_id:
                return False
        cls.add_skin(player, skin_id, text)
        return True

    @classmethod
    def ensure_star_shelly(cls, player):
        return cls.ensure_skin(
            player, cls.STAR_SHELLY_SKIN_ID, cls.STAR_SHELLY_TEXT
        )

    @classmethod
    def ensure_wizard_barley(cls, player):
        from Logic.Rewards import RewardTransaction
        brawler_id = Skins.getBrawler(cls.WIZARD_BARLEY_SKIN_ID)
        states = getattr(player, "BrawlersUnlockedState", {})
        unlocked = isinstance(states, dict) and states.get(
            str(brawler_id), states.get(brawler_id, 0)
        ) == 1
        has_notification = any(
            skin_id == cls.WIZARD_BARLEY_SKIN_ID
            for _, skin_id in cls._entries(
                getattr(player, "Notifications", {})
            )
        )
        if unlocked and has_notification:
            return False
        transaction = RewardTransaction(player)
        if not unlocked:
            transaction.add_reward("Brawler", brawler_id)
        if not has_notification:
            notifications, _ = cls._prepare_skin(
                player, cls.WIZARD_BARLEY_SKIN_ID, cls.WIZARD_BARLEY_TEXT
            )
            transaction.set_value("Notifications", "Notifications", notifications)
        transaction.commit()
        return True

    @classmethod
    def claim_next_skin(cls, player):
        current = getattr(player, "Notifications", {})
        if not isinstance(current, dict):
            raise ValueError("Notificação não encontrada")
        pending = [
            (notification, skin_id)
            for notification, skin_id in cls._entries(current)
            if not bool(notification.get("Read", notification.get("nrd", False)))
        ]
        if not pending:
            raise ValueError("Notificação não encontrada")
        notification_index = cls._integer(pending[0][0].get("Index"), -1)
        if notification_index <= 0:
            raise ValueError("Notificação sem índice válido")
        return cls.claim_skin(player, notification_index)

    @classmethod
    def claim_skin(cls, player, notification_index):
        from Logic.Rewards import RewardTransaction
        notification_index = cls._integer(notification_index, -1)
        current = getattr(player, "Notifications", {})
        if not isinstance(current, dict):
            raise ValueError("Notificação não encontrada")
        notifications = copy.deepcopy(current)
        for notification in notifications.values():
            if not isinstance(notification, dict):
                continue
            if cls._integer(notification.get("Index"), -1) != notification_index:
                continue
            entries = cls._entries([notification])
            if not entries:
                raise ValueError("A notificação não é uma recompensa de skin")
            skin_id = entries[0][1]
            if bool(notification.get("Read", notification.get("nrd", False))):
                raise ValueError("Notificação já resgatada")
            brawler_id = Skins.getBrawler(skin_id)
            owned = getattr(player, "UnlockedSkins", {}).get("Skins", [])
            already_owned = skin_id in owned
            transaction = RewardTransaction(player)
            if not already_owned:
                unlocked_skins = copy.deepcopy(
                    getattr(player, "UnlockedSkins", {"Skins": []})
                )
                unlocked_skins.setdefault("Skins", []).append(skin_id)
                transaction.set_value(
                    "UnlockedSkins", "UnlockedSkins", unlocked_skins
                )
                states = getattr(player, "BrawlersUnlockedState", {})
                if states.get(str(brawler_id), states.get(brawler_id, 0)) == 1:
                    selected_skins = copy.deepcopy(
                        getattr(player, "brawlers_skins", {})
                    )
                    selected_skins[str(brawler_id)] = skin_id
                    transaction.set_value(
                        "brawlers_skins", "brawlersSkins", selected_skins
                    )
            notification["Read"] = True
            transaction.set_value("Notifications", "Notifications", notifications)
            transaction.commit()
            return {
                "skin": skin_id,
                "brawler": brawler_id,
                "index": notification_index,
                "alreadyOwned": already_owned,
            }
        raise ValueError("Notificação não encontrada")
