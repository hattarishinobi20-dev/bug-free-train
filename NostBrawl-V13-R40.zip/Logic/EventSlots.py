from Logic.EventRotation import EventRotation


class EventSlots:
    def Timer(self):
        return EventRotation.seconds_to_next_day()

    def loadEvents(self):
        player = getattr(self, "player", None)
        return EventRotation.legacy_events(player)
