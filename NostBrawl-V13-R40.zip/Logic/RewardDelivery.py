from Logic.Rewards import RewardError


class RewardDelivery:
    BOX_RESOURCES = {
        10: (5000001, 100),
        12: (5000009, 10),
    }

    @staticmethod
    def display(detail):
        name = detail["name"]
        amount = int(detail["amount"])
        target = int(detail.get("target", 0) or 0)
        displays = {
            "Coins": {"type": 1, "amount": amount},
            "gems": {"type": 2, "amount": amount},
            "tickets": {"type": 3, "amount": amount},
            "tokens_doubler": {"type": 4, "amount": amount},
            "UpgradePoints": {"type": 5, "amount": amount, "brawler": target},
            "Brawler": {"type": 6, "amount": 1, "brawler": amount},
            "Skin": {"type": 7, "amount": 1, "skin": amount},
            "StarPower": {"type": 8, "amount": 1, "brawler": target},
        }
        if name not in displays:
            raise RewardError(f"Resposta de recompensa inválida: {name}")
        return displays[name]

    @classmethod
    def displays(cls, details):
        return [cls.display(detail) for detail in details]

    @classmethod
    def responses(cls, rewards, stored_boxes):
        responses = []
        if rewards:
            responses.append({"kind": "item", "rewards": list(rewards)})
        for entry in stored_boxes:
            box_type = int(entry["boxType"])
            amount = int(entry["amount"])
            if box_type == 11:
                continue
            if box_type not in cls.BOX_RESOURCES or amount < 1:
                raise RewardError("Caixa entregue inválida")
            resource, unit_cost = cls.BOX_RESOURCES[box_type]
            responses.append({
                "kind": "resource",
                "resource": resource,
                "amount": amount * unit_cost,
            })
        return responses

    @staticmethod
    def send(client, player, response):
        kind = response["kind"]
        if kind == "item":
            from Packets.Commands.Server.LogicBuyItem import LogicBuyItem
            LogicBuyItem(client, player, response["rewards"]).send()
            return
        if kind == "resource":
            from Packets.Commands.Server.LogicChangeResourcesCommand import LogicChangeResourcesCommand
            LogicChangeResourcesCommand(
                client, player, response["resource"], response["amount"]
            ).send()
            return
        if kind == "box":
            from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
            LogicBoxDataCommand(client, player, response["result"]).send()
            return
        raise ValueError(f"Unknown reward response: {kind}")

    @classmethod
    def send_many(cls, client, player, responses):
        for response in responses:
            cls.send(client, player, response)
