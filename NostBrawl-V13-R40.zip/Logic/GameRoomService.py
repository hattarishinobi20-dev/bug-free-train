import json
import secrets
import time

from Database.DatabaseManager import DataBase
from Files.CsvLogic.Skins import Skins
from Logic.EventRotation import EventRotation


class GameRoomError(ValueError):
    pass


class GameRoomService:
    MAX_ROOM_ID = 2147483647
    OPEN = 0
    STARTING = 1

    @staticmethod
    def _now():
        return int(time.time())

    @staticmethod
    def _account_id(player):
        try:
            low_id = int(getattr(player, "low_id", 0) or 0)
        except (TypeError, ValueError):
            low_id = 0
        if low_id <= 0:
            raise GameRoomError("Conta inválida para GameRoom")
        return low_id

    @classmethod
    def _location(cls, map_id):
        try:
            map_id = int(map_id)
        except (TypeError, ValueError):
            raise GameRoomError("Mapa inválido") from None
        locations = EventRotation.locations()
        if not 0 <= map_id < len(locations) or not locations[map_id]["enabled"]:
            raise GameRoomError("Mapa não habilitado")
        return locations[map_id]

    @classmethod
    def _map_for_create(cls, player, slot, requested_map):
        try:
            slot = int(slot)
            requested_map = int(requested_map)
        except (TypeError, ValueError):
            raise GameRoomError("Slot ou mapa inválido") from None
        if 1 <= slot <= len(EventRotation.SLOT_POOLS):
            event = EventRotation.resolve_slot(player, slot)
            return event["map_id"], slot
        if requested_map == -64:
            event = EventRotation.resolve_slot(player, 0)
            return event["map_id"], 0
        return cls._location(requested_map)["id"], 0

    @staticmethod
    def _capacity(location):
        return 10 if location["game_mode"] in {"BattleRoyale", "BattleRoyaleTeam"} else 6

    @staticmethod
    def _membership(connection, low_id):
        return connection.execute(
            "SELECT room_id FROM game_room_members WHERE low_id = ?", (low_id,)
        ).fetchone()

    @classmethod
    def _room_row(cls, connection, room_id):
        row = connection.execute(
            "SELECT id, room_type, map_id, slot_index, practice, advertise_band, "
            "advertise_friends, owner_id, state, created_at, updated_at "
            "FROM game_rooms WHERE id = ?", (room_id,)
        ).fetchone()
        if row is None:
            raise GameRoomError("GameRoom inexistente")
        return row

    @classmethod
    def _next_team(cls, connection, room_id, location):
        rows = connection.execute(
            "SELECT team, COUNT(*) FROM game_room_members WHERE room_id = ? GROUP BY team",
            (room_id,),
        ).fetchall()
        counts = {int(row[0]): int(row[1]) for row in rows}
        if location["game_mode"] == "BattleRoyaleTeam":
            for team in range(5):
                if counts.get(team, 0) < 2:
                    return team
            raise GameRoomError("GameRoom cheia")
        if location["game_mode"] == "BattleRoyale":
            return 0
        capacity = cls._capacity(location)
        for team in range(2):
            if counts.get(team, 0) < capacity // 2:
                return team
        raise GameRoomError("GameRoom cheia")

    @classmethod
    def _snapshot(cls, connection, room_id):
        row = cls._room_row(connection, room_id)
        location = cls._location(row[2])
        room = {
            "id": int(row[0]),
            "room_type": int(row[1]),
            "map_id": int(row[2]),
            "slot_index": int(row[3]),
            "practice": bool(row[4]),
            "advertise_band": bool(row[5]),
            "advertise_friends": bool(row[6]),
            "owner_id": int(row[7]),
            "state": int(row[8]),
            "created_at": int(row[9]),
            "updated_at": int(row[10]),
            "game_mode": location["game_mode"],
            "capacity": cls._capacity(location),
            "members": [],
        }
        members = connection.execute(
            "SELECT m.low_id, m.host, m.ready, m.team, m.status, m.brawler_id, "
            "m.skin_id, m.joined_at, p.name, p.profileIcon, p.namecolor, "
            "p.brawlersTrophies, p.brawlersTrophiesForRank, p.brawlerPowerLevel, "
            "p.brawlerStarPower FROM game_room_members m "
            "JOIN players p ON p.lowID = m.low_id WHERE m.room_id = ? "
            "ORDER BY m.joined_at, m.low_id", (room_id,)
        ).fetchall()
        for member in members:
            brawler_id = int(member[5])
            brawler_key = str(brawler_id)
            skin_id = Skins.resolve_skin(brawler_id, member[6])
            trophies = DataBase._decode_json(member[11], "brawlersTrophies")
            highest = DataBase._decode_json(member[12], "brawlersTrophiesForRank")
            levels = DataBase._decode_json(member[13], "brawlerPowerLevel")
            star_powers = DataBase._decode_json(member[14], "brawlerStarPower")
            room["members"].append({
                "low_id": int(member[0]),
                "high_id": 0,
                "host": bool(member[1]),
                "ready": bool(member[2]),
                "team": int(member[3]),
                "status": int(member[4]),
                "brawler_id": brawler_id,
                "skin_id": skin_id,
                "joined_at": int(member[7]),
                "name": str(member[8] or ""),
                "profile_icon": int(member[9] or 0),
                "name_color": int(member[10] or 0),
                "trophies": int(trophies.get(brawler_key, 0) or 0),
                "highest_trophies": int(highest.get(brawler_key, 0) or 0),
                "power_level": int(levels.get(brawler_key, 1) or 1),
                "star_power": int(star_powers.get(brawler_key, 0) or 0),
            })
        room["player_count"] = len(room["members"])
        invite_rows = connection.execute(
            "SELECT i.recipient_id, i.invite_type, i.created_at, p.name, i.sender_id "
            "FROM game_room_invites i JOIN players p ON p.lowID = i.recipient_id "
            "WHERE i.room_id = ? ORDER BY i.created_at, i.recipient_id", (room_id,)
        ).fetchall()
        room["invites"] = [
            {
                "recipient_id": int(invite[0]),
                "invite_type": int(invite[1]),
                "created_at": int(invite[2]),
                "name": str(invite[3] or ""),
                "sender_id": int(invite[4]),
                "status": 0,
            }
            for invite in invite_rows
        ]
        request_rows = connection.execute(
            "SELECT player_id, created_at FROM game_room_join_requests "
            "WHERE room_id = ? ORDER BY created_at, player_id", (room_id,)
        ).fetchall()
        from Logic.FriendService import FriendService
        room["join_requests"] = []
        for request in request_rows:
            entry = FriendService._entry(connection, room["owner_id"], request[0], 1)
            if entry is not None:
                room["join_requests"].append({
                    "player_id": int(request[0]),
                    "created_at": int(request[1]),
                    "entry": entry,
                })
        return room

    @staticmethod
    def _set_player_room(connection, low_id, room_id):
        cursor = connection.execute(
            "UPDATE players SET roomID = ? WHERE lowID = ?", (room_id, low_id)
        )
        if cursor.rowcount != 1:
            raise GameRoomError("Conta não encontrada")

    @staticmethod
    def _sync(player, room):
        player.room_id = int(room["id"]) if room else 0
        if room:
            for member in room["members"]:
                if member["low_id"] == int(getattr(player, "low_id", 0) or 0):
                    player.map_id = room["map_id"]
                    player.slot_index = room["slot_index"]
                    player.isReady = int(member["ready"])
                    player.team = member["team"]
                    player.status = member["status"]
                    player.brawler_id = member["brawler_id"]
                    player.skin_id = member["skin_id"]
                    break

    @classmethod
    def get(cls, room_id):
        with DataBase._connection() as connection:
            return cls._snapshot(connection, int(room_id))

    @classmethod
    def for_player(cls, player):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            membership = cls._membership(connection, low_id)
            if membership is None:
                cls._set_player_room(connection, low_id, 0)
                room = None
            else:
                room = cls._snapshot(connection, membership[0])
        cls._sync(player, room)
        return room

    @classmethod
    def create(cls, player, slot, requested_map, room_type, practice=False):
        low_id = cls._account_id(player)
        map_id, slot = cls._map_for_create(player, slot, requested_map)
        location = cls._location(map_id)
        try:
            room_type = int(room_type)
        except (TypeError, ValueError):
            raise GameRoomError("Tipo de GameRoom inválido") from None
        if not 0 <= room_type <= 3:
            raise GameRoomError("Tipo de GameRoom inválido")
        now = cls._now()
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if cls._membership(connection, low_id) is not None:
                raise GameRoomError("Conta já pertence a uma GameRoom")
            for _ in range(32):
                room_id = secrets.randbelow(cls.MAX_ROOM_ID - 1) + 1
                try:
                    connection.execute(
                        "INSERT INTO game_rooms(id, room_type, map_id, slot_index, "
                        "practice, advertise_band, advertise_friends, owner_id, state, "
                        "created_at, updated_at) VALUES(?, ?, ?, ?, ?, 0, 1, ?, 0, ?, ?)",
                        (room_id, room_type, map_id, slot, int(bool(practice)), low_id, now, now),
                    )
                    break
                except Exception as error:
                    if "UNIQUE" not in str(error).upper():
                        raise
            else:
                raise GameRoomError("Não foi possível alocar a GameRoom")
            connection.execute(
                "INSERT INTO game_room_members(room_id, low_id, host, ready, team, "
                "status, brawler_id, skin_id, joined_at) VALUES(?, ?, 1, 0, 0, 3, ?, ?, ?)",
                (
                    room_id, low_id, int(getattr(player, "brawler_id", 0) or 0),
                    int(getattr(player, "skin_id", 0) or 0), now,
                ),
            )
            cls._set_player_room(connection, low_id, room_id)
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def _join_locked(cls, connection, low_id, room_id, now):
        low_id = int(low_id)
        room_id = int(room_id)
        existing = cls._membership(connection, low_id)
        if existing is not None:
            if int(existing[0]) == room_id:
                return cls._snapshot(connection, room_id)
            raise GameRoomError("Conta já pertence a outra GameRoom")
        row = cls._room_row(connection, room_id)
        if int(row[8]) != cls.OPEN:
            raise GameRoomError("Partida já iniciada")
        location = cls._location(row[2])
        count = connection.execute(
            "SELECT COUNT(*) FROM game_room_members WHERE room_id = ?", (room_id,)
        ).fetchone()[0]
        if count >= cls._capacity(location):
            raise GameRoomError("GameRoom cheia")
        account = connection.execute(
            "SELECT brawlerID, skinID FROM players WHERE lowID = ?", (low_id,)
        ).fetchone()
        if account is None:
            raise GameRoomError("Conta não encontrada")
        team = cls._next_team(connection, room_id, location)
        connection.execute(
            "INSERT INTO game_room_members(room_id, low_id, host, ready, team, "
            "status, brawler_id, skin_id, joined_at) VALUES(?, ?, 0, 0, ?, 3, ?, ?, ?)",
            (room_id, low_id, team, int(account[0] or 0), int(account[1] or 0), now),
        )
        connection.execute(
            "UPDATE game_rooms SET updated_at = ? WHERE id = ?", (now, room_id)
        )
        cls._set_player_room(connection, low_id, room_id)
        return cls._snapshot(connection, room_id)

    @classmethod
    def join(cls, player, room_id):
        low_id = cls._account_id(player)
        try:
            room_id = int(room_id)
        except (TypeError, ValueError):
            raise GameRoomError("GameRoom inválida") from None
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room = cls._join_locked(connection, low_id, room_id, cls._now())
        cls._sync(player, room)
        return room

    @classmethod
    def _member_for_update(cls, connection, room_id, low_id):
        row = connection.execute(
            "SELECT host FROM game_room_members WHERE room_id = ? AND low_id = ?",
            (room_id, low_id),
        ).fetchone()
        if row is None:
            raise GameRoomError("Jogador não pertence à GameRoom")
        return row

    @classmethod
    def _mutable_room(cls, player, connection, host=False):
        low_id = cls._account_id(player)
        membership = cls._membership(connection, low_id)
        if membership is None:
            raise GameRoomError("Conta não pertence a uma GameRoom")
        room_id = int(membership[0])
        row = cls._room_row(connection, room_id)
        member = cls._member_for_update(connection, room_id, low_id)
        if host and not member[0]:
            raise GameRoomError("Somente o dono pode alterar a GameRoom")
        return room_id, row, low_id

    @classmethod
    def set_location(cls, player, map_id, slot=0, room_type=None):
        location = cls._location(map_id)
        now = cls._now()
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, row, _ = cls._mutable_room(player, connection, host=True)
            new_type = int(row[1]) if room_type is None else int(room_type)
            if not 0 <= new_type <= 3:
                raise GameRoomError("Tipo de GameRoom inválido")
            connection.execute(
                "UPDATE game_rooms SET map_id = ?, slot_index = ?, room_type = ?, "
                "state = 0, updated_at = ? WHERE id = ?",
                (location["id"], int(slot), new_type, now, room_id),
            )
            connection.execute(
                "UPDATE game_room_members SET ready = 0, team = -1 WHERE room_id = ?",
                (room_id,),
            )
            member_ids = [int(item[0]) for item in connection.execute(
                "SELECT low_id FROM game_room_members WHERE room_id = ? "
                "ORDER BY joined_at, low_id", (room_id,)
            ).fetchall()]
            for member_id in member_ids:
                team = cls._next_team(connection, room_id, location)
                connection.execute(
                    "UPDATE game_room_members SET team = ? WHERE room_id = ? AND low_id = ?",
                    (team, room_id, member_id),
                )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def set_ranked_location(cls, player, slot):
        event = EventRotation.resolve_slot(player, slot)
        return cls.set_location(player, event["map_id"], event["slot"], 0)

    @classmethod
    def toggle_practice(cls, player):
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, row, _ = cls._mutable_room(player, connection, host=True)
            connection.execute(
                "UPDATE game_rooms SET practice = ?, state = 0, updated_at = ? WHERE id = ?",
                (0 if row[4] else 1, cls._now(), room_id),
            )
            connection.execute(
                "UPDATE game_room_members SET ready = 0 WHERE room_id = ?", (room_id,)
            )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def set_advertisement(cls, player, enabled):
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, _ = cls._mutable_room(player, connection, host=True)
            connection.execute(
                "UPDATE game_rooms SET advertise_band = ?, updated_at = ? WHERE id = ?",
                (int(bool(enabled)), cls._now(), room_id),
            )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def set_member_settings(cls, player, brawler_id, skin_id):
        from Files.CsvLogic.Skins import Skins
        try:
            brawler_id = int(brawler_id)
            skin_id = int(skin_id)
        except (TypeError, ValueError):
            raise GameRoomError("Configuração de membro inválida") from None
        if Skins.getBrawler(skin_id) != brawler_id:
            raise GameRoomError("Skin não pertence ao brawler")
        now = cls._now()
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, low_id = cls._mutable_room(player, connection)
            connection.execute(
                "UPDATE game_room_members SET brawler_id = ?, skin_id = ?, ready = 0 "
                "WHERE room_id = ? AND low_id = ?",
                (brawler_id, skin_id, room_id, low_id),
            )
            connection.execute(
                "UPDATE game_rooms SET state = 0, updated_at = ? WHERE id = ?",
                (now, room_id),
            )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def set_ready(cls, player, ready):
        now = cls._now()
        started = False
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, row, low_id = cls._mutable_room(player, connection)
            if int(row[8]) == cls.STARTING:
                room = cls._snapshot(connection, room_id)
            else:
                connection.execute(
                    "UPDATE game_room_members SET ready = ? WHERE room_id = ? AND low_id = ?",
                    (int(bool(ready)), room_id, low_id),
                )
                pending = connection.execute(
                    "SELECT COUNT(*) FROM game_room_members WHERE room_id = ? AND ready = 0",
                    (room_id,),
                ).fetchone()[0]
                if pending == 0 and bool(ready):
                    connection.execute(
                        "UPDATE game_rooms SET state = 1, updated_at = ? WHERE id = ?",
                        (now, room_id),
                    )
                    started = True
                else:
                    connection.execute(
                        "UPDATE game_rooms SET updated_at = ? WHERE id = ?", (now, room_id)
                    )
                room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room, started

    @classmethod
    def set_status(cls, player, status):
        try:
            status = int(status)
        except (TypeError, ValueError):
            raise GameRoomError("Status inválido") from None
        if not 0 <= status <= 11:
            raise GameRoomError("Status inválido")
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, low_id = cls._mutable_room(player, connection)
            connection.execute(
                "UPDATE game_room_members SET status = ? WHERE room_id = ? AND low_id = ?",
                (status, room_id, low_id),
            )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def set_teams(cls, player, targets, team):
        try:
            team = int(team)
        except (TypeError, ValueError):
            raise GameRoomError("Equipe inválida") from None
        if not targets:
            raise GameRoomError("Nenhum membro informado")
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, row, _ = cls._mutable_room(player, connection, host=True)
            location = cls._location(row[2])
            if location["game_mode"] == "BattleRoyaleTeam":
                valid_teams = set(range(5))
            elif location["game_mode"] == "BattleRoyale":
                valid_teams = {0}
            else:
                valid_teams = {0, 1}
            if team not in valid_teams:
                raise GameRoomError("Equipe incompatível com o modo")
            member_ids = {
                int(item[0]) for item in connection.execute(
                    "SELECT low_id FROM game_room_members WHERE room_id = ?", (room_id,)
                ).fetchall()
            }
            target_ids = {int(target[1]) for target in targets}
            if not target_ids or not target_ids.issubset(member_ids):
                raise GameRoomError("Membro de outra GameRoom")
            for target_id in target_ids:
                connection.execute(
                    "UPDATE game_room_members SET team = ?, ready = 0 "
                    "WHERE room_id = ? AND low_id = ?", (team, room_id, target_id)
                )
            connection.execute(
                "UPDATE game_rooms SET state = 0 WHERE id = ?", (room_id,)
            )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def leave(cls, player):
        low_id = cls._account_id(player)
        now = cls._now()
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            membership = cls._membership(connection, low_id)
            if membership is None:
                cls._set_player_room(connection, low_id, 0)
                room = None
            else:
                room_id = int(membership[0])
                connection.execute(
                    "DELETE FROM game_room_members WHERE room_id = ? AND low_id = ?",
                    (room_id, low_id),
                )
                cls._set_player_room(connection, low_id, 0)
                remaining = connection.execute(
                    "SELECT COUNT(*) FROM game_room_members WHERE room_id = ?", (room_id,)
                ).fetchone()[0]
                if remaining == 0:
                    connection.execute("DELETE FROM game_rooms WHERE id = ?", (room_id,))
                    room = None
                else:
                    owner = connection.execute(
                        "SELECT 1 FROM game_room_members WHERE room_id = ? AND host = 1",
                        (room_id,),
                    ).fetchone()
                    if owner is None:
                        successor = connection.execute(
                            "SELECT low_id FROM game_room_members WHERE room_id = ? "
                            "ORDER BY joined_at, low_id LIMIT 1", (room_id,)
                        ).fetchone()[0]
                        connection.execute(
                            "UPDATE game_room_members SET host = 1 WHERE room_id = ? AND low_id = ?",
                            (room_id, successor),
                        )
                        connection.execute(
                            "UPDATE game_rooms SET owner_id = ? WHERE id = ?",
                            (successor, room_id),
                        )
                    connection.execute(
                        "UPDATE game_rooms SET state = 0, updated_at = ? WHERE id = ?",
                        (now, room_id),
                    )
                    connection.execute(
                        "UPDATE game_room_members SET ready = 0 WHERE room_id = ?", (room_id,)
                    )
                    room = cls._snapshot(connection, room_id)
        cls._sync(player, None)
        return room

    @classmethod
    def kick(cls, player, target_id):
        try:
            target_id = int(target_id)
        except (TypeError, ValueError):
            raise GameRoomError("Membro inválido") from None
        if target_id == cls._account_id(player):
            raise GameRoomError("Use sair da GameRoom")
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, _ = cls._mutable_room(player, connection, host=True)
            cls._member_for_update(connection, room_id, target_id)
            connection.execute(
                "DELETE FROM game_room_members WHERE room_id = ? AND low_id = ?",
                (room_id, target_id),
            )
            cls._set_player_room(connection, target_id, 0)
            connection.execute(
                "UPDATE game_room_members SET ready = 0 WHERE room_id = ?", (room_id,)
            )
            connection.execute(
                "UPDATE game_rooms SET state = 0, updated_at = ? WHERE id = ?",
                (cls._now(), room_id),
            )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def add_chat(cls, player, text):
        text = str(text or "")
        if not text.strip() or len(text.encode("utf-8")) > 256:
            raise GameRoomError("Mensagem de GameRoom inválida")
        now = cls._now()
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, low_id = cls._mutable_room(player, connection)
            cursor = connection.execute(
                "INSERT INTO game_room_messages(room_id, player_id, message, created_at) "
                "VALUES(?, ?, ?, ?)", (room_id, low_id, text, now)
            )
            message_id = int(cursor.lastrowid)
            room = cls._snapshot(connection, room_id)
        return room, {
            "id": message_id,
            "room_id": room["id"],
            "player_id": low_id,
            "player_name": str(getattr(player, "name", "") or ""),
            "message": text,
            "created_at": now,
        }

    @classmethod
    def chats(cls, room_id, after_id=0, limit=100):
        with DataBase._connection() as connection:
            rows = connection.execute(
                "SELECT id, room_id, player_id, message, created_at FROM game_room_messages "
                "WHERE room_id = ? AND id > ? ORDER BY id LIMIT ?",
                (int(room_id), int(after_id), min(100, max(1, int(limit)))),
            ).fetchall()
        return [
            {
                "id": int(row[0]), "room_id": int(row[1]), "player_id": int(row[2]),
                "message": str(row[3]), "created_at": int(row[4]),
            }
            for row in rows
        ]

    @classmethod
    def return_to_room(cls, player):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            membership = cls._membership(connection, low_id)
            if membership is None:
                room = None
            else:
                room_id = int(membership[0])
                connection.execute(
                    "UPDATE game_rooms SET state = 0, updated_at = ? WHERE id = ?",
                    (cls._now(), room_id),
                )
                connection.execute(
                    "UPDATE game_room_members SET ready = 0 WHERE room_id = ?",
                    (room_id,),
                )
                room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def set_friend_advertisement(cls, player, enabled):
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, _ = cls._mutable_room(player, connection, host=True)
            connection.execute(
                "UPDATE game_rooms SET advertise_friends = ?, updated_at = ? WHERE id = ?",
                (int(bool(enabled)), cls._now(), room_id),
            )
            room = cls._snapshot(connection, room_id)
        cls._sync(player, room)
        return room

    @classmethod
    def invite(cls, player, recipient_id, invite_type=0, club_only=False):
        low_id = cls._account_id(player)
        recipient_id = int(recipient_id)
        invite_type = int(invite_type)
        if recipient_id == low_id or not 0 <= invite_type <= 255:
            raise GameRoomError("Convite de GameRoom inválido")
        now = cls._now()
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, room_row, _ = cls._mutable_room(player, connection)
            if int(room_row[8]) != cls.OPEN:
                raise GameRoomError("Partida já iniciada")
            recipient = connection.execute(
                "SELECT clubID FROM players WHERE lowID = ?", (recipient_id,)
            ).fetchone()
            if recipient is None:
                raise GameRoomError("Destinatário do convite inexistente")
            if club_only:
                sender_club = connection.execute(
                    "SELECT clubID FROM players WHERE lowID = ?", (low_id,)
                ).fetchone()[0]
                if not sender_club or int(recipient[0]) != int(sender_club):
                    raise GameRoomError("O convite exige membro do mesmo clube")
            if connection.execute(
                "SELECT 1 FROM game_room_members WHERE room_id = ? AND low_id = ?",
                (room_id, recipient_id),
            ).fetchone() is not None:
                raise GameRoomError("Jogador já está na GameRoom")
            connection.execute(
                "INSERT INTO game_room_invites(room_id, sender_id, recipient_id, invite_type, created_at) "
                "VALUES(?, ?, ?, ?, ?) ON CONFLICT(room_id, recipient_id) DO UPDATE SET "
                "sender_id = excluded.sender_id, invite_type = excluded.invite_type, "
                "created_at = excluded.created_at",
                (room_id, low_id, recipient_id, invite_type, now),
            )
            room = cls._snapshot(connection, room_id)
        return room, {
            "room_id": room_id,
            "sender_id": low_id,
            "recipient_id": recipient_id,
            "invite_type": invite_type,
            "created_at": now,
        }

    @classmethod
    def clear_invite(cls, player, room_id, expected_type=None):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT sender_id, recipient_id, invite_type FROM game_room_invites "
                "WHERE room_id = ? AND (sender_id = ? OR recipient_id = ?)",
                (int(room_id), low_id, low_id),
            ).fetchone()
            if row is None:
                raise GameRoomError("Convite inexistente")
            if expected_type is not None and int(row[2]) != int(expected_type):
                raise GameRoomError("Tipo de convite divergente")
            connection.execute(
                "DELETE FROM game_room_invites WHERE room_id = ? AND recipient_id = ?",
                (int(room_id), int(row[1])),
            )
            room = cls._snapshot(connection, int(room_id))
        return room, {
            "room_id": int(room_id),
            "sender_id": int(row[0]),
            "recipient_id": int(row[1]),
            "invite_type": int(row[2]),
        }

    @classmethod
    def accept_invite(cls, player, room_id, expected_type=None):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT sender_id, invite_type FROM game_room_invites "
                "WHERE room_id = ? AND recipient_id = ?", (int(room_id), low_id)
            ).fetchone()
            if row is None:
                raise GameRoomError("Convite recebido inexistente")
            if expected_type is not None and int(row[1]) != int(expected_type):
                raise GameRoomError("Tipo de convite divergente")
            connection.execute(
                "DELETE FROM game_room_invites WHERE room_id = ? AND recipient_id = ?",
                (int(room_id), low_id),
            )
            room = cls._join_locked(connection, low_id, int(room_id), cls._now())
        cls._sync(player, room)
        return room, {
            "room_id": int(room_id),
            "sender_id": int(row[0]),
            "recipient_id": low_id,
            "invite_type": int(row[1]),
        }

    @classmethod
    def request_join(cls, player, room_id, owner_id=0):
        low_id = cls._account_id(player)
        room_id = int(room_id)
        owner_id = int(owner_id)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = cls._room_row(connection, room_id)
            if int(row[8]) != cls.OPEN:
                raise GameRoomError("Partida já iniciada")
            if owner_id > 0 and int(row[7]) != owner_id:
                raise GameRoomError("Dono da GameRoom divergente")
            if cls._membership(connection, low_id) is not None:
                raise GameRoomError("Conta já pertence a uma GameRoom")
            connection.execute(
                "INSERT INTO game_room_join_requests(room_id, player_id, created_at) "
                "VALUES(?, ?, ?) ON CONFLICT(room_id, player_id) DO UPDATE SET "
                "created_at = excluded.created_at",
                (room_id, low_id, cls._now()),
            )
            room = cls._snapshot(connection, room_id)
        return room

    @classmethod
    def cancel_join_requests(cls, player):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_ids = [int(row[0]) for row in connection.execute(
                "SELECT room_id FROM game_room_join_requests WHERE player_id = ?", (low_id,)
            ).fetchall()]
            connection.execute(
                "DELETE FROM game_room_join_requests WHERE player_id = ?", (low_id,)
            )
            rooms = [cls._snapshot(connection, room_id) for room_id in room_ids]
        return rooms

    @classmethod
    def approve_join_request(cls, player, target_id, approved):
        target_id = int(target_id)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, _ = cls._mutable_room(player, connection, host=True)
            if connection.execute(
                "SELECT 1 FROM game_room_join_requests WHERE room_id = ? AND player_id = ?",
                (room_id, target_id),
            ).fetchone() is None:
                raise GameRoomError("Solicitação de entrada inexistente")
            connection.execute(
                "DELETE FROM game_room_join_requests WHERE room_id = ? AND player_id = ?",
                (room_id, target_id),
            )
            if approved:
                room = cls._join_locked(connection, target_id, room_id, cls._now())
            else:
                room = cls._snapshot(connection, room_id)
        if int(getattr(player, "low_id", 0)) == target_id:
            cls._sync(player, room)
        return room, {"player_id": target_id, "approved": bool(approved)}

    @classmethod
    def report_chat(cls, player, message_id, reported_id):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            room_id, _, _ = cls._mutable_room(player, connection)
            message = connection.execute(
                "SELECT player_id FROM game_room_messages WHERE id = ? AND room_id = ?",
                (int(message_id), room_id),
            ).fetchone()
            if message is None or int(message[0]) != int(reported_id):
                raise GameRoomError("Mensagem denunciada inexistente")
            connection.execute(
                "INSERT OR IGNORE INTO game_room_chat_reports(room_id, message_id, "
                "reporter_id, reported_id, created_at) VALUES(?, ?, ?, ?, ?)",
                (room_id, int(message_id), low_id, int(reported_id), cls._now()),
            )
            row = connection.execute(
                "SELECT id FROM game_room_chat_reports WHERE room_id = ? "
                "AND message_id = ? AND reporter_id = ?",
                (room_id, int(message_id), low_id),
            ).fetchone()
        return int(row[0])

    @classmethod
    def set_team_chat_muted(cls, player, muted):
        low_id = cls._account_id(player)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT progression FROM players WHERE lowID = ?", (low_id,)
            ).fetchone()
            if row is None:
                raise GameRoomError("Conta não encontrada")
            progression = DataBase._decode_json(row[0], "progression")
            progression["teamChatMuted"] = bool(muted)
            connection.execute(
                "UPDATE players SET progression = ? WHERE lowID = ?",
                (json.dumps(progression, separators=(",", ":")), low_id),
            )
        player.progression = progression
        return bool(muted)
