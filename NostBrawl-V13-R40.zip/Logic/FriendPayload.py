def encode_friend_entry(writer, entry):
    writer.writeLong(entry["high_id"], entry["low_id"])
    writer.writeString(entry["name"])
    writer.writeString(entry["facebook_id"])
    writer.writeString(entry["game_center_id"])
    writer.writeString("")
    writer.writeInt(entry["state"])
    writer.writeInt(entry["trophies"])
    for _ in range(4):
        writer.writeInt(0)
    club = entry.get("club")
    writer.writeBoolean(club is not None)
    if club is not None:
        writer.writeLong(0, club["id"])
        writer.writeInt(0)
        writer.writeString(club["name"])
        writer.writeInt(0)
        writer.writeInt(0)
    writer.writeString("")
    writer.writeInt(entry["profile_icon"])
    writer.writeInt(0)


def encode_addable_friend(writer, entry):
    writer.writeInt(entry["high_id"])
    writer.writeInt(entry["low_id"])
    writer.writeString(entry["name"])
    writer.writeInt(entry["state"])
    writer.writeString(entry["facebook_id"])
    writer.writeString(entry["game_center_id"])
