import random

from Logic.Boxes import Boxes
from Logic.BoxInventory import BoxInventory
from Logic.Rewards import RewardError, RewardTransaction
from Packets.Commands.Server.LogicBoxGenerator import LogicBoxGenerator


DIRECT_COSTS = {
    5: ("brawlBoxes", 100),
    4: ("bigBoxes", 10),
    3: ("gems", 80),
    1: ("gems", 30),
}


def generate_rewards(player, box_type, rng=random, box_count=1):
    box_type = Boxes.get_box_type(box_type)
    generation_type = Boxes.get_generation_type(box_type)
    return LogicBoxGenerator.generate_rewards(
        player, generation_type, box_count=box_count, rng=rng
    )


def apply_box_opening(transaction, box_id, rng=random, box_count=1):
    box_type = Boxes.get_box_type(box_id)
    rewards = generate_rewards(
        transaction.player, box_type, rng, box_count=box_count
    )
    transaction.add_rewards(rewards)
    return box_type


def open_boxes(player, box_id, count=1, rng=random):
    try:
        box_id = int(box_id)
        count = int(count)
    except (TypeError, ValueError):
        raise RewardError("Caixa ou quantidade inválida") from None
    if box_id not in DIRECT_COSTS or count < 1:
        raise RewardError("Essa caixa não pode ser aberta diretamente")

    box_type = Boxes.get_box_type(box_id)
    transaction = RewardTransaction(player)
    stored = BoxInventory.count(player, box_type) if box_id in (3, 4, 5) else 0
    consumed = min(stored, count)
    if consumed:
        BoxInventory.consume(transaction, box_type, consumed)
    remaining = count - consumed
    currency, price = DIRECT_COSTS[box_id]
    if remaining:
        transaction.charge(currency, price * remaining)
    if consumed == count:
        source = "inventory"
    elif consumed:
        source = "mixed"
    else:
        source = "currency"

    apply_box_opening(transaction, box_type, rng, box_count=count)
    transaction.commit()
    result = transaction.result(box_type, box_type)
    result["boxCount"] = count
    result["openingSource"] = source
    result["storedBoxes"] = BoxInventory.count(player, box_type)
    return result
