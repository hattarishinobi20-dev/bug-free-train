import copy
import csv
import json
from datetime import datetime, time, timedelta
from pathlib import Path

from Database.DatabaseManager import DataBase


class EventError(ValueError):
    pass


class EventRotation:
    SLOT_POOLS = (
        ("CoinRush", (7, 8, 9, 10, 11, 12, 40, 48)),
        ("BattleRoyale", (13, 14, 15, 16, 32, 43)),
        ("BountyHunter", (0, 4, 22)),
        ("LaserBall", (24, 25, 26, 50, 51)),
        ("BattleRoyaleTeam", (34, 35, 36, 37, 38, 28)),
    )
    CLAIMS_KEY = "eventClaims"
    CLAIM_HISTORY_DAYS = 64
    PROJECT_ROOT = Path(__file__).resolve().parents[1]
    LOCATIONS_PATH = PROJECT_ROOT / "GameAssets" / "csv_logic" / "locations.csv"

    @staticmethod
    def _now(value=None):
        return value if value is not None else datetime.now()

    @staticmethod
    def _location_rows():
        with EventRotation.LOCATIONS_PATH.open(
            encoding="utf-8-sig", newline=""
        ) as source:
            rows = list(csv.DictReader(source))
        if rows and rows[0].get("Name") == "string":
            rows = rows[1:]
        return rows

    @classmethod
    def locations(cls):
        rows = cls._location_rows()
        result = []
        for location_id, row in enumerate(rows):
            disabled = str(row.get("Disabled", "")).strip().lower()
            result.append({
                "id": location_id,
                "name": row.get("Name", ""),
                "game_mode": row.get("GameMode", ""),
                "enabled": disabled not in {"1", "true", "yes"},
            })
        return result

    @classmethod
    def enabled_pools(cls):
        locations = cls.locations()
        pools = []
        for game_mode, candidates in cls.SLOT_POOLS:
            enabled = tuple(
                location_id for location_id in candidates
                if location_id < len(locations)
                and locations[location_id]["enabled"]
                and locations[location_id]["game_mode"] == game_mode
            )
            if not enabled:
                raise EventError("Slot sem mapa habilitado: " + game_mode)
            pools.append((game_mode, enabled))
        return tuple(pools)

    @classmethod
    def events(cls, now=None):
        moment = cls._now(now)
        day = moment.date().toordinal()
        result = []
        for slot, (game_mode, pool) in enumerate(cls.enabled_pools(), 1):
            map_id = pool[(day + slot - 1) % len(pool)]
            result.append({
                "slot": slot,
                "map_id": map_id,
                "game_mode": game_mode,
                "tokens": 10,
                "modifier": 0,
                "date": moment.date().isoformat(),
            })
        return result

    @classmethod
    def claimed_slots(cls, player, now=None):
        moment = cls._now(now)
        progression = getattr(player, "progression", {})
        if not isinstance(progression, dict):
            return set()
        claims = progression.get(cls.CLAIMS_KEY, {})
        if not isinstance(claims, dict):
            return set()
        values = claims.get(moment.date().isoformat(), [])
        if not isinstance(values, (list, tuple, set)):
            return set()
        result = set()
        for value in values:
            try:
                result.add(int(value))
            except (TypeError, ValueError):
                continue
        return result

    @classmethod
    def snapshot(cls, player, now=None):
        moment = cls._now(now)
        claimed = cls.claimed_slots(player, moment)
        result = []
        for event in cls.events(moment):
            item = copy.deepcopy(event)
            item["claimed"] = item["slot"] in claimed
            result.append(item)
        return result

    @classmethod
    def resolve_slot(cls, player, slot, now=None):
        try:
            slot = int(slot)
        except (TypeError, ValueError):
            raise EventError("Slot de evento inválido") from None
        events = cls.snapshot(player, now)
        if slot == 0:
            return copy.deepcopy(events[0])
        for event in events:
            if event["slot"] == slot:
                return event
        raise EventError("Slot de evento inexistente")

    @classmethod
    def seconds_to_next_day(cls, now=None):
        moment = cls._now(now)
        following = datetime.combine(moment.date() + timedelta(days=1), time.min)
        return max(0, int((following - moment).total_seconds()))

    @classmethod
    def legacy_events(cls, player=None, now=None):
        events = cls.snapshot(player, now) if player is not None else cls.events(now)
        result = {}
        for event in events:
            collected = []
            if event.get("claimed") and player is not None:
                collected = [getattr(player, "low_id", 0)]
            result[str(event["slot"] - 1)] = {
                "ID": event["map_id"],
                "Modifier": event["modifier"],
                "Tokens": event["tokens"],
                "Collected": collected,
            }
        return result

    @classmethod
    def claim(cls, player, slot, now=None):
        moment = cls._now(now)
        event = cls.resolve_slot(player, slot, moment)
        if event["claimed"]:
            return {"claimed": False, "event": event, "balance": int(getattr(player, "brawl_boxes", 0) or 0)}
        low_id = int(getattr(player, "low_id", 0) or 0)
        if low_id <= 0:
            raise EventError("Conta inválida para coleta")
        date_key = moment.date().isoformat()
        cutoff = moment.date() - timedelta(days=cls.CLAIM_HISTORY_DAYS)
        with DataBase._connection() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT brawlBoxes, progression FROM players WHERE lowID = ?",
                (low_id,),
            ).fetchone()
            if row is None:
                raise EventError("Conta não encontrada para coleta")
            try:
                progression = json.loads(row[1] or "{}")
            except (TypeError, ValueError):
                progression = {}
            if not isinstance(progression, dict):
                progression = {}
            claims = progression.get(cls.CLAIMS_KEY, {})
            if not isinstance(claims, dict):
                claims = {}
            claims = {
                key: value for key, value in claims.items()
                if cls._claim_date_after_cutoff(key, cutoff)
            }
            current = claims.get(date_key, [])
            if not isinstance(current, list):
                current = []
            current = {int(value) for value in current if str(value).lstrip("-").isdigit()}
            if event["slot"] in current:
                balance = int(row[0] or 0)
                progression[cls.CLAIMS_KEY] = claims
                return {"claimed": False, "event": event, "balance": balance}
            current.add(event["slot"])
            claims[date_key] = sorted(current)
            progression[cls.CLAIMS_KEY] = claims
            balance = int(row[0] or 0) + event["tokens"]
            cursor = connection.execute(
                "UPDATE players SET brawlBoxes = ?, progression = ? WHERE lowID = ?",
                (balance, json.dumps(progression, separators=(",", ":")), low_id),
            )
            if cursor.rowcount != 1:
                raise EventError("Falha ao persistir a coleta")
        player.brawl_boxes = balance
        player.progression = progression
        event["claimed"] = True
        return {"claimed": True, "event": event, "balance": balance}

    @staticmethod
    def _claim_date_after_cutoff(value, cutoff):
        try:
            return datetime.strptime(str(value), "%Y-%m-%d").date() >= cutoff
        except ValueError:
            return False
