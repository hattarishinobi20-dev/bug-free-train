import json
import sqlite3
import time
from contextlib import closing
from pathlib import Path

from Database.DatabaseManager import DataBase


class ClubError(ValueError):
    def __init__(self, message, code=42):
        super().__init__(message)
        self.code = code


class ClubService:
    MAX_MEMBERS = 100

    @staticmethod
    def _now():
        return int(time.time())

    @staticmethod
    def _text(value, maximum, required=False):
        text = str(value or "")
        size = len(text.encode("utf-8"))
        if required and not text.strip():
            raise ClubError("Nome do clube obrigatório")
        if size > maximum:
            raise ClubError("Texto do clube muito longo")
        return text

    @staticmethod
    def _membership(connection, player_id):
        row = connection.execute(
            "SELECT clubID, clubRole FROM players WHERE lowID = ?", (player_id,)
        ).fetchone()
        if row is None:
            raise ClubError("Conta não encontrada")
        return int(row[0]), int(row[1])

    @staticmethod
    def _set_membership(connection, player_id, club_id, role, seen=False):
        progression = None
        if seen:
            row = connection.execute(
                "SELECT progression FROM players WHERE lowID = ?", (player_id,)
            ).fetchone()
            if row is None:
                raise ClubError("Conta não encontrada")
            progression = DataBase._decode_json(row[0], "progression")
            progression["clubLastSeenMessageID"] = 0
            cursor = connection.execute(
                "UPDATE players SET clubID = ?, clubRole = ?, progression = ? WHERE lowID = ?",
                (club_id, role, json.dumps(progression), player_id),
            )
        else:
            cursor = connection.execute(
                "UPDATE players SET clubID = ?, clubRole = ? WHERE lowID = ?",
                (club_id, role, player_id),
            )
        if cursor.rowcount != 1:
            raise ClubError("Conta não encontrada")
        return progression

    @staticmethod
    def _sync_player(player, club_id, role, progression=None):
        player.club_low_id = club_id
        player.club_role = role
        if progression is not None:
            player.progression = progression

    @staticmethod
    def _add_message(connection, club_id, event, tick, player, message, role=None):
        now = ClubService._now()
        message_role = int(getattr(player, "club_role", 0) or 0) if role is None else int(role)
        position = connection.execute(
            "SELECT COUNT(*) + 1 FROM club_messages WHERE club_id = ?", (club_id,)
        ).fetchone()[0]
        cursor = connection.execute(
            "INSERT INTO club_messages "
            "(club_id, event, tick, player_id, player_name, player_role, message, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                club_id, event, tick, int(getattr(player, "low_id", 0) or 0),
                str(getattr(player, "name", "") or ""),
                message_role, str(message), now,
            ),
        )
        return {
            "id": cursor.lastrowid,
            "position": int(position),
            "event": event,
            "tick": tick,
            "player_id": int(getattr(player, "low_id", 0) or 0),
            "player_name": str(getattr(player, "name", "") or ""),
            "player_role": message_role,
            "message": str(message),
            "created_at": now,
        }

    @staticmethod
    def _club(connection, club_id):
        row = connection.execute(
            "SELECT id, name, description, region, badge_id, type, "
            "required_trophies, family_friendly, created_at FROM clubs WHERE id = ?",
            (club_id,),
        ).fetchone()
        if row is None:
            return None
        member_rows = connection.execute(
            "SELECT p.lowID, p.name, p.trophies, m.role, p.online, "
            "p.brawlersTrophiesForRank, p.profileIcon, p.namecolor, p.playerExp, m.joined_at "
            "FROM club_members m JOIN players p ON p.lowID = m.player_id "
            "WHERE m.club_id = ? ORDER BY m.joined_at ASC, p.lowID ASC",
            (club_id,),
        ).fetchall()
        members = []
        for member in member_rows:
            ranks = DataBase._decode_json(member[5], "brawlersTrophiesForRank")
            rank_values = [int(value or 0) for value in ranks.values()] if isinstance(ranks, dict) else []
            members.append({
                "low_id": int(member[0]),
                "name": member[1],
                "trophies": int(member[2]),
                "role": int(member[3]),
                "status": int(member[4]),
                "rank": max(rank_values, default=0),
                "profile_icon": int(member[6]),
                "name_color": int(member[7]),
                "experience": int(member[8]),
                "joined_at": int(member[9]),
            })
        return {
            "id": int(row[0]),
            "name": row[1],
            "description": row[2],
            "region": row[3],
            "badge_id": int(row[4]),
            "type": int(row[5]),
            "required_trophies": int(row[6]),
            "family_friendly": int(row[7]),
            "created_at": int(row[8]),
            "members": members,
            "member_ids": [member["low_id"] for member in members],
            "member_count": len(members),
            "online_count": sum(
                1 for member in members if member["status"] not in (0, 6)
            ),
            "trophies": sum(member["trophies"] for member in members),
        }

    @staticmethod
    def get_club(club_id):
        with DataBase._connection() as connection:
            return ClubService._club(connection, int(club_id))

    @staticmethod
    def get_messages(club_id):
        with DataBase._connection() as connection:
            rows = connection.execute(
                "SELECT id, event, tick, player_id, player_name, player_role, message, created_at "
                "FROM club_messages WHERE club_id = ? ORDER BY id ASC",
                (int(club_id),),
            ).fetchall()
        messages = [{
            "id": int(row[0]),
            "event": int(row[1]),
            "tick": int(row[2]),
            "player_id": int(row[3]),
            "player_name": row[4],
            "player_role": int(row[5]),
            "message": row[6],
            "created_at": int(row[7]),
        } for row in rows]
        for position, entry in enumerate(messages, 1):
            entry["position"] = position
        return messages

    @staticmethod
    def get_notifications(club_id, limit=5):
        with DataBase._connection() as connection:
            rows = connection.execute(
                "SELECT id, text, sender_id, created_at FROM club_notifications "
                "WHERE club_id = ? ORDER BY id DESC LIMIT ?",
                (int(club_id), int(limit)),
            ).fetchall()
        return [{
            "id": int(row[0]),
            "text": row[1],
            "by": int(row[2]),
            "timer": int(row[3]),
        } for row in reversed(rows)]

    @staticmethod
    def list_clubs(min_members=1, max_members=100, club_type=2, max_list_length=30, name=None):
        minimum = max(0, int(min_members))
        maximum = min(ClubService.MAX_MEMBERS, max(minimum, int(max_members)))
        type_limit = int(club_type)
        limit = (
            None
            if max_list_length is None
            else max(0, min(200, int(max_list_length)))
        )
        needle = str(name or "").casefold()
        with DataBase._connection() as connection:
            ids = [int(row[0]) for row in connection.execute("SELECT id FROM clubs")]
            clubs = [ClubService._club(connection, club_id) for club_id in ids]
        filtered = [
            club for club in clubs
            if minimum <= club["member_count"] <= maximum
            and club["type"] <= type_limit
            and (not needle or needle in club["name"].casefold() or needle == str(club["id"]))
        ]
        filtered.sort(key=lambda club: (-club["trophies"], club["id"]))
        return filtered if limit is None else filtered[:limit]

    @staticmethod
    def create(player, club_id, name, description, badge_id, club_type, required_trophies, family_friendly):
        club_id = int(club_id)
        name = ClubService._text(name, 96, required=True)
        description = ClubService._text(description, 1024)
        badge_id = int(badge_id)
        club_type = int(club_type)
        required_trophies = int(required_trophies)
        family_friendly = int(family_friendly)
        if club_id <= 0 or badge_id < 0 or club_type not in (1, 2, 3):
            raise ClubError("Configuração de clube inválida")
        if not 0 <= required_trophies <= 1000000 or family_friendly not in (0, 1):
            raise ClubError("Configuração de clube inválida")
        now = ClubService._now()
        with DataBase._connection() as connection:
            current_club, _ = ClubService._membership(connection, player.low_id)
            if current_club:
                raise ClubError("O jogador já pertence a um clube")
            if connection.execute("SELECT 1 FROM clubs WHERE id = ?", (club_id,)).fetchone():
                raise ClubError("ID de clube já utilizado")
            connection.execute(
                "INSERT INTO clubs "
                "(id, name, description, region, badge_id, type, required_trophies, family_friendly, created_at) "
                "VALUES (?, ?, ?, 'RU', ?, ?, ?, ?, ?)",
                (club_id, name, description, badge_id, club_type, required_trophies, family_friendly, now),
            )
            connection.execute(
                "INSERT INTO club_members (club_id, player_id, role, joined_at) VALUES (?, ?, 2, ?)",
                (club_id, player.low_id, now),
            )
            progression = ClubService._set_membership(connection, player.low_id, club_id, 2, seen=True)
            entry = ClubService._add_message(connection, club_id, 2, 1, player, "Club Created!", role=2)
            club = ClubService._club(connection, club_id)
        ClubService._sync_player(player, club_id, 2, progression)
        return club, entry

    @staticmethod
    def join(player, club_id):
        club_id = int(club_id)
        now = ClubService._now()
        with DataBase._connection() as connection:
            current_club, _ = ClubService._membership(connection, player.low_id)
            if current_club:
                raise ClubError("O jogador já pertence a um clube")
            club = ClubService._club(connection, club_id)
            if club is None:
                raise ClubError("Clube não encontrado")
            if club["member_count"] >= ClubService.MAX_MEMBERS:
                raise ClubError("O clube está cheio", 42)
            connection.execute(
                "INSERT INTO club_members (club_id, player_id, role, joined_at) VALUES (?, ?, 1, ?)",
                (club_id, player.low_id, now),
            )
            progression = ClubService._set_membership(connection, player.low_id, club_id, 1, seen=True)
            entry = ClubService._add_message(connection, club_id, 4, 0, player, "3", role=1)
            club = ClubService._club(connection, club_id)
        ClubService._sync_player(player, club_id, 1, progression)
        return club, entry

    @staticmethod
    def leave(player):
        with DataBase._connection() as connection:
            club_id, role = ClubService._membership(connection, player.low_id)
            if not club_id:
                raise ClubError("O jogador não pertence a um clube")
            club = ClubService._club(connection, club_id)
            if club is None:
                raise ClubError("Clube não encontrado")
            entry = ClubService._add_message(connection, club_id, 4, 0, player, "4", role=role)
            connection.execute(
                "DELETE FROM club_members WHERE club_id = ? AND player_id = ?",
                (club_id, player.low_id),
            )
            progression = ClubService._set_membership(connection, player.low_id, 0, 0, seen=True)
            remaining = ClubService._club(connection, club_id)
            if remaining["member_count"] == 0:
                connection.execute("DELETE FROM clubs WHERE id = ?", (club_id,))
                remaining_ids = []
                deleted = True
            else:
                remaining_ids = remaining["member_ids"]
                deleted = False
                if role == 2 and not any(member["role"] == 2 for member in remaining["members"]):
                    successor = remaining["members"][0]
                    connection.execute(
                        "UPDATE club_members SET role = 2 WHERE club_id = ? AND player_id = ?",
                        (club_id, successor["low_id"]),
                    )
                    connection.execute(
                        "UPDATE players SET clubRole = 2 WHERE lowID = ?",
                        (successor["low_id"],),
                    )
                    remaining = ClubService._club(connection, club_id)
        ClubService._sync_player(player, 0, 0, progression)
        return {
            "clubID": club_id,
            "club": remaining,
            "entry": entry,
            "memberIDs": remaining_ids,
            "deleted": deleted,
        }

    @staticmethod
    def edit(player, description, badge_id, club_type, required_trophies, family_friendly=None):
        description = ClubService._text(description, 1024)
        badge_id = int(badge_id)
        club_type = int(club_type)
        required_trophies = int(required_trophies)
        if badge_id < 0 or club_type not in (1, 2, 3) or not 0 <= required_trophies <= 1000000:
            raise ClubError("Configuração de clube inválida")
        with DataBase._connection() as connection:
            club_id, role = ClubService._membership(connection, player.low_id)
            if not club_id or role not in (2, 3):
                raise ClubError("Sem permissão para editar o clube")
            club = ClubService._club(connection, club_id)
            if club is None:
                raise ClubError("Clube não encontrado")
            if family_friendly is None:
                family_friendly = club["family_friendly"]
            family_friendly = int(family_friendly)
            if family_friendly not in (0, 1):
                raise ClubError("Configuração family friendly inválida")
            connection.execute(
                "UPDATE clubs SET description = ?, badge_id = ?, type = ?, "
                "required_trophies = ?, family_friendly = ? WHERE id = ?",
                (description, badge_id, club_type, required_trophies, family_friendly, club_id),
            )
            club = ClubService._club(connection, club_id)
        return club

    @staticmethod
    def promote(player, target_id, targeted_role):
        target_id = int(target_id)
        targeted_role = int(targeted_role)
        if targeted_role not in (1, 2, 3, 4) or target_id == player.low_id:
            raise ClubError("Promoção inválida")
        with DataBase._connection() as connection:
            club_id, actor_role = ClubService._membership(connection, player.low_id)
            target_club, target_role = ClubService._membership(connection, target_id)
            if not club_id or target_club != club_id:
                raise ClubError("O membro não pertence ao mesmo clube")
            if actor_role == 2:
                allowed = True
            elif actor_role == 3 and targeted_role in (1, 4):
                allowed = True
            else:
                allowed = False
            if not allowed or target_role == 2:
                raise ClubError("Sem permissão para alterar esse papel")
            connection.execute(
                "UPDATE club_members SET role = ? WHERE club_id = ? AND player_id = ?",
                (targeted_role, club_id, target_id),
            )
            connection.execute("UPDATE players SET clubRole = ? WHERE lowID = ?", (targeted_role, target_id))
            actor_new_role = actor_role
            if targeted_role == 2:
                actor_new_role = 4
                connection.execute(
                    "UPDATE club_members SET role = 4 WHERE club_id = ? AND player_id = ?",
                    (club_id, player.low_id),
                )
                connection.execute("UPDATE players SET clubRole = 4 WHERE lowID = ?", (player.low_id,))
            club = ClubService._club(connection, club_id)
        ClubService._sync_player(player, club_id, actor_new_role)
        return club, actor_new_role

    @staticmethod
    def kick(player, target_id):
        target_id = int(target_id)
        if target_id == player.low_id:
            raise ClubError("Use a saída de clube para sair")
        with DataBase._connection() as connection:
            club_id, actor_role = ClubService._membership(connection, player.low_id)
            target_club, target_role = ClubService._membership(connection, target_id)
            if not club_id or target_club != club_id or actor_role not in (2, 3, 4):
                raise ClubError("Sem permissão para expulsar esse membro")
            if target_role == 2 or (actor_role != 2 and target_role != 1):
                raise ClubError("Sem permissão para expulsar esse membro")
            entry = ClubService._add_message(connection, club_id, 4, 1, player, "1", role=actor_role)
            connection.execute(
                "DELETE FROM club_members WHERE club_id = ? AND player_id = ?",
                (club_id, target_id),
            )
            ClubService._set_membership(connection, target_id, 0, 0, seen=True)
            club = ClubService._club(connection, club_id)
        return club, entry, target_id

    @staticmethod
    def chat(player, text):
        text = ClubService._text(text, 1024, required=True)
        with DataBase._connection() as connection:
            club_id, role = ClubService._membership(connection, player.low_id)
            if not club_id or role <= 0:
                raise ClubError("O jogador não pertence a um clube")
            if ClubService._club(connection, club_id) is None:
                raise ClubError("Clube não encontrado")
            entry = ClubService._add_message(connection, club_id, 2, 0, player, text, role=role)
        return club_id, entry

    @staticmethod
    def mail(player, text):
        text = ClubService._text(text, 1024, required=True)
        now = ClubService._now()
        with DataBase._connection() as connection:
            club_id, role = ClubService._membership(connection, player.low_id)
            if not club_id or role <= 0:
                raise ClubError("O jogador não pertence a um clube")
            club = ClubService._club(connection, club_id)
            if club is None:
                raise ClubError("Clube não encontrado")
            cursor = connection.execute(
                "INSERT INTO club_notifications (club_id, text, sender_id, created_at) VALUES (?, ?, ?, ?)",
                (club_id, text, player.low_id, now),
            )
        return club, {
            "id": cursor.lastrowid,
            "text": text,
            "by": player.low_id,
            "timer": now,
        }

    @staticmethod
    def migrate_legacy(clubs_path="Database/clubs.db", chats_directory="Database/Chats"):
        clubs_path = Path(clubs_path)
        if not clubs_path.exists() or clubs_path.stat().st_size == 0:
            return {"clubs": 0, "members": 0, "messages": 0, "notifications": 0}
        with closing(sqlite3.connect(str(clubs_path))) as legacy:
            try:
                rows = legacy.execute("SELECT * FROM clubs").fetchall()
            except sqlite3.DatabaseError:
                return {"clubs": 0, "members": 0, "messages": 0, "notifications": 0}
        counts = {"clubs": 0, "members": 0, "messages": 0, "notifications": 0}
        now = ClubService._now()
        with DataBase._connection() as connection:
            for row in rows:
                if len(row) < 10:
                    continue
                club_id = int(row[0])
                cursor = connection.execute(
                    "INSERT OR IGNORE INTO clubs "
                    "(id, name, description, region, badge_id, type, required_trophies, family_friendly, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)",
                    (club_id, str(row[1]), str(row[2]), str(row[3]), int(row[4]), int(row[5]), int(row[6]), now),
                )
                counts["clubs"] += cursor.rowcount
                try:
                    members = json.loads(row[8] or "{}")
                except (TypeError, ValueError):
                    members = {}
                for player_key, data in members.items():
                    if player_key == "totalmembers":
                        continue
                    try:
                        player_id = int(player_key)
                    except (TypeError, ValueError):
                        continue
                    account = connection.execute(
                        "SELECT clubID, clubRole FROM players WHERE lowID = ?", (player_id,)
                    ).fetchone()
                    if account is None or int(account[0]) != club_id:
                        continue
                    role = int(data.get("role", account[1])) if isinstance(data, dict) else int(account[1])
                    cursor = connection.execute(
                        "INSERT OR IGNORE INTO club_members (club_id, player_id, role, joined_at) VALUES (?, ?, ?, ?)",
                        (club_id, player_id, role or 1, now),
                    )
                    counts["members"] += cursor.rowcount
                chat_path = Path(chats_directory) / f"{club_id}.db"
                if chat_path.exists() and chat_path.stat().st_size:
                    has_messages = connection.execute(
                        "SELECT 1 FROM club_messages WHERE club_id = ? LIMIT 1", (club_id,)
                    ).fetchone()
                    if not has_messages:
                        with closing(sqlite3.connect(str(chat_path))) as chat:
                            try:
                                messages = chat.execute("SELECT * FROM chats").fetchall()
                            except sqlite3.DatabaseError:
                                messages = []
                        for message in messages:
                            if len(message) < 6:
                                continue
                            connection.execute(
                                "INSERT INTO club_messages "
                                "(club_id, event, tick, player_id, player_name, player_role, message, created_at) "
                                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                (club_id, int(message[0]), int(message[1]), int(message[2]), str(message[3]), int(message[4]), str(message[5]), now),
                            )
                            counts["messages"] += 1
                try:
                    notifications = json.loads(row[9] or "{}")
                except (TypeError, ValueError):
                    notifications = {}
                has_notifications = connection.execute(
                    "SELECT 1 FROM club_notifications WHERE club_id = ? LIMIT 1", (club_id,)
                ).fetchone()
                if not has_notifications:
                    for notification in notifications.values():
                        if not isinstance(notification, dict):
                            continue
                        connection.execute(
                            "INSERT INTO club_notifications (club_id, text, sender_id, created_at) VALUES (?, ?, ?, ?)",
                            (club_id, str(notification.get("text", "")), int(notification.get("by", 0)), int(notification.get("timer", now))),
                        )
                        counts["notifications"] += 1
        return counts
