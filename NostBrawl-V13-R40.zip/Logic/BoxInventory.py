from Logic.Rewards import RewardError, RewardTransaction


class BoxInventory:
    STATE_KEY = "boxInventory"
    STATE_VERSION = 2
    BOX_TYPES = (10, 11, 12)
    TOKEN_BOXES = {
        10: ("brawl_boxes", "brawlBoxes", 100),
        12: ("big_boxes", "bigBoxes", 10),
    }

    @classmethod
    def _normalize(cls, value):
        source = value.get("boxes", {}) if isinstance(value, dict) else {}
        if not isinstance(source, dict):
            source = {}
        boxes = {}
        for box_type in cls.BOX_TYPES:
            raw = source.get(str(box_type), source.get(box_type, 0))
            try:
                count = int(raw or 0)
            except (TypeError, ValueError):
                count = 0
            boxes[str(box_type)] = max(0, count)
        return {"version": cls.STATE_VERSION, "boxes": boxes}

    @staticmethod
    def _balance(source, attribute):
        try:
            if isinstance(source, RewardTransaction):
                raw = source._value(attribute, 0)
            else:
                raw = getattr(source, attribute, 0)
            return max(0, int(raw or 0))
        except (TypeError, ValueError):
            return 0

    @classmethod
    def _state(cls, progression):
        if not isinstance(progression, dict):
            progression = {}
        return cls._normalize(progression.get(cls.STATE_KEY))

    @classmethod
    def counts(cls, player):
        state = cls._state(getattr(player, "progression", {}))
        result = dict(state["boxes"])
        result["10"] += cls._balance(player, "brawl_boxes") // 100
        result["12"] += cls._balance(player, "big_boxes") // 10
        return result

    @classmethod
    def count(cls, player, box_type):
        try:
            box_type = int(box_type)
        except (TypeError, ValueError):
            raise RewardError("Tipo de caixa inválido") from None
        if box_type not in cls.BOX_TYPES:
            raise RewardError("Tipo de caixa inválido")
        return cls.counts(player)[str(box_type)]

    @classmethod
    def _write(cls, transaction, state):
        transaction.set_progression_value(cls.STATE_KEY, state)

    @classmethod
    def _migrate_transaction(cls, transaction):
        state = cls._state(transaction.progression)
        for box_type, (attribute, column, cost) in cls.TOKEN_BOXES.items():
            key = str(box_type)
            legacy = state["boxes"][key]
            if legacy:
                balance = cls._balance(transaction, attribute)
                transaction.set_value(attribute, column, balance + legacy * cost)
                state["boxes"][key] = 0
        return state

    @classmethod
    def migrate(cls, player):
        token = getattr(player, "token", None)
        if not isinstance(token, str) or not token or token == "None":
            return False
        state = cls._state(getattr(player, "progression", {}))
        required = any(
            state["boxes"][str(box_type)] for box_type in cls.TOKEN_BOXES
        )
        if not required:
            return False
        transaction = RewardTransaction(player)
        migrated = cls._migrate_transaction(transaction)
        cls._write(transaction, migrated)
        transaction.commit()
        return True

    @staticmethod
    def _values(box_type, amount):
        try:
            box_type = int(box_type)
            amount = int(amount)
        except (TypeError, ValueError):
            raise RewardError("Quantidade de caixas inválida") from None
        if box_type not in BoxInventory.BOX_TYPES or amount < 1:
            raise RewardError("Quantidade de caixas inválida")
        return box_type, amount

    @classmethod
    def add(cls, transaction, box_type, amount):
        box_type, amount = cls._values(box_type, amount)
        state = cls._migrate_transaction(transaction)
        if box_type in cls.TOKEN_BOXES:
            attribute, column, cost = cls.TOKEN_BOXES[box_type]
            balance = cls._balance(transaction, attribute) + amount * cost
            transaction.set_value(attribute, column, balance)
            cls._write(transaction, state)
            return balance // cost
        key = str(box_type)
        state["boxes"][key] += amount
        cls._write(transaction, state)
        return state["boxes"][key]

    @classmethod
    def consume(cls, transaction, box_type, amount=1):
        box_type, amount = cls._values(box_type, amount)
        state = cls._migrate_transaction(transaction)
        if box_type in cls.TOKEN_BOXES:
            attribute, column, cost = cls.TOKEN_BOXES[box_type]
            balance = cls._balance(transaction, attribute)
            required = amount * cost
            if balance < required:
                raise RewardError("Caixas insuficientes no inventário")
            balance -= required
            transaction.set_value(attribute, column, balance)
            cls._write(transaction, state)
            return balance // cost
        key = str(box_type)
        if state["boxes"][key] < amount:
            raise RewardError("Caixas insuficientes no inventário")
        state["boxes"][key] -= amount
        cls._write(transaction, state)
        return state["boxes"][key]
