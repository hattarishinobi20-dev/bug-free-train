def read_data_reference(reader):
    csv_id = reader.read_Vint()
    if csv_id == 0:
        return 0, 0
    return csv_id, reader.read_Vint()


def read_boolean(reader):
    value = reader.read_byte()
    if value not in (0, 1):
        raise ValueError("Booleano inválido")
    return bool(value)


def ensure_end(reader, label):
    if reader.read(1):
        raise ValueError(label + " contém dados residuais")
