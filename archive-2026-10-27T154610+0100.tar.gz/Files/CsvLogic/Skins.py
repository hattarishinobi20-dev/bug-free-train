import csv

class Skins:

    def get_skins_id():

        SkinsID = []

        with open('GameAssets/csv_logic/skins.csv') as char_file:
            csv_reader = csv.reader(char_file, delimiter=',')
            skins = list(csv_reader)

        skins = skins[2:] 
        for index, row in enumerate(skins):
            if row[2] != "" and index <= 49:
                SkinsID.append(index)
                
        return SkinsID
    def getBrawler(skinID):
        with open('GameAssets/csv_logic/skins.csv') as char_file:
            csv_reader = csv.reader(char_file, delimiter=',')
            skins = list(csv_reader)

        skins = skins[2:] 

        if skinID >= len(skins) or skinID > 49:
            return 0

        target = skins[skinID][2]
        with open('GameAssets/csv_logic/characters.csv') as card_file:
            csv_reader = csv.reader(card_file, delimiter=',')
            cards = list(csv_reader)
        cards = cards[2:]
        for index, row in enumerate(cards):
            if row[0] == target:
                return index
        return 0
    
    def getNonDefaultSkins():
        defaultSkins = []
        nonDefaultSkins = []
        with open('GameAssets/csv_logic/characters.csv') as card_file:
            csv_reader = csv.reader(card_file, delimiter=',')
            cards = list(csv_reader)
        cards = cards[2:]
        for index, row in enumerate(cards):
            defaultSkins.append(row[22])
        with open('GameAssets/csv_logic/skins.csv') as char_file:
            csv_reader = csv.reader(char_file, delimiter=',')
            skins = list(csv_reader)

        skins = skins[2:] 
        for index, row in enumerate(skins):
            if row[0] not in defaultSkins and row[2] != "" and index <= 49:
                nonDefaultSkins.append(index)
        return nonDefaultSkins
    def getSkinPrice(skinID):
        with open('GameAssets/csv_logic/skins.csv') as char_file:
            csv_reader = csv.reader(char_file, delimiter=',')
            skins = list(csv_reader)

        skins = skins[2:] 

        if skinID >= len(skins):
            return 0

        price = skins[skinID][4]
        
        return price
    
    def getIsDefaultSkin(skinID):
        defaultSkins = []
        with open('GameAssets/csv_logic/characters.csv') as card_file:
            csv_reader = csv.reader(card_file, delimiter=',')
            cards = list(csv_reader)
        cards = cards[2:]
        for index, row in enumerate(cards):
            defaultSkins.append(row[22])
        with open('GameAssets/csv_logic/skins.csv') as char_file:
            csv_reader = csv.reader(char_file, delimiter=',')
            skins = list(csv_reader)

        skins = skins[2:] 

        if skinID >= len(skins):
            return 0

        name = skins[skinID][0]
        if name in defaultSkins:
            return True
        return False


