from Packets.Messages.Server.Login.ServerHelloMessage import ServerHelloMessage
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.PiranhaMessage import PiranhaMessage

class ClientHelloMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes, serverStates):
        super().__init__(initial_bytes)
        self.player = player
        self.serverStates = serverStates
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["Protocol"] = self.readInt()
        self.fields["KeyVersion"] = self.readInt()
        self.fields["MajorVersion"] = self.readInt()
        self.fields["MinorVersion"] = self.readInt()
        self.fields["Build"] = self.readInt()
        self.fields["ContentHash"] = self.readString()
        self.fields["DeviceType"] = self.readInt()
        self.fields["AppStore"] = self.readInt()


    def process(self, crypter):
        print(f"[HELLO] {getattr(self.player, 'last_ip', '?')} cliente v{self.fields.get('MajorVersion')}.{self.fields.get('MinorVersion')}.{self.fields.get('Build')}")
        ServerHelloMessage(self.client, self.player).send(crypter)
        maintenance = bool(getattr(self.serverStates, "maintenance", False) or getattr(self.player, "maintenance", False))
        try:
            with open('config.json', 'r') as config_file:
                settings = json.load(config_file)
            maintenance = bool(settings.get("Maintenance", maintenance))
            try:
                self.player.maintenance_time = int(settings.get("MaintenanceTime", self.player.maintenance_time))
            except (TypeError, ValueError):
                pass
        except Exception:
            pass
        if maintenance:
            self.player.err_code = 10
            LoginFailedMessage(self.client, self.player, "", 10).send(crypter)
            self.player._close_after_packet = True
        elif self.fields["MajorVersion"] != 11:
            print(f"[HELLO] {getattr(self.player, 'last_ip', '?')} REJEITADO: cliente v{self.fields.get('MajorVersion')} (servidor = v11) - APK incompativel")
            LoginFailedMessage(self.client, self.player, "", self.player.err_code).send(crypter)
            self.player._close_after_packet = True
        else:
            pass