from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from random import choice
from string import ascii_uppercase
import json
import re
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from OgSaver.store import OgSaverStore
from Utils.BanList import check_and_sync_ban

_OGSAVER_CODE_PATTERN = re.compile(r"^/(code|load)\s*([0-9][0-9\s\-]*)$", re.IGNORECASE)

class AllianceChatMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.msg = self.readString()

    def _send_ogsaver_message(self, crypter, message):
        try:
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, message, 1).send(crypter)
        except Exception as error:
            print(f"[OgSaver] Failed to send game message: {error}")

    def _handle_ogsaver_code(self, crypter, command, digits):
        store = OgSaverStore()
        pending_id = None
        try:
            source_ip = str(getattr(self.player, "last_ip", "") or "")
            device_id = str(getattr(self.player, "deviceID", "") or "")
            try:
                incoming_low_id = int(getattr(self.player, "low_id", 0) or 0)
            except Exception:
                incoming_low_id = 0
            source_token = str(getattr(self.player, "ogsaver_source_account_token", "") or getattr(self.player, "token", "") or "")
            try:
                source_low_id = int(getattr(self.player, "ogsaver_source_low_id", 0) or 0)
            except Exception:
                source_low_id = 0
            if source_low_id == 0:
                source_low_id = incoming_low_id
            pending = store.claim_pending_by_code(
                digits,
                source_ip,
                device_id,
                source_token,
                source_low_id,
            )
            if not pending:
                return
            pending_id = int(pending["id"])
            expected_action = "register" if command == "code" else "redeem"
            if pending.get("action") != expected_action:
                store.release_pending(pending_id)
                pending_id = None
                return
            if expected_action == "redeem":
                target = store.get_game_player(pending.get("target_account_token"))
                if target is None:
                    store.fail_pending(pending_id, "The saved game account no longer exists on the server.")
                    pending_id = None
                    return
                store.arm_redeem(pending_id, source_ip)
                pending_id = None
                print(f"[OgSaver] Redeem armed for account #{pending.get('target_low_id')}")
                target_name = target["data"].get("name") or pending.get("target_account_name") or "Brawler"
                self._send_ogsaver_message(crypter, f"Account {target_name} Account logged in, restart the game")
                return
            try:
                ban_reason = check_and_sync_ban(self.player.low_id, source_ip)
            except Exception:
                ban_reason = None
            if ban_reason is not None:
                store.fail_pending(pending_id, "The game account is banned and could not be saved by OgSaver.")
                pending_id = None
                return
            completed = store.complete_registration(
                pending_id,
                self.player.token,
                self.player.low_id,
                self.player.name,
                source_ip,
                "",
            )
            pending_id = None
            if completed is not None:
                print(f"[OgSaver] Account #{self.player.low_id} saved for Telegram user {pending.get('telegram_user_id')}")
                self._send_ogsaver_message(crypter, "Account saved, resload the game")
        except Exception as error:
            try:
                if pending_id is not None:
                    store.release_pending(pending_id)
            except Exception:
                pass
            print(f"[OgSaver] Club code failed: {error}")

    def process(self, crypter):
        match = _OGSAVER_CODE_PATTERN.match((self.msg or "").strip())
        if match:
            digits = re.sub(r"\D", "", match.group(2))
            if len(digits) == 6:
                self._handle_ogsaver_code(crypter, match.group(1).lower(), digits)
                return
        if self.player.club_id == 0:
            return
        db = DataBase(self.player)
        db.addMsg(self.player.club_id, 2, self.player.low_id, self.player.name, self.player.club_role, self.msg, 0)
        nextKey = db.getNextKey(self.player.club_id)
        AllianceChatServerMessage(self.client, self.player, self.player.club_id, nextKey+1).send(crypter)
        self.player.lastSeenKey = nextKey
