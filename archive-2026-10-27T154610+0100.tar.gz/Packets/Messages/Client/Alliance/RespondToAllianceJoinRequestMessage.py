from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.AllianceEventMessage import AllianceEventMessage
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from random import choice
from string import ascii_uppercase
import json
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage

class RespondToAllianceJoinRequestMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["messageID"] = self.readLong()
        self.fields["isAccepted"] = self.readBoolean()

    def process(self, crypter):
        db = DataBase(self.player)
        newEvent = 2 if self.fields["isAccepted"] else 0
        db.replaceMessageValue(self.fields["messageID"][1], "Event", newEvent)
        #db.addMsg(self.fields["clubID"][1], 3, self.player.low_id, self.player.name, self.player.club_role, self.fields["promotionMessage"], 0)
        if self.fields["isAccepted"]:
            clubMessages = db.loadClubMessages(self.player.club_id)
            playertoken = ""
            if clubMessages != None:
              for index in range(len(clubMessages["info"]["messages"])):
                  if clubMessages["info"]["messages"][str(index)]["Tick"] == self.fields["messageID"][1]:
                      playertoken = db.getTokenByLowId(clubMessages["info"]["messages"][str(index)]["PlayerID"])
                      playerId = clubMessages["info"]["messages"][str(index)]["PlayerID"]
            playersData = db.getSpecifiedPlayers([playertoken]) if playertoken else []
            if not playersData:
                return "kek"
            playerData = playersData[0]
            if playerData["club_id"] != 0:
                AllianceEventMessage(self.client, self.player, 92).send(crypter)
                return "aa"
            AllianceEventMessage(self.client, self.player, 90).send(crypter)
            db.replaceOtherValue("club_id", self.player.club_id, playertoken)
            db.replaceOtherValue("club_role", 1, playertoken)
            db.addMember(self.player.club_id, playertoken, 1)
            db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, 0, "", 3, playerId)
        else:
            AllianceEventMessage(self.client, self.player, 91).send(crypter)
        