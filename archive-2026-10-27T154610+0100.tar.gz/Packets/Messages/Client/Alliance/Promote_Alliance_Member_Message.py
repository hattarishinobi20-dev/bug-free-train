from Packets.Messages.Server.Alliance.Events.AllianceRoleChangedOKMessage import AllianceRoleChangedOKMessage
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Alliance.AllianceEventMessage import AllianceEventMessage
from Packets.PiranhaMessage import PiranhaMessage


class Promote_Alliance_Member_Message(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.TargetHighID = self.readInt()
        self.TargetLowID = self.readInt()
        self.TargetedRole = self.readVInt()

    def process(self, crypter):
        db = DataBase(self.player)
        if self.TargetedRole not in [0, 1, 2, 3, 4]:
            return "kek"
        if self.player.club_role not in [2, 4]:
            return "kek"
        if self.player.club_role == 3 and self.TargetedRole == (4 or 2) or self.player.club_role == 4 and self.TargetedRole == 2:
            return "kek"
        # Replacing value
        playertoken = db.getTokenByLowId(self.TargetLowID)
        playersData = db.getSpecifiedPlayers([playertoken])
        playerData = playersData[0]
        db.replaceOtherValue('club_role', self.TargetedRole, playertoken)
        db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, 0, "", 5, self.TargetLowID, playerData["name"])
        if self.TargetedRole == 2:
            self.player.club_role = 4
            db.replaceValue("club_role", self.player.club_role)
            db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, 0, "", 6, self.player.low_id, self.player.name)
        # Sending confirmation and updated data
        AllianceEventMessage(self.client, self.player, 81).send(crypter)