from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json

from Logic.Player import Players
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.Events.AllianceLeaveOkMessage import AllianceLeaveOkMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage

from Packets.PiranhaMessage import PiranhaMessage


class Leave_Message(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, crypter):
        db = DataBase(self.player)
        # Removing member 
        club =  db.loadClub(self.player.club_id)

        if club is not None and len(club["info"]["memberCount"]) == 1:
            db.addMember(self.player.club_id, self.player.token, 0)

        else:
            db.addMember(self.player.club_id, self.player.token, 2)
            db.addMsg(self.player.club_id, 4, self.player.low_id, self.player.name, self.player.club_role, "", 4, self.player.low_id, self.player.name)

        # Info
        
        AllianceLeaveOkMessage(self.client, self.player).send(crypter)
        MyAllianceMessage(self.client, self.player, 0).send(crypter)
        #AllianceDataMessage(self.client, self.player, 0, self.player.club_id).send(crypter)
        self.player.club_id = 0
        db.replaceValue('club_id', self.player.club_id)
        self.player.club_id = 0
        db.replaceValue('club_role', 0)
        self.player.club_role = 0