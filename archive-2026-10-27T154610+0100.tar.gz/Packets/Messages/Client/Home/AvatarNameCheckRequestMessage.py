from Packets.Messages.Server.Home.AvatarNameCheckResponseMessage import AvatarNameCheckResponseMessage
from random import choice
from string import ascii_uppercase
import json
from Packets.PiranhaMessage import PiranhaMessage


class AvatarNameCheckRequestMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.name = self.readString()

    def process(self, crypter):
        AvatarNameCheckResponseMessage(self.client, self.player).send(crypter)