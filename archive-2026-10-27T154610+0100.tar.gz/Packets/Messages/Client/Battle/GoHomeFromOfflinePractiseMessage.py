from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage
from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage


class GoHomeFromOfflinePractiseMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, crypter):
        if self.player.tutorialState < 2:
            self.player.tutorialState += 1
        db = DataBase(self.player)
        db.replaceValue('tutorialState', self.player.tutorialState)
        OwnHomeDataMessage(self.client, self.player).send(crypter)
        if not self.player.settings.get("EnableSocialPackets", True):
            return
        try:
            if self.player.room_id > 0 and db.loadGameroom():
                self.player.lastSeenGameroomKey = db.getNextGameroomKey(self.player.room_id)
                TeamGameroomDataMessage(self.client, self.player).send(crypter)
                TeamStreamMessage(self.client, self.player, self.player.room_id).send(crypter)
            elif self.player.room_id > 0:
                self.player.room_id = 0
        except Exception:
            pass