from Database.DatabaseManager import DataBase

from Packets.Messages.Server.Gameroom.TeamLeftMessage import TeamLeftMessage

from Utils.Reader import BSMessageReader


class TeamLeaveMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self, crypter):
        TeamLeftMessage(self.client, self.player).send(crypter)
        if self.player.room_id == 0:
            return
        db = DataBase(self.player)
        room_id = self.player.room_id
        db.addGameroomMsg(room_id, 4, self.player.low_id, self.player.name, "", 103, self.player.low_id, self.player.name)
        db.removeGameroomPlayer(self.player.low_id, room_id, self.player.token)
        self.player.room_id = 0
