from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase
from random import choice
from string import ascii_uppercase
import json
from Packets.Messages.Server.Alliance.AllianceEventMessage import AllianceEventMessage
from Logic.Player import Players
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.Events.AllianceLeaveOkMessage import AllianceLeaveOkMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.Alliance_Data_Message import AllianceDataMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage

from Packets.PiranhaMessage import PiranhaMessage


class TeamKickMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        self.fields["playerID"] = self.readVLong()


    def process(self, crypter):
        db = DataBase(self.player)
        gameroomInfo = db.loadGameroom()
        if self.player.room_id == 0 or not gameroomInfo:
            self.player.room_id = 0
            return
        players = gameroomInfo.get("players", {})
        own_info = players.get(str(self.player.low_id)) or {}
        if not own_info.get("host"):
            TeamGameroomDataMessage(self.client, self.player).send(crypter)
            return
        target = self.fields.get("playerID")
        target_low_id = target[1] if isinstance(target, (list, tuple)) and len(target) > 1 else target
        playertoken = db.getTokenByLowId(target_low_id)
        if playertoken is None or str(target_low_id) not in players:
            TeamGameroomDataMessage(self.client, self.player).send(crypter)
            return
        db.removeGameroomPlayer(target_low_id, self.player.room_id, playertoken)
        db.addGameroomMsg(self.player.room_id, 4, self.player.low_id, self.player.name, "", 104, target_low_id, self.player.name)

        db.replaceOtherValue('room_id', 0, playertoken)
        TeamGameroomDataMessage(self.client, self.player).send(crypter)
