from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots

from Packets.PiranhaMessage import PiranhaMessage

class TeamSetRankedLocationMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.player.always8 = self.readVInt()
        self.player.slot = self.readVInt()
        self.valid_slot = isinstance(self.player.slot, int) and 1 <= self.player.slot <= len(EventSlots.maps)
        if self.valid_slot:
            self.player.map_id = EventSlots.maps[self.player.slot - 1]["ID"]
        self.roomType = 0

    def process(self, crypter):
        db = DataBase(self.player)
        if self.player.room_id == 0 or not db.loadGameroom():
            self.player.room_id = 0
            return
        if not getattr(self, "valid_slot", False):
            TeamGameroomDataMessage(self.client, self.player).send(crypter)
            return
        db.updateGameroomInfo(self.player.map_id, self.player.room_id, "map_id")
        db.updateGameroomInfo(self.roomType, self.player.room_id, "room_type")
        TeamGameroomDataMessage(self.client, self.player).send(crypter)
