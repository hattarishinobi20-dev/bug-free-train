from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Logic.EventSlots import EventSlots
from Database.DatabaseManager import DataBase
import random
from random import choice
from string import ascii_uppercase
import json
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Messages.Server.Gameroom.TeamStreamMessage import TeamStreamMessage
import time

class TeamCreateMessage(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.mapSlot = self.readVInt()
        self.player.map_id = self.readVInt()
        self.roomType = self.readVInt()
        self.mapID = self.readVInt()

    def process(self, crypter):
        db = DataBase(self.player)
        if self.player.room_id != 0:
            if db.loadGameroom():
                TeamGameroomDataMessage(self.client, self.player).send(crypter)
                return
            self.player.room_id = 0
        if self.player.map_id > 100:
            self.player.map_id = 0
        created = False
        for attempt in range(5):
            db.getRoomId()
            try:
                db.createGameroom(self.roomType, {"info": {"roomID": self.player.room_id, "messages": { "0": {"EventType": 4, "Event": 101, "Tick": 1, "PlayerID": self.player.low_id, "PlayerName": self.player.name, "Message": "", "promotedTeam": 0, "TimeStamp": time.time(), "targetID": self.player.low_id, "targetName": self.player.name}}}})
                created = True
                break
            except Exception:
                try:
                    db.connection.rollback()
                except Exception:
                    pass
        if not created:
            self.player.room_id = 0
            return
        db.replaceValue('room_id', self.player.room_id)
        self.player.lastSeenGameroomKey = db.getNextGameroomKey(self.player.room_id)
        TeamGameroomDataMessage(self.client, self.player).send(crypter)
        TeamStreamMessage(self.client, self.player, self.player.room_id).send(crypter)
