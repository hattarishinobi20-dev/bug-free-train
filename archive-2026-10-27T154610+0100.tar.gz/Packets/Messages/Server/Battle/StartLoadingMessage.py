from Utils.Writer import Writer


class StartLoadingMessage(Writer):
    def __init__(self, client, player, device=None, battle=None):
        super().__init__(client)
        self.id = 20559
        self.device = device
        self.client = client
        self.player = player
        self.battle = battle

    def _default_battle(self):
        players = [{
            "high_id": getattr(self.player, "high_id", 0),
            "low_id": getattr(self.player, "low_id", 0),
            "name": getattr(self.player, "name", "Brawler"),
            "index": 0, "team": 0,
            "brawler": getattr(self.player, "brawler_id", 0),
            "skin": 0,
        }]
        for i in range(1, 6):
            players.append({
                "high_id": 0, "low_id": 10000 + i, "name": f"Bot {i}",
                "index": i, "team": 0 if i < 3 else 1, "brawler": 0, "skin": 0,
            })
        return {"location": 7, "players": players}

    def encode(self):
        battle = self.battle or self._default_battle()
        players = battle["players"]
        location = int(battle.get("location", 7))

        self.writeInt(len(players))  # Player Count for the GameMode
        self.writeInt(0)
        self.writeInt(0)

        self.writeInt(len(players))  # Players Count
        for p in players:
            self.writeInt(int(p.get("high_id", 0)))   # Player High ID
            self.writeInt(int(p.get("low_id", 0)))    # Player Low ID
            self.writeString(p.get("name", "Bot"))    # Player Name
            self.writeVint(int(p.get("index", 0)))    # Player Index
            self.writeVint(int(p.get("team", 0)))     # Player Team
            self.writeVint(0)
            self.writeInt(30)
            self.writeScId(16, int(p.get("brawler", 0)))  # Selected Brawler
            self.writeScId(29, int(p.get("skin", 0)))     # Selected Skin
            self.writeByte(0)

        leaders = []
        seen_teams = set()
        for p in sorted(players, key=lambda x: x.get("index", 0)):
            team = p.get("team", 0)
            if team not in seen_teams:
                seen_teams.add(team)
                leaders.append(p)
        self.writeInt(len(leaders))
        for p in leaders:
            self.writeInt(int(p.get("high_id", 0)))
            self.writeInt(int(p.get("low_id", 0)))

        self.writeInt(1000)
        self.writeVint(1)
        self.writeVint(1)
        self.writeVint(1)
        self.writeByte(1)
        self.writeScId(15, location)
