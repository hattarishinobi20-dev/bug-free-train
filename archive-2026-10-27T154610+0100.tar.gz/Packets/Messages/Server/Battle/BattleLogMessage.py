from Utils.Writer2 import Writer
from Entries.BattleLogEntry import BattleLogEntry

class BattleLogMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23458
        self.player = player

    def encode(self):
        self.writeBoolean(True) # disable = death

        self.writeVInt(0) # Count
        for battle in range(0):
            BattleLogEntry.encode(self, battle)
        #self.writeVInt(1)
