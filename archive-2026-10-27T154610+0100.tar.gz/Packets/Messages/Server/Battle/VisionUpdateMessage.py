from Utils.Writer import Writer
from Utils.BitStream import *
from Logic.Battles.Objects.LogicGameObjectManager import LogicGameObjectManager
from Logic.GameModes import *
from Logic.Battle import Battle

class VisionUpdateMessage(Writer):
    def __init__(self, client, player, device, ticks, low_id, mapIndex):
        super().__init__(client)
        self.client = client
        self.id = 24109
        self.device = device
        self.player = player
        self.tick = ticks
        self.low_id = low_id
        self.mapIndex = mapIndex

    def encode(self):
        if Battle.gems[self.player.MapIndex - 1][0] != 0 or Battle.gems[self.player.MapIndex - 1][1] != 0:
            self.tick += 900
        self.writeVint(self.tick) # Battle Ticks
        self.writeVint(0) # bad wifi ticks
        self.writeVint(1)
        battle = BitStream()
        #GemGrab(battle, self.low_id, self.player.playermmindex, self.client, self.player, self.tick, self.mapIndex)
        LogicGameObjectManager.encode(battle, self.low_id, self.player.playermmindex, self.client, self.player, self.tick, self.mapIndex, 32, 16, 5)
        #AttackDefend(battle, self.low_id, self.player.playermmindex, self.client, self.player, self.tick, self.mapIndex)
        buf = bytes(battle.buffer)
        self.writeBytes(buf, len(buf))
        #self.buffer += buf
        #self.writeBytes(buf, len(buf))
        #print("VisionUpdateMessage sent.")
