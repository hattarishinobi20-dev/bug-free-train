from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class MatchMakingStatusMessage(Writer):
    def __init__(self, client, player, fields, found=1, max_players=11):
        super().__init__(client)
        self.id = 20405
        self.fields = fields
        self.player = player
        self.found = found
        self.max_players = max_players


    def encode(self):
        db = DataBase(self.player)
        #try:
        #    db.joinMMPool(self.fields["MapIndex"],self.fields["Brawler"])
        #except:
        #    db.createMMPool(self.fields["MapIndex"],self.fields["Brawler"])
        #db.loadMMPool(self.fields["MapIndex"])
        #self.player.MapIndex = self.fields["MapIndex"]
        self.writeInt(0) # Matchmake Timer
        self.writeInt(self.found)
        self.writeInt(self.max_players) # max players
        self.writeInt(0)
        self.writeInt(0)