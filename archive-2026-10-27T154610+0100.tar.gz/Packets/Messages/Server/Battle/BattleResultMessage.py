from Utils.Writer2 import Writer
from Database.DatabaseManager import DataBase
from Logic.Milestones import Milestones
from Logic.BattleRewardsManager import BattleRewardsManager
from Packets.PiranhaMessage import PiranhaMessage
class BattleResultMessage(Writer):

    def __init__(self, client, player, fields):
        super().__init__(client)
        self.id = 23456
        self.player = player
        self.fields = fields
        self.db = DataBase(self.player)
        self.milestones = Milestones()

    def encode(self):
        db = DataBase(self.player)
        self.writeVInt(self.fields["GameMode"]) # battle end type
        self.writeVInt(self.fields["Rank"] if self.fields["GameMode"] in [2, 5] else self.fields["Victory"]) # battle result
        rewards = BattleRewardsManager(self.player,self.db)
        
        battleEndRewards = rewards.process_rewards(self.fields)
        self.writeVInt(battleEndRewards["tokens_gain"]) # Tokens Gained
        self.writeVInt(battleEndRewards["trophies_gain"]) # Trophies Result
        self.writeVInt(battleEndRewards["doubled_tokens"]) # Doubled Tokens
        self.writeVInt(battleEndRewards["remaining_tokens"]) # Token Doubler Remaining
        self.writeVInt(0) # game lenght in second
        
        self.writeBoolean(battleEndRewards["hasStarKey"]) # star key got
        self.writeBoolean(False) #has reached tokens limit
        self.writeBoolean(False) # battle keys exhausted
        self.writeBoolean(self.player.tutorialState == 1) # is tutorial battle
        self.writeBoolean(self.fields["isInRealGame"]) # is in real game
        self.writeBoolean(self.player.tutorialState == 1) # another is tutorial battle check
        
        #self.writeVInt(self.fields["Result"]) # Battle Result Info and Stuff
        heroes = self.fields.get("Heroes") or []
        local_team = 0
        for hero in heroes:
            if hero.get("IsPlayer"):
                local_team = hero.get("Team", 0)
                break
        if heroes and not any(hero.get("IsPlayer") for hero in heroes):
            local_team = heroes[0].get("Team", 0)
        self.writeVInt(len(heroes)) #Battle End Screen Players
        for heroe in heroes:
            self.writeString(heroe["PlayerName"])
            self.writeBoolean(heroe["IsPlayer"])
            self.writeBoolean(heroe["Team"] != local_team)
            self.writeBoolean(heroe["IsPlayer"]) # is star player actually
            self.writeDataReference(heroe["Brawler"]["ID"][0], heroe["Brawler"]["ID"][1])
            _skin = heroe["Brawler"]["SkinID"]
            if _skin and _skin[0] == 29 and 0 <= _skin[1] <= 49:
                self.writeDataReference(29, _skin[1])
            else:
                self.writeDataReference(0, 0)
            self.writeVInt(heroe["Brawler"]["Trophies"])
            self.writeVInt(heroe["Brawler"]["PowerLevel"])
            self.writeBoolean(heroe["IsPlayer"])
            if heroe["IsPlayer"]:
                self.writeLong(0, heroe["LowID"])

        # Experience Array
        self.writeVInt(len(battleEndRewards["exp_rewards_array"])) # Count
        for key, reward in battleEndRewards["exp_rewards_array"].items():
            self.writeVInt(key) # id
            self.writeVInt(reward) # gained amount

        # Rank Up and Level Up Bonus Array
        self.writeVint(0) # Count

        # Trophies and Experience Bars Array
        self.writeVint(2) # Count
        self.writeVint(1) # Ranks Milestone ID
        self.writeVint(battleEndRewards["brawler_trophies"]) # Brawler Trophies Bar
        self.writeVint(battleEndRewards["brawler_trophies_for_rank"]) # Brawler Trophies for Rank
        self.writeVint(5) # Experience Milestone ID
        self.writeVint(self.player.player_experience - battleEndRewards["experience"] -battleEndRewards["star_player_exp"]) # Total Experience Bar
        self.writeVint(self.player.player_experience - battleEndRewards["experience"] -battleEndRewards["star_player_exp"]) # ???
        self.player.keysReward = battleEndRewards["tokens_gain"]
        self.player.trophiesReward = battleEndRewards["trophies_gain"]
        
        self.writeBoolean(True)  # milestones boolean
        
        self.writeVint(621) # Count
# MILESTONES
        self.writeHexa(self.milestones.hexa, len(self.milestones.hexa)) 
# MIELSTONES END
        self.writeVInt(0)
        self.writeBoolean(False)  # Play Again