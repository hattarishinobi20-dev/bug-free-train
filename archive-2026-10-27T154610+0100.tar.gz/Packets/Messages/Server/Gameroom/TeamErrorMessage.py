from Utils.Writer import Writer


class TeamErrorMessage(Writer):

    def __init__(self, client, player, error):
        super().__init__(client)
        self.id = 24129
        self.error = error
        self.player = player

    def encode(self):
        self.writeVInt(self.error)
        self.writeVInt(self.error) # just why...
