from Utils.Writer2 import Writer
from Database.DatabaseManager import DataBase
from Logic.EventData import EventData
from Logic.LogicGamePlayUtil import LogicGamePlayUtil

class TeamGameroomDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24124
        self.player = player
        self.playerCount = 1
        self.playersData = {}

    def encode(self):
            db = DataBase(self.player)
            gameroomInfo = db.loadGameroom() or {}
            if not isinstance(gameroomInfo, dict):
                gameroomInfo = {}
            players = gameroomInfo.get("players", {})
            if not isinstance(players, dict):
                players = {}
            room_type = gameroomInfo.get("room_type", 0)
            map_id = gameroomInfo.get("map_id", getattr(self.player, "map_id", 7) or 7)
            self.writeVInt(room_type)  # Mode
            self.writeBoolean(room_type == 1) # practice with bots
            gameModeVariation = EventData.getGameModeVariation(self, map_id)
            playerCountWithGameMode = LogicGamePlayUtil.getPlayerCountWithGameMode(gameModeVariation)
            self.writeVInt(playerCountWithGameMode) # max players
            self.writeLong(0, self.player.room_id)
            self.writeVInt(0)
            self.writeBoolean(gameroomInfo.get("advertiseToBand", False))
            self.writeBoolean(gameroomInfo.get("advertiseToFriends", False))
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeDataReference(15, map_id)
            self.playerCount = len(players)
            self.writeVint(self.playerCount)
            for player, values in players.items():
                if not isinstance(values, dict):
                    values = {}
                playerToken = db.getTokenByLowId(values.get("low_id", 0))
                specifiedPlayers = db.getSpecifiedPlayers([playerToken]) if playerToken else []
                playersData = specifiedPlayers[0] if specifiedPlayers else {}
                self.writeBoolean(values.get("host", False))  # Gameroom owner boolean
                self.writeLong(0, values.get("low_id", 0))  # player ID
                self.writeString(values.get("name", ""))  # Player name
                friends = self.player.friends if isinstance(self.player.friends, dict) else {}
                self.writeVint(friends.get(playerToken, 0))  # friend list state
                self.writeDataReference(16, values.get("brawler_id", 0))  # Brawler ID
                self.writeDataReference(0, 1) #skin
                brawler_id = str(values.get("brawler_id", 0))
                brawlerData = playersData.get("unlocked_brawlers", {}).get(brawler_id, {})
                self.writeVint(brawlerData.get("Trophies", 0))  # Trophies
                self.writeVint(brawlerData.get("HighestTrophies", 0))  # Highest trophies
                self.writeVint(brawlerData.get("PowerLevel", 0))  # Power level
                self.writeVint(values.get("status", 0) if playersData.get("player_status", 0) != 0 else 0)  # Player state
                self.writeBoolean(values.get("ready", False))  # Is ready
                self.writeVint(values.get("team", 0))  # Team: 0 = Blue, 1 = Red
            self.writeVint(0) # array
