from Database.DatabaseManager import DataBase
import json
from Utils.Writer2 import Writer
from Entries.StreamEntryFactory import StreamEntryFactory

class TeamStreamMessage(Writer):

    def __init__(self, client, player, roomLowID):
        super().__init__(client)
        self.id = 24131
        self.player = player
        self.roomLowID = roomLowID

    def encode(self):
     self.writeLogicLong(0, self.player.room_id)
     db = DataBase(self.player)
     messages = {}
     if self.roomLowID != 0:
        roomMessages = db.loadRoomMessages(self.roomLowID)
        if roomMessages != None:
           messages = roomMessages.get("info", {}).get("messages", {})
        self.writeVInt(len(messages))  # Message count

        for messageKey in sorted(messages.keys(), key=lambda k: int(k) if str(k).isdigit() else 0):
            message = messages[messageKey]
            self.writeVInt(message["EventType"])
            StreamEntryFactory.createStreamEntryByType(self, message)
     else:
        self.writeVInt(0)  # No messages
