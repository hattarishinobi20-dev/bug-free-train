from Utils.Writer2 import Writer
import json
from Entries.StreamEntryFactory import StreamEntryFactory
from Database.DatabaseManager import DataBase

class TeamChatServerMessage(Writer):

    def __init__(self, client, player, roomLowID, tick):
        super().__init__(client)
        self.tick = tick
        self.roomLowID = roomLowID
        self.id = 24131
        self.player = player

    def encode(self):
        db = DataBase(self.player)
        found = None
        if self.roomLowID != 0:
            roomMessages = db.loadRoomMessages(self.roomLowID)
            messages = {}
            if roomMessages != None:
                messages = roomMessages.get("info", {}).get("messages", {})
            for messageKey in sorted(messages.keys(), key=lambda k: int(k) if str(k).isdigit() else 0):
                message = messages[messageKey]
                if message.get("Tick") == self.tick - 1:
                    found = message
                    break
            self.writeLogicLong(0, self.roomLowID)
            self.writeVint(1 if found is not None else 0)  # Message count
            if found is not None:
                self.writeVInt(found["EventType"])
                StreamEntryFactory.createStreamEntryByType(self, found)
        else:
            self.writeVint(0)  # No messages
