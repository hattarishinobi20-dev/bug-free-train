from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class GetLeaderboardLocalOkMessage(Writer):

    def __init__(self, client, player, players):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.players = players

    def encode(self):
        db = DataBase(self.player)
        self.indexOfPlayer = 1
        self.writeVint(1)
        self.writeVint(0) # SCID
        self.writeString(self.player.region)

        self.writeVint(len(self.players)) # Players Count

        for player in self.players:
            club = db.loadClub(player["club_id"])
            if player["low_id"] == self.player.low_id:
                self.indexOfPlayer = self.players.index(player) + 1
            self.writeVint(0) # High ID
            self.writeVint(player["low_id"]) # Low ID

            self.writeVint(1)
            self.writeVint(player['trophies']) # Player Trophies

            self.writeVint(1)

            self.writeString(player['name']) 
            if player["club_id"] != 0:
                db.loadClub(player["club_id"])
                self.writeString(club["info"]["name"])
            else:
                self.writeString() 

            self.writeVint(player['player_experience']) # Player Experience Level
            self.writeVint(28)  # Player Profile Icon
            self.writeVint(player['profile_icon'])
            self.writeVint(0)


        self.writeVint(0)
        self.writeVint(self.indexOfPlayer)
        self.writeVint(0)
        self.writeVint(0) # Leaderboard Region
        self.writeString(self.player.region)
