from Database.DatabaseManager import DataBase
import json
from Utils.Writer2 import Writer
from Entries.StreamEntryFactory import StreamEntryFactory

class AllianceStreamMessage(Writer):

    def __init__(self, client, player, clubLowID, type):
        super().__init__(client)
        # self.msg_content = msg_content
        self.id = 24311
        self.player = player
        self.eventType = type
        self.clubLowID = clubLowID

    def encode(self):
     db = DataBase(self.player)
     msgCount = 0
     if self.clubLowID != 0:
        clubMessages = db.loadClubMessages(self.clubLowID)
        if clubMessages is None:
           self.writeVint(0)
           return
        msgCount = len(clubMessages["info"]["messages"])
        self._player_display_cache = {}
        try:
            db.cursor.execute("SELECT data FROM Players")
            for row in db.cursor.fetchall():
                try:
                    player_data = json.loads(row[0])
                    self._player_display_cache.setdefault(int(player_data.get("low_id", 0)), player_data)
                except Exception:
                    continue
        except Exception:
            self._player_display_cache = None
        self.writeVint(msgCount)  # Message count
        #self.writeVInt(0)

        for messageKey in sorted(clubMessages["info"]["messages"].keys(), key=lambda k: int(k) if str(k).isdigit() else 0):
            message = clubMessages["info"]["messages"][messageKey]
            self.writeVInt(message["EventType"])
            StreamEntryFactory.createStreamEntryByType(self, message)
     else:
        self.writeVint(0)  # No messages