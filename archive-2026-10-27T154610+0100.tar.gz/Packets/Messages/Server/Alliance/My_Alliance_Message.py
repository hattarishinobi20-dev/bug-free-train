from Database.DatabaseManager import DataBase
from Logic import OnlineTracker
from Utils.Writer import Writer


class MyAllianceMessage(Writer):

    def __init__(self, client, player, LowID):
        super().__init__(client)
        self.id = 24399
        self.player = player
        self.clubid = LowID

    def encode(self):
        db = DataBase(self.player)
        clubInfo = db.loadClub(self.clubid) if self.clubid != 0 else None
        if clubInfo is not None:
            online_count = OnlineTracker.count_online([p.get("low_id", 0) for p in db.getSpecifiedPlayers(clubInfo["info"]["memberCount"])])
            self.writeVint(online_count)
            self.writeVint(1)
            self.writeVint(25)

            self.writeVint(self.player.club_role)

            # Club info
            self.writeInt(0)                            # Club high id
            self.writeInt(self.clubid)               # Club low id
            self.writeString(clubInfo["info"]["name"])             # Club name

            # Badge
            self.writeVint(8)
            self.writeVint(clubInfo["info"]["clubBadge"])            # Club badge id

            # Club settings
            self.writeVint(clubInfo["info"]["clubType"])               # Club type
            self.writeVint(len(clubInfo["info"]["memberCount"]))        # Club members count

            # Club trophies
            self.writeVint(db.getClubTrophies(clubInfo["info"]["memberCount"]))           # Club total trophies
            self.writeVint(clubInfo["info"]["requiredTrophies"])     # Club required trophies

            self.writeVint(0)  # Region (null DataReference)
            self.writeVint(online_count)

        else:
            self.writeVint(0)
            self.writeVint(0)