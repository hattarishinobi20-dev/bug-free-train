from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic import OnlineTracker
import json


class AllianceSearchResultMessage(Writer):

    def __init__(self, client, player, fields, count):
        super().__init__(client)
        self.id = 24310
        self.player = player
        self.fields = fields
        self.count = count

    def encode(self):
        db = DataBase(self.player)
        self.writeString(self.fields["RequestedName"])
        self.writeVint(len(self.count))

        for i in self.count:
            self.writeInt(0)                                 # ClubHighID
            self.writeInt(i["clubID"])                                 # ClubLowID
            self.writeString(i["name"])                  # Club name

            self.writeVint(8)                                # BadgeID type
            self.writeVint(i["clubBadge"])                 # Club badge number

            self.writeVint(i["clubType"])                    # Club type

            self.writeVint(len(i["memberCount"]))             # Member count

            self.writeVint(db.getClubTrophies(i["memberCount"]))                # Trophies total
            self.writeVint(i["requiredTrophies"])          # Trophies needed
            self.writeVint(0)                                # Region (null DataReference)
            self.writeVint(OnlineTracker.count_online([p.get("low_id", 0) for p in db.getSpecifiedPlayers(i["memberCount"])]))             # Members online