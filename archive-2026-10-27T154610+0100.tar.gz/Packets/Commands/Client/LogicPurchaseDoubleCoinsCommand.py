from Database.DatabaseManager import DataBase
from Logic.Shop import Shop

from Utils.Reader import BSMessageReader

class LogicPurchaseDoubleCoinsCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass


    def process(self, crypter):
        db = DataBase(self.player)
        cost = Shop.token_doubler['Cost']
        value = Shop.token_doubler['Amount']

        if self.player.gems < cost:
            return "kek"
        self.player.gems -= cost
        db.replaceValue('gems', self.player.gems)

        self.player.tokensdoubler += value
        db.replaceValue('tokens_doubler', self.player.tokensdoubler)

