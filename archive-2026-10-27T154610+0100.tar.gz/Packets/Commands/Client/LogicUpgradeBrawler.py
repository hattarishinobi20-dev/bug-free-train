from Database.DatabaseManager import DataBase
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand
class Upgrade_Brawler(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        fields = {}
        LogicCommand.decode(self, fields, False)
        #LogicCommand.parseFields(fields)
        self.BrawlerID = self.readDataReference()


    def process(self, crypter):
        db = DataBase(self.player)
        currentPowerLevel = self.player.unlocked_brawlers[str(self.BrawlerID[1])]["PowerLevel"]
        
        self.player.unlocked_brawlers[str(self.BrawlerID[1])]["PowerLevel"] += 1
        db.replaceValue("unlocked_brawlers", self.player.unlocked_brawlers)
        coins = [20, 35, 75, 140, 290, 480, 800, 1250]
        self.player.gold -= coins[currentPowerLevel]
        db.replaceValue('gold', self.player.gold)

        