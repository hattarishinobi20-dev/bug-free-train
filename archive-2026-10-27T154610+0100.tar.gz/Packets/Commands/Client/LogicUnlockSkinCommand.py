from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicUnlockSkinServerCommand import LogicUnlockSkinServerCommand
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand
from Files.CsvLogic.Cards import Cards
from Files.CsvLogic.Skins import Skins
from Packets.Commands.Server.LogicDayChanged import LogicDayChanged

class LogicUnlockSkinCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.fields = {}
        LogicCommand.decode(self, self.fields, False)
        self.fields["skin"] = self.readDataReference()


    def process(self, crypter):
        if self.fields["skin"][1] not in Skins.get_skins_id():
            return "kek"
        self.fields["isBrawler"] = Skins.getIsDefaultSkin(self.fields["skin"][1])
        self.fields["brawler"] = Skins.getBrawler(self.fields["skin"][1])
        if self.fields["isBrawler"]:
            db = DataBase(self.player)
            if str(self.fields["brawler"]) in self.player.unlocked_brawlers:
                return "kek"
            self.rewardNames = ["Brawler"]
            self.rewards = [self.fields["brawler"]]
            self.rewardsTargetBrawler = [0]
            self.player.unlocked_brawlers[str(self.rewards[0])] = {
                'CardID': Cards.get_brawler_unlock_by_character((self.rewards[0])),
                'Skins': [0],
                'selectedSkin': 0,
                'Trophies': 0,
                'HighestTrophies': 0,
                'PowerLevel': 0,
                'PowerPoints': 0,
                'State': 0,
                'StarPower': 0
            }
            
            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
            #LogicUnlockSkinServerCommand(self.client, self.player, self.fields).send(crypter)
        else:
            db = DataBase(self.player)
            if str(self.fields["brawler"]) not in self.player.unlocked_brawlers:
                return "kek"
            self.rewardNames = ["Skin"]
            self.rewards = [self.fields["skin"][1]]
            self.rewardsTargetBrawler = [int(self.fields["brawler"])]
            try:
                price = int(Skins.getSkinPrice(self.fields["skin"][1]))
            except (TypeError, ValueError):
                price = 0
            self.player.gems -= price
            db.replaceValue("gems", self.player.gems)
            self.player.unlocked_brawlers[str(self.fields["brawler"])]["Skins"].append(self.fields["skin"][1]) if self.fields["skin"][1] not in self.player.unlocked_brawlers[str(self.fields["brawler"])]["Skins"] else None
            self.player.unlocked_brawlers[str(self.fields["brawler"])]["selectedSkin"] = self.fields["skin"][1]
            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        
