from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand
from Files.CsvLogic.Cards import Cards
import random

class LogicClaimRankUpRewardCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        fields = {}
        LogicCommand.decode(self, fields, False)
        #LogicCommand.parseFields(fields)
        
        self.brawlerPowerPointsTarget = self.readDataReference()

    def process(self, crypter):
        db = DataBase(self.player)
        rewards = ["box", "brawler", "box", "event", "box", "brawler", "box", "tokenDoublers", "powerPoints", "brawler", "box", "event", "powerPoints", "box", "brawler", "coins", "powerPoints", "box", "coins", "box", "event", "powerPoints", "coins", "tickets", "brawler", "coins", "box", "powerPoints", "coins", "powerPoints", "box", "coins", "box", "powerPoints", "brawler", "coins", "box", "powerPoints", "coins", "box", "coins", "box", "powerPoints", "coins", "brawler", "coins", "powerPoints", "coins", "box", "coins", "tokenDoublers", "box", "powerPoints", "coins", "box", "powerPoints", "coins", "box", "powerPoints", "box", "powerPoints", "box", "coins", "powerPoints", "box", "coins", "box", "powerPoints", "coins", "box", "coins", "powerPoints", "box", "coins", "box", "powerPoints", "box", "coins", "box", "box", "coins", "powerPoints", "coins", "box", "box", "coins", "coins", "coins", "box", "coins", "coins", "coins", "box", "coins"]
        rewardsValue = [10, 8, 10, 2, 10, 1, 10, 200, 25, 2, 10, 3, 25, 10, 7, 50, 25, 12, 50, 10, 4, 25, 50, 10, 3, 50, 10, 75, 50, 25, 12, 50, 10, 25, 9, 50, 10, 150, 50, 10, 150, 10, 25, 50, 14, 50, 25, 300, 10, 50, 600, 10, 25, 50, 11, 25, 50, 12, 25, 11, 25, 10, 150, 25, 11, 50, 10, 75, 50, 11, 50, 25, 12, 50, 11, 25, 10, 150, 10, 11, 50, 25, 150, 10, 11, 150, 300, 150, 11, 150, 300, 150, 11, 150]
        self.player.isTrophyRoad = True
        if not (1 <= self.player.trophyRoad <= len(rewards)):
            return "kek"
        if rewards[self.player.trophyRoad - 1] == "box":
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, rewardsValue[self.player.trophyRoad-1])
            logicBoxDataCommand.getRewards()
            logicBoxDataCommand.send(crypter)
        elif rewards[self.player.trophyRoad - 1] == "event":
            self.player.unlockedEvents += 1
            db.replaceValue("unlockedEvents", self.player.unlockedEvents)
        elif rewards[self.player.trophyRoad - 1] == "brawler":
            
            brawler_id = rewardsValue[self.player.trophyRoad-1]
            if str(brawler_id) in self.player.unlocked_brawlers:
                logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 10)
                logicBoxDataCommand.getRewards()
                logicBoxDataCommand.send(crypter)
                self.player.trophyRoad += 1
                db.replaceValue("trophyRoad", self.player.trophyRoad)
                return
            self.rewardNames = ["Brawler"]
            self.rewards = [brawler_id]
            self.rewardsTargetBrawler = [0]
            self.player.unlocked_brawlers[str(self.rewards[0])] = {
                'CardID': Cards.get_brawler_unlock_by_character((self.rewards[0])),
                'Skins': [0],
                'selectedSkin': 0,
                'Trophies': 0,
                'HighestTrophies': 0,
                'PowerLevel': 0,
                'PowerPoints': 0,
                'State': 0,
                'StarPower': 0
            }
            
            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif rewards[self.player.trophyRoad - 1] == "tokenDoublers":
            self.rewardNames = ["tokens_doubler"]
            self.rewards = [rewardsValue[self.player.trophyRoad-1]]
            self.rewardsTargetBrawler = [0]
            self.player.tokensdoubler += self.rewards[0]
            db.replaceValue('tokens_doubler', self.player.tokensdoubler)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif rewards[self.player.trophyRoad - 1] == "powerPoints":
            targetBrawlers = self.brawlerPowerPointsTarget[1]
            if str(targetBrawlers) not in self.player.unlocked_brawlers:
                owned = sorted(self.player.unlocked_brawlers, key=lambda k: int(k))
                if not owned:
                    return "kek"
                targetBrawlers = int(owned[0])
            reward = rewardsValue[self.player.trophyRoad-1]
            if self.player.unlocked_brawlers[str(targetBrawlers)]["PowerPoints"]  + reward > 1410:
                reward = 1410 - self.player.unlocked_brawlers[str(targetBrawlers)]["PowerPoints"]
            self.rewards = [reward]
            self.rewardNames = ["UpgradePoints"]
            self.rewardsTargetBrawler = [targetBrawlers]
            self.player.unlocked_brawlers[str(targetBrawlers)]["PowerPoints"] += reward
            db.replaceValue('unlocked_brawlers', self.player.unlocked_brawlers)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif rewards[self.player.trophyRoad - 1] == "coins":
            self.rewards = [rewardsValue[self.player.trophyRoad-1]]
            self.rewardNames = ["Coins"]
            self.rewardsTargetBrawler = [0]
            self.player.gold += self.rewards[0]
            db.replaceValue("gold", self.player.gold)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)
        elif rewards[self.player.trophyRoad - 1] == "tickets":
            self.rewardNames = ["tickets"]
            self.rewards = [rewardsValue[self.player.trophyRoad-1]]
            self.rewardsTargetBrawler = [0]
            self.player.tickets += self.rewards[0]
            db.replaceValue('tickets', self.player.tickets)
            logicBoxDataCommand = LogicBoxDataCommand(self.client, self.player, 100, self.rewards, self.rewardNames, self.rewardsTargetBrawler)
            logicBoxDataCommand.send(crypter)

        self.player.trophyRoad += 1
        db.replaceValue("trophyRoad", self.player.trophyRoad)
        #LogicBoxDataCommand(self.client, self.player, self.box_id).send(crypter)