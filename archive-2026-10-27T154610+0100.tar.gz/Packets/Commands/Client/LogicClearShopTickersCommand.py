from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand

class LogicClearShopTickersCommand(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        fields = {}
        LogicCommand.decode(self, fields, False)
        #LogicCommand.parseFields(fields)
        

    def process(self, crypter):
        db = DataBase(self.player)
        offers = db.load_offers(self.player.token)
        if not offers or "info" not in offers:
            db.initialize_player_offers(self.player.token)
            offers = db.load_offers(self.player.token)
        offfers = offers["info"]
        for index in range(len(offfers)):
            offers["info"][str(index)]["IsOfferSeen"] = 1
        db.save_offers(self.player.token, offers)