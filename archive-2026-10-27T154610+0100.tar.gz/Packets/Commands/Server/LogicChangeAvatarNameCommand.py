from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class LogicChangeAvatarNameCommand(Writer):

    def __init__(self, client, player, state):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.state = state

    def encode(self):
        self.writeVint(201)
        self.writeString(self.player.name)
        self.writeVint(self.state)
        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(1)
        db = DataBase(self.player)
        db.replaceValue('name', self.player.name)
