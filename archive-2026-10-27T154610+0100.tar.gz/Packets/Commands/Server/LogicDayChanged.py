from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Entries.LogicDailyData import LogicDailyData
from Entries.LogicConfData import LogicConfData

class LogicDayChanged(Writer):

    def __init__(self, client, player, updateDailyData, updateConfData):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.updateDailyData = updateDailyData
        self.updateConfData = updateConfData
    def encode(self):
        self.writeVInt(204)
        self.writeBoolean(self.updateDailyData)
        if self.updateDailyData:
            LogicDailyData.encode(self)
        self.writeBoolean(self.updateConfData)
        if self.updateConfData:
            LogicConfData.encode(self)
