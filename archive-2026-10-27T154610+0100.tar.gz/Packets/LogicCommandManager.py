from Packets.PiranhaMessage import PiranhaMessage
from Packets.Commands.LogicCommand import LogicCommand
from Packets.Commands.Client.LogicUpgradeBrawler import Upgrade_Brawler
from Packets.Commands.Client.LogicSetPlayerThumbnailCommand import LogicSetPlayerThumbnailCommand
from Packets.Commands.Client.LogicPurchaseBoxCommand import LogicPurchaseBoxCommand
from Packets.Commands.Client.LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from Packets.Commands.Client.LogicSelectSkinCommand import LogicSelectSkinCommand
from Packets.Commands.Client.LogicPurchaseHeroLvlUpMaterialCommand import LogicPurchaseHeroLvlUpMaterialCommand
from Packets.Commands.Client.LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from Database.DatabaseManager import DataBase
from Packets.Commands.Client.LogicUnlockSkinCommand import LogicUnlockSkinCommand
from Packets.Commands.Client.LogicClaimRankUpRewardCommand import LogicClaimRankUpRewardCommand
from Packets.Commands.Client.LogicClearShopTickersCommand import LogicClearShopTickersCommand
from random import choice
from string import ascii_uppercase
import json
class EndClientTurn(PiranhaMessage):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        self.readBoolean()
        self.readVInt()
        self.readVInt()
        self.count = self.readVInt()
        self.commandID = []


    def process(self, crypter):
      db = DataBase(self.player)
      for x in range(self.count):
       try:
        current_id = self.readVInt()
        self.commandID.append(current_id)
        if current_id == 503:
            _fields503 = {}
            LogicCommand.decode(self, _fields503, False)
            _slot503 = self.readVInt()
            try:
                _events503 = db.loadEvents(1)["info"]["events"]
                _event503 = _events503.get(str(_slot503 - 1))
                if _event503 is not None:
                    _collected503 = dict(getattr(self.player, "collected_events", None) or {})
                    if _collected503.get(str(_slot503)) != _event503["TimeStamp"]:
                        _collected503[str(_slot503)] = _event503["TimeStamp"]
                        self.player.collected_events = _collected503
                        db.replaceValue("collected_events", _collected503)
                        _bonus503 = int(_event503.get("Tokens", 10))
                        self.player.brawl_boxes += _bonus503
                        db.replaceValue("brawl_boxes", self.player.brawl_boxes)
                        print(f"[EVENTO] Bonus de evento novo coletado: slot {_slot503}, +{_bonus503} fichas (player {self.player.low_id})")
            except Exception as _e503:
                print(f"[EVENTO] Falha ao coletar bonus do slot {_slot503}: {_e503}")

        elif current_id == 500 or current_id == 535:
            LogicPurchaseBoxCommand.decode(self)
            LogicPurchaseBoxCommand.process(self, crypter)
            
        elif current_id == 517:
            LogicClaimRankUpRewardCommand.decode(self)
            LogicClaimRankUpRewardCommand.process(self, crypter)
            
        elif current_id == 515:
            LogicClearShopTickersCommand.decode(self)
            LogicClearShopTickersCommand.process(self, crypter)

        elif current_id == 519:
            LogicPurchaseOfferCommand.decode(self)
            LogicPurchaseOfferCommand.process(self, crypter)

        elif current_id == 505:
            LogicSetPlayerThumbnailCommand.decode(self)
            LogicSetPlayerThumbnailCommand.process(self, crypter)

        elif current_id == 506:
            LogicSelectSkinCommand.decode(self)
            LogicSelectSkinCommand.process(self, crypter)
        
        elif current_id == 507:
            LogicUnlockSkinCommand.decode(self)
            LogicUnlockSkinCommand.process(self, crypter)

        elif current_id == 520:
            Upgrade_Brawler.decode(self)
            Upgrade_Brawler.process(self, crypter)

        elif current_id == 521:
            LogicPurchaseHeroLvlUpMaterialCommand.decode(self)
            LogicPurchaseHeroLvlUpMaterialCommand.process(self, crypter)
            
        elif current_id == 522:
            _fields522 = {}
            LogicCommand.decode(self, _fields522, False)
            self.readDataReference()

        elif current_id == 509:
            LogicPurchaseDoubleCoinsCommand.decode(self)
            LogicPurchaseDoubleCoinsCommand.process(self, crypter)
            
        elif current_id < 500 or current_id > 570:
            break

        else:
            print("CommandID:", current_id, "not handled!")
            break
       except Exception as _cmdError:
        print("Command error:", _cmdError)
        break