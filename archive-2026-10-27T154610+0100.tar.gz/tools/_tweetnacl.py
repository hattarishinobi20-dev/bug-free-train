from nacl import bindings as _b

crypto_box_NONCEBYTES = 24

def crypto_scalarmult_base(sk):
    return _b.crypto_scalarmult_base(sk)

def crypto_box_beforenm(pk, sk):
    return _b.crypto_box_beforenm(pk, sk)

def crypto_secretbox(m, n, k):
    return _b.crypto_secretbox_easy(m, n, k)

def crypto_secretbox_open(c, n, k):
    return _b.crypto_secretbox_open_easy(c, n, k)

def crypto_box_afternm(m, n, k):
    return _b.crypto_secretbox_easy(m, n, k)

def crypto_box_open_afternm(c, n, k):
    return _b.crypto_secretbox_open_easy(c, n, k)

def crypto_hash(m):
    return _b.crypto_hash_sha512(m)
