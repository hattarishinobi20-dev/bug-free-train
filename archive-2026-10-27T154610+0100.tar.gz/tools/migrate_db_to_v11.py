#!/usr/bin/env python3
import json
import shutil
import sqlite3
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

V11_LOCATIONS = ['Wanted1', 'Wanted2', 'Wanted3', 'Wanted4', 'Wanted5', 'Wanted6', 'Wanted7',
                 'Gemgrab1', 'Gemgrab2', 'Gemgrab3', 'Gemgrab4', 'Gemgrab5', 'Gemgrab6',
                 'Survival1', 'Survival2', 'Survival3', 'Survival4', 'Heist1', 'Heist2',
                 'Heist3', 'Tutorial', 'BossFight1', 'Wanted8', 'Heist4', 'Ball1', 'Ball2',
                 'Ball3', 'Coop1', 'SurvivalTeam1', 'Coop2', 'BossFight2', 'Gemgrab8',
                 'Survival5', 'Survival6', 'SurvivalTeam2', 'SurvivalTeam3', 'SurvivalTeam4',
                 'SurvivalTeam5', 'SurvivalTeam6', 'GeneratedRobo', 'Gemgrab7', 'Gemgrab9',
                 'Gemgrab10', 'Heist5', 'Survival7', 'SurvivalTeam7', 'Survival8',
                 'SurvivalTeam8', 'Heist6']
V12_LOCATIONS = ['Wanted1', 'Wanted2', 'Wanted3', 'Wanted4', 'Wanted5', 'Wanted6', 'Wanted7',
                 'Gemgrab1', 'Gemgrab2', 'Gemgrab3', 'Gemgrab4', 'Gemgrab5', 'Gemgrab6',
                 'Survival1', 'Survival2', 'Survival3', 'Survival4', 'Heist1', 'Heist2',
                 'Heist3', 'Tutorial', 'BossFight1', 'Wanted8', 'Heist4', 'Ball1', 'Ball2',
                 'Ball3', 'Coop1', 'SurvivalTeam1', 'Coop2', 'BossFight2', 'Gemgrab8',
                 'Survival5', 'Survival6', 'SurvivalTeam2', 'SurvivalTeam3', 'SurvivalTeam4',
                 'SurvivalTeam5', 'SurvivalTeam6', 'GeneratedRobo', 'Gemgrab7', 'Gemgrab10',
                 'Heist5', 'Survival7', 'SurvivalTeam7', 'Survival8', 'SurvivalTeam8',
                 'Heist6', 'Gemgrab11', 'Heist7', 'Ball4', 'Ball6', 'Ball7', 'Heist8',
                 'Wanted9', 'Survival12', 'SurvivalTeam12']
SLOT_DEFAULT = [7, 16, 23, 1, 38, 25]


def to_v11(location_v12, slot):
    if 0 <= location_v12 < len(V12_LOCATIONS):
        name = V12_LOCATIONS[location_v12]
        if name in V11_LOCATIONS:
            return V11_LOCATIONS.index(name)
    return SLOT_DEFAULT[slot % len(SLOT_DEFAULT)]


def main():
    db_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("database.db")
    if not db_path.exists():
        print(f"Banco nao encontrado: {db_path}")
        return 1
    backup = db_path.with_suffix(".db.bak")
    shutil.copyfile(db_path, backup)
    print(f"Backup criado: {backup}")

    con = sqlite3.connect(db_path)
    cur = con.cursor()
    stamp = int((datetime.now() + timedelta(days=1)).replace(
        hour=10, minute=0, second=0, microsecond=0).timestamp())

    try:
        for state, raw in cur.execute("SELECT state, data FROM Events").fetchall():
            data = json.loads(raw)
            for key, event in data.get("info", {}).get("events", {}).items():
                old = event.get("ID", 7)
                new = to_v11(old, int(key))
                if new != old:
                    print(f"  Events[state={state}][{key}]: mapa {old} -> {new}")
                event["ID"] = new
                if event.get("TimeStamp", 0) < time.time():
                    event["TimeStamp"] = stamp
            cur.execute("UPDATE Events SET data = ? WHERE state = ?",
                        (json.dumps(data), state))
        print("Events migrados.")
    except sqlite3.Error as e:
        print(f"(sem tabela Events: {e})")

    try:
        rows = cur.execute("SELECT token, data FROM Players").fetchall()
        for token, raw in rows:
            p = json.loads(raw)
            brawlers = p.get("unlocked_brawlers", {})
            changed = False
            for key in list(brawlers.keys()):
                try:
                    char_id = int(key)
                except (TypeError, ValueError):
                    char_id = -1
                if char_id < 0 or char_id > 20 or brawlers[key].get("CardID", 0) > 104:
                    print(f"  Player {token[:8]}...: removido brawler invalido p/ v11: {key}")
                    del brawlers[key]
                    changed = True
                    continue
                skins = [s for s in brawlers[key].get("Skins", [0]) if isinstance(s, int) and s <= 49]
                if skins != brawlers[key].get("Skins"):
                    brawlers[key]["Skins"] = skins if skins else [0]
                    changed = True
                if not isinstance(brawlers[key].get("selectedSkin", 0), int) or brawlers[key]["selectedSkin"] > 49:
                    brawlers[key]["selectedSkin"] = 0
                    changed = True
            if isinstance(p.get("profile_icon"), int) and not (0 <= p["profile_icon"] <= 36):
                p["profile_icon"] = 0
                changed = True
            if changed:
                cur.execute("UPDATE Players SET data = ? WHERE token = ?",
                            (json.dumps(p), token))
        print(f"{len(rows)} jogador(es) verificados.")
    except sqlite3.Error as e:
        print(f"(sem tabela Players: {e})")

    try:
        cur.execute("DELETE FROM PlayerOffers")
        print("PlayerOffers limpas (serao recriadas).")
    except sqlite3.Error:
        pass

    con.commit()
    con.close()
    print("Migracao concluida.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
