import json
import os
import sqlite3
from pathlib import Path


SERVER_ROOT = Path(__file__).resolve().parent.parent
BANNED_ACC_PATH = SERVER_ROOT / "banned_acc.json"
BANNED_IP_PATH = SERVER_ROOT / "banned_ip.json"
DATABASE_PATH = SERVER_ROOT / "database.db"


def _load(path):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _save(path, data):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(data, indent=4), encoding="utf-8")
    os.replace(temporary, path)


def load_ban_lists():
    return _load(BANNED_ACC_PATH), _load(BANNED_IP_PATH)


def save_ban_lists(banned_acc, banned_ip):
    _save(BANNED_ACC_PATH, banned_acc)
    _save(BANNED_IP_PATH, banned_ip)


def _reason(entry):
    if isinstance(entry, dict):
        return str(entry.get("reason") or "")
    return str(entry or "")


def add_bans(low_id, ip, reason):
    banned_acc, banned_ip = load_ban_lists()
    low_key = str(low_id).strip() if low_id not in (None, "") else ""
    ip = str(ip or "").strip()
    reason = str(reason or "")
    if low_key:
        banned_acc[low_key] = {"reason": reason}
    if ip:
        banned_ip[ip] = {"reason": reason}
    save_ban_lists(banned_acc, banned_ip)
    return bool(low_key), bool(ip)


def check_and_sync_ban(low_id, ip):
    banned_acc, banned_ip = load_ban_lists()
    low_key = str(low_id).strip() if low_id not in (None, "", 0, "0") else ""
    ip = str(ip or "").strip()
    if low_key and low_key in banned_acc:
        reason = _reason(banned_acc[low_key])
        if ip and banned_ip.get(ip) != {"reason": reason}:
            banned_ip[ip] = {"reason": reason}
            save_ban_lists(banned_acc, banned_ip)
        return reason
    if ip and ip in banned_ip:
        reason = _reason(banned_ip[ip])
        if low_key and banned_acc.get(low_key) != {"reason": reason}:
            banned_acc[low_key] = {"reason": reason}
            save_ban_lists(banned_acc, banned_ip)
        return reason
    return None


def remove_bans(low_id=None, ip=None):
    banned_acc, banned_ip = load_ban_lists()
    low_key = str(low_id).strip() if low_id not in (None, "") else ""
    ip = str(ip or "").strip()
    removed_acc = False
    removed_ip = False
    if low_key and low_key in banned_acc:
        del banned_acc[low_key]
        removed_acc = True
    if ip and ip in banned_ip:
        del banned_ip[ip]
        removed_ip = True
    if removed_acc or removed_ip:
        save_ban_lists(banned_acc, banned_ip)
    return removed_acc, removed_ip


def migrate_legacy_banned_ips(database_path=DATABASE_PATH):
    if not Path(database_path).exists():
        return 0
    connection = sqlite3.connect(str(database_path), timeout=10)
    try:
        table = connection.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'BannedIps'"
        ).fetchone()
        if not table:
            return 0
        rows = connection.execute("SELECT ip, reason FROM BannedIps").fetchall()
    finally:
        connection.close()
    if not rows:
        return 0
    banned_acc, banned_ip = load_ban_lists()
    migrated = 0
    for ip, reason in rows:
        ip = str(ip or "").strip()
        if ip and ip not in banned_ip:
            banned_ip[ip] = {"reason": str(reason or "")}
            migrated += 1
    if migrated:
        save_ban_lists(banned_acc, banned_ip)
    return migrated
