# Okay — Brawl Stars **v11.112** server (convertido da v12)

Servidor privado em Python para o cliente **11.112** (APK patcheado do
projeto [Voeed/Brawl-stars-v11](https://github.com/Voeed/Brawl-stars-v11)).

Esta é a **mesma base de código da v12** (Okay), com o protocolo convertido
para a v11: contas/banco de dados, loja e ofertas, caixas, clube, amigos,
salas de equipe, rankings e batalhas de treino continuam os mesmos — só o
formato dos pacotes mudou. O detalhamento de tudo que foi alterado está em
[CHANGES_V11.md](CHANGES_V11.md).

## Requisitos
- Python 3
- Módulo `_tweetnacl` compilado (o mesmo que você já usava na v12)
  **ou** a alternativa via PyNaCl: `pip install pynacl` e copie
  `tools/_tweetnacl.py` para a raiz do servidor.

## Como rodar
```
py main.py
```
O servidor escuta em `0.0.0.0:9339`. Aponte o APK 11.112 patcheado para o
IP da sua máquina (o APK do Voeed já vem preparado para isso).

## Banco de dados
- O `database.db` que acompanha já foi migrado para os IDs de mapa da v11.
- Para migrar outro banco seu da v12 (contas incluídas):
  ```
  py tools/migrate_db_to_v11.py caminho/para/database.db
  ```
  Ele cria backup `.bak`, remapeia os mapas dos eventos, remove
  brawlers/skins que não existem na 11.112 e limpa as ofertas (o servidor
  gera ofertas novas e válidas).

## Configuração nova
- `config.json` → `"EnableSocialPackets": true` — controla os pacotes de
  clube/amigos (`MyAllianceData` 24399 e `FriendList` 20105). Se o cliente
  fechar logo depois de entrar na tela inicial, coloque `false` e teste de
  novo (esses dois pacotes não têm referência pública na 11.112).

## Testes incluídos
- `py tools/test_protocol.py` — gera `OwnHomeData`, `LoginOk` e
  `BattleResult` e relê byte a byte no formato esperado pelo cliente
  11.112 (roda numa cópia da pasta, pois cria uma conta de teste no banco).

## Créditos
- Base: Okay v12 (Nyxazy), sobre o Classic-Brawl
- Referência de protocolo v11: Voeed/Brawl-stars-v11
- CSVs oficiais 11.112: tailsjs/brawl-stars-assets
