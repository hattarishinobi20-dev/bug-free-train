OgSaver
========

OgSaver runs inside AdminBot. There is ONE bot, ONE token and ONE polling
loop. The bot is the same one defined in AdminBot/config.json.

Setup
-----

1. Configure the bot once, exactly like AdminBot:
   - Put the token in AdminBot/config.json (BOT_TOKEN) or in the
     BOT_TOKEN environment variable.
   - Put the owner Telegram IDs in ADMIN_IDS.

2. Who sees what:
   - Telegram IDs listed in ADMIN_IDS see the admin panel and an
     "OgSaver" button inside it.
   - Every other Telegram user sees ONLY OgSaver: Register account,
     My accounts and Add another account. Admin options are never
     shown to them.

3. Start the game server (main.py). It starts the bot automatically.
   The bot (AdminBot/bot.py) can also be started alone.

IMPORTANT: run exactly ONE copy of the bot. If the server (main.py)
is running, do NOT also run AdminBot/bot.py, and do not leave another
old copy running in a second window/session. Two copies polling the
same bot token cause:
  409 Conflict: terminated by other getUpdates request
If you see that error, close every other running copy and keep only one.

Optional settings (top of AdminBot/bot.py):
- CODE_EXPIRY_SECONDS: how long a generated code stays valid
- SAVER_ACCOUNTS_PER_PAGE: accounts per page in the list

Player commands
---------------

- /start - open the button menu
- /register - create a registration code
- /add - save another game account
- /accounts - list saved accounts and create redeem codes
- /cancel - cancel the pending code

How it works
------------

The first screen shows only buttons.

Register account / Add another account gives a 6-number code. The
player sends "/code 123456" (with his own code) in the club chat.
The server saves the exact account that sent the message under the
Telegram user, and the bot confirms: Account (account name) saved.

My accounts lists the saved accounts. Tapping an account gives a
redeem code. On any device, the player sends "/load 123456" in the
club chat and restarts the game; the next login opens the saved
account.

The /code and /load messages are hidden: they never appear in the
club chat for anyone. The player must be in a club to use them, so
accounts without a club need to join any club first.

Saved data lives in OgSaver/ogsaver.db. Existing OgSaver data keeps
working because the Telegram user IDs are the same.

This folder only contains the database layer (store.py), used by
AdminBot/bot.py and the game server.
