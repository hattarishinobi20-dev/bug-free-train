import csv
import json
import os
import secrets
import sqlite3
import time
from pathlib import Path


BARLEY_ID = 6
DEFAULT_EXPIRY_SECONDS = 600


def _now():
    return int(time.time())


def _safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def _dict(row):
    return dict(row) if row is not None else None


class OgSaverStore:
    def __init__(self, saver_db_path=None, game_db_path=None):
        package_dir = Path(__file__).resolve().parent
        root_dir = package_dir.parent
        self.root_dir = root_dir
        saver_value = saver_db_path or os.getenv("OGSAVER_DATABASE_PATH") or package_dir / "ogsaver.db"
        game_value = game_db_path or os.getenv("OGSAVER_GAME_DATABASE_PATH") or root_dir / "database.db"
        self.saver_db_path = Path(saver_value).resolve()
        self.game_db_path = Path(game_value).resolve()

    def _connect(self):
        self.saver_db_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(str(self.saver_db_path), timeout=30)
        connection.row_factory = sqlite3.Row
        return connection

    def _game_connect(self):
        if not self.game_db_path.exists():
            return None
        connection = sqlite3.connect(str(self.game_db_path), timeout=30)
        connection.row_factory = sqlite3.Row
        return connection

    def initialize(self):
        connection = self._connect()
        try:
            alias_table_exists = connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'login_aliases'"
            ).fetchone() is not None
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS saver_users (
                    telegram_user_id INTEGER PRIMARY KEY,
                    last_ip TEXT NOT NULL DEFAULT '',
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS saved_accounts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    telegram_user_id INTEGER NOT NULL,
                    account_token TEXT NOT NULL,
                    low_id INTEGER NOT NULL,
                    account_name TEXT NOT NULL DEFAULT '',
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    UNIQUE(telegram_user_id, account_token)
                );
                CREATE INDEX IF NOT EXISTS idx_saved_accounts_user
                    ON saved_accounts(telegram_user_id, id);
                CREATE TABLE IF NOT EXISTS pending_operations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code TEXT NOT NULL UNIQUE,
                    telegram_user_id INTEGER NOT NULL,
                    action TEXT NOT NULL CHECK(action IN ('register', 'redeem')),
                    status TEXT NOT NULL DEFAULT 'pending',
                    target_saved_account_id INTEGER,
                    target_account_token TEXT,
                    target_low_id INTEGER,
                    target_account_name TEXT NOT NULL DEFAULT '',
                    target_last_ip TEXT NOT NULL DEFAULT '',
                    bound_ip TEXT NOT NULL DEFAULT '',
                    bound_device_id TEXT NOT NULL DEFAULT '',
                    incoming_account_token TEXT NOT NULL DEFAULT '',
                    incoming_low_id INTEGER NOT NULL DEFAULT 0,
                    matched_account_token TEXT NOT NULL DEFAULT '',
                    matched_low_id INTEGER NOT NULL DEFAULT 0,
                    matched_account_name TEXT NOT NULL DEFAULT '',
                    reward_summary TEXT NOT NULL DEFAULT '',
                    error_message TEXT NOT NULL DEFAULT '',
                    created_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    claimed_at INTEGER,
                    armed_at INTEGER,
                    completed_at INTEGER,
                    armed_notified_at INTEGER,
                    notified_at INTEGER
                );
                CREATE INDEX IF NOT EXISTS idx_pending_status
                    ON pending_operations(status, expires_at, created_at);
                CREATE INDEX IF NOT EXISTS idx_pending_user
                    ON pending_operations(telegram_user_id, status, created_at);
                CREATE TABLE IF NOT EXISTS login_aliases (
                    source_account_token TEXT PRIMARY KEY,
                    source_low_id INTEGER NOT NULL DEFAULT 0,
                    target_account_token TEXT NOT NULL,
                    target_low_id INTEGER NOT NULL DEFAULT 0,
                    telegram_user_id INTEGER NOT NULL DEFAULT 0,
                    updated_at INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_login_aliases_target
                    ON login_aliases(target_account_token);
                CREATE TABLE IF NOT EXISTS registration_rewards (
                    account_token TEXT PRIMARY KEY,
                    low_id INTEGER NOT NULL DEFAULT 0,
                    brawler_granted INTEGER NOT NULL DEFAULT 0,
                    gems_granted INTEGER NOT NULL DEFAULT 0,
                    granted_at INTEGER NOT NULL
                );
                """
            )
            if not alias_table_exists:
                self._backfill_login_aliases(connection)
            connection.commit()
        finally:
            connection.close()

    def _expire(self, connection, now=None):
        now = _now() if now is None else now
        connection.execute(
            "UPDATE pending_operations SET status = 'expired' "
            "WHERE status IN ('pending', 'claimed', 'armed', 'completing') AND expires_at <= ?",
            (now,),
        )

    def _touch_user(self, connection, telegram_user_id, source_ip=""):
        now = _now()
        telegram_user_id = int(telegram_user_id)
        source_ip = str(source_ip or "")
        row = connection.execute(
            "SELECT last_ip FROM saver_users WHERE telegram_user_id = ?",
            (telegram_user_id,),
        ).fetchone()
        if row is None:
            connection.execute(
                "INSERT INTO saver_users (telegram_user_id, last_ip, created_at, updated_at) VALUES (?, ?, ?, ?)",
                (telegram_user_id, source_ip, now, now),
            )
        else:
            connection.execute(
                "UPDATE saver_users SET last_ip = ?, updated_at = ? WHERE telegram_user_id = ?",
                (source_ip or row[0] or "", now, telegram_user_id),
            )

    def _get_pending(self, connection, pending_id):
        return _dict(
            connection.execute(
                "SELECT * FROM pending_operations WHERE id = ?",
                (int(pending_id),),
            ).fetchone()
        )

    def _get_login_alias(self, connection, source_account_token):
        return _dict(
            connection.execute(
                "SELECT * FROM login_aliases WHERE source_account_token = ?",
                (str(source_account_token or ""),),
            ).fetchone()
        )

    def _delete_login_alias(self, connection, source_account_token):
        connection.execute(
            "DELETE FROM login_aliases WHERE source_account_token = ?",
            (str(source_account_token or ""),),
        )

    def _save_login_alias(self, connection, source_account_token, source_low_id, target_account_token, target_low_id, telegram_user_id, now=None):
        source_account_token = str(source_account_token or "")
        target_account_token = str(target_account_token or "")
        if not source_account_token or not target_account_token:
            return
        if source_account_token == target_account_token:
            self._delete_login_alias(connection, source_account_token)
            return
        updated_at = _now() if now is None else _safe_int(now)
        existing = self._get_login_alias(connection, source_account_token)
        if existing is None:
            connection.execute(
                "INSERT INTO login_aliases "
                "(source_account_token, source_low_id, target_account_token, target_low_id, telegram_user_id, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    source_account_token,
                    _safe_int(source_low_id),
                    target_account_token,
                    _safe_int(target_low_id),
                    _safe_int(telegram_user_id),
                    updated_at,
                ),
            )
        else:
            connection.execute(
                "UPDATE login_aliases SET source_low_id = ?, target_account_token = ?, target_low_id = ?, "
                "telegram_user_id = ?, updated_at = ? WHERE source_account_token = ?",
                (
                    _safe_int(source_low_id),
                    target_account_token,
                    _safe_int(target_low_id),
                    _safe_int(telegram_user_id),
                    updated_at,
                    source_account_token,
                ),
            )

    def _backfill_login_aliases(self, connection):
        rows = connection.execute(
            "SELECT incoming_account_token, incoming_low_id, target_account_token, target_low_id, "
            "telegram_user_id, completed_at, created_at FROM pending_operations "
            "WHERE action = 'redeem' AND status = 'completed' "
            "AND incoming_account_token IS NOT NULL AND incoming_account_token != '' "
            "AND target_account_token IS NOT NULL AND target_account_token != '' "
            "ORDER BY COALESCE(completed_at, created_at, 0), id"
        ).fetchall()
        for row in rows:
            item = _dict(row) or {}
            self._save_login_alias(
                connection,
                item.get("incoming_account_token"),
                item.get("incoming_low_id"),
                item.get("target_account_token"),
                item.get("target_low_id"),
                item.get("telegram_user_id"),
                item.get("completed_at") or item.get("created_at"),
            )

    def resolve_login_alias(self, source_account_token, source_low_id=0):
        self.initialize()
        source_account_token = str(source_account_token or "")
        if not source_account_token:
            return None
        connection = self._connect()
        try:
            current_token = source_account_token
            seen_tokens = set()
            result = None
            first_hop = True
            changed = False
            for _ in range(10):
                alias = self._get_login_alias(connection, current_token)
                if alias is None:
                    break
                target_token = str(alias.get("target_account_token") or "")
                if not target_token or target_token == current_token or target_token in seen_tokens:
                    if first_hop:
                        self._delete_login_alias(connection, source_account_token)
                        changed = True
                    break
                if self.get_game_player(target_token) is None:
                    if first_hop:
                        self._delete_login_alias(connection, source_account_token)
                        changed = True
                    break
                result = alias
                seen_tokens.add(current_token)
                current_token = target_token
                first_hop = False
            if changed:
                connection.commit()
            return result
        finally:
            connection.close()

    def get_game_player(self, account_token):
        if not account_token:
            return None
        connection = self._game_connect()
        if connection is None:
            return None
        try:
            row = connection.execute(
                "SELECT token, data FROM Players WHERE token = ?",
                (str(account_token),),
            ).fetchone()
            if row is None:
                return None
            try:
                data = json.loads(row["data"] or "{}")
            except Exception:
                data = {}
            if not isinstance(data, dict):
                data = {}
            return {"token": row["token"], "data": data}
        except sqlite3.Error:
            return None
        finally:
            connection.close()

    def _enrich_account(self, account):
        result = dict(account)
        current = self.get_game_player(result.get("account_token"))
        result["exists"] = current is not None
        if current is None:
            result["current_name"] = result.get("account_name") or "Brawler"
            result["trophies"] = 0
            result["gems"] = 0
            result["last_ip"] = ""
            return result
        data = current["data"]
        result["current_name"] = data.get("name") or result.get("account_name") or "Brawler"
        result["low_id"] = _safe_int(data.get("low_id"), _safe_int(result.get("low_id")))
        result["trophies"] = _safe_int(data.get("trophies"))
        result["gems"] = _safe_int(data.get("gems"))
        result["last_ip"] = str(data.get("last_ip") or "")
        return result

    def list_accounts(self, telegram_user_id):
        self.initialize()
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT * FROM saved_accounts WHERE telegram_user_id = ? ORDER BY id",
                (int(telegram_user_id),),
            ).fetchall()
        finally:
            connection.close()
        return [self._enrich_account(_dict(row)) for row in rows]

    def get_saved_account(self, telegram_user_id, saved_account_id):
        self.initialize()
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT * FROM saved_accounts WHERE telegram_user_id = ? AND id = ?",
                (int(telegram_user_id), int(saved_account_id)),
            ).fetchone()
        finally:
            connection.close()
        return self._enrich_account(_dict(row)) if row is not None else None

    def create_pending(self, telegram_user_id, action, saved_account_id=None, expiry_seconds=DEFAULT_EXPIRY_SECONDS):
        if action not in ("register", "redeem"):
            raise ValueError("Invalid OgSaver action")
        self.initialize()
        target = None
        if action == "redeem":
            target = self.get_saved_account(telegram_user_id, saved_account_id)
            if target is None or not target.get("exists"):
                return None
        expiry_seconds = max(60, _safe_int(expiry_seconds, DEFAULT_EXPIRY_SECONDS))
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            self._expire(connection, now)
            self._touch_user(connection, telegram_user_id)
            connection.execute(
                "UPDATE pending_operations SET status = 'cancelled', notified_at = ? "
                "WHERE telegram_user_id = ? AND status = 'pending'",
                (now, int(telegram_user_id)),
            )
            connection.execute(
                "DELETE FROM pending_operations WHERE status IN ('completed', 'failed', 'expired', 'cancelled') "
                "AND notified_at IS NOT NULL AND COALESCE(completed_at, created_at) < ?",
                (now - 86400,),
            )
            while True:
                code = "%06d" % secrets.randbelow(1000000)
                try:
                    cursor = connection.execute(
                        "INSERT INTO pending_operations "
                        "(code, telegram_user_id, action, target_saved_account_id, target_account_token, "
                        "target_low_id, target_account_name, target_last_ip, created_at, expires_at) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                        (
                            code,
                            int(telegram_user_id),
                            action,
                            int(target["id"]) if target else None,
                            target.get("account_token") if target else None,
                            _safe_int(target.get("low_id")) if target else None,
                            target.get("current_name", "") if target else "",
                            target.get("last_ip", "") if target else "",
                            now,
                            now + expiry_seconds,
                        ),
                    )
                    break
                except sqlite3.IntegrityError:
                    continue
            pending = self._get_pending(connection, cursor.lastrowid)
            connection.commit()
            return pending
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def cancel_pending(self, telegram_user_id):
        self.initialize()
        now = _now()
        connection = self._connect()
        try:
            cursor = connection.execute(
                "UPDATE pending_operations SET status = 'cancelled', notified_at = ? "
                "WHERE telegram_user_id = ? AND status = 'pending'",
                (now, int(telegram_user_id)),
            )
            connection.commit()
            return cursor.rowcount
        finally:
            connection.close()

    def _pending_score(self, row, source_ip, incoming_token, user_ips):
        score = 0
        if source_ip and row.get("bound_ip") == source_ip:
            score = max(score, 100)
        if source_ip and user_ips.get(_safe_int(row.get("telegram_user_id"))) == source_ip:
            score = max(score, 80)
        if source_ip and row.get("target_last_ip") == source_ip:
            score = max(score, 70)
        if incoming_token and row.get("target_account_token") == incoming_token:
            score = max(score, 60)
        return score

    def claim_pending_for_login(self, source_ip, device_id="", incoming_token="", incoming_low_id=0):
        self.initialize()
        source_ip = str(source_ip or "")
        device_id = str(device_id or "")
        incoming_token = str(incoming_token or "")
        incoming_low_id = _safe_int(incoming_low_id)
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            self._expire(connection, now)
            rows = [
                _dict(row)
                for row in connection.execute(
                    "SELECT * FROM pending_operations WHERE status = 'pending' AND expires_at > ? "
                    "ORDER BY created_at, id",
                    (now,),
                ).fetchall()
            ]
            if not rows:
                connection.commit()
                return None
            user_ips = {
                _safe_int(row["telegram_user_id"]): str(row["last_ip"] or "")
                for row in connection.execute("SELECT telegram_user_id, last_ip FROM saver_users").fetchall()
            }
            scored = [
                (self._pending_score(row, source_ip, incoming_token, user_ips), row)
                for row in rows
            ]
            best_score = max(score for score, _ in scored)
            chosen = None
            if best_score > 0:
                chosen = next(row for score, row in scored if score == best_score)
            elif len(rows) == 1:
                chosen = rows[0]
            if chosen is None:
                connection.commit()
                return None
            connection.execute(
                "UPDATE pending_operations SET status = 'claimed', claimed_at = ?, bound_ip = ?, "
                "bound_device_id = ?, incoming_account_token = ?, incoming_low_id = ? WHERE id = ? AND status = 'pending'",
                (now, source_ip, device_id, incoming_token, incoming_low_id, int(chosen["id"])),
            )
            pending = self._get_pending(connection, chosen["id"])
            connection.commit()
            return pending
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def claim_pending_by_code(self, code, source_ip, device_id="", incoming_token="", incoming_low_id=0):
        self.initialize()
        code = "".join(character for character in str(code or "") if character.isdigit())
        if not code:
            return None
        source_ip = str(source_ip or "")
        device_id = str(device_id or "")
        incoming_token = str(incoming_token or "")
        incoming_low_id = _safe_int(incoming_low_id)
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            self._expire(connection, now)
            row = connection.execute(
                "SELECT * FROM pending_operations WHERE code = ? AND status = 'pending' AND expires_at > ?",
                (code, now),
            ).fetchone()
            if row is None:
                connection.commit()
                return None
            connection.execute(
                "UPDATE pending_operations SET status = 'claimed', claimed_at = ?, bound_ip = ?, "
                "bound_device_id = ?, incoming_account_token = ?, incoming_low_id = ? WHERE id = ? AND status = 'pending'",
                (now, source_ip, device_id, incoming_token, incoming_low_id, int(row["id"])),
            )
            pending = self._get_pending(connection, row["id"])
            connection.commit()
            return pending
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def claim_armed_redeem(self, source_ip, device_id="", incoming_token="", incoming_low_id=0):
        self.initialize()
        source_ip = str(source_ip or "")
        device_id = str(device_id or "")
        incoming_token = str(incoming_token or "")
        incoming_low_id = _safe_int(incoming_low_id)
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            self._expire(connection, now)
            rows = [
                _dict(row)
                for row in connection.execute(
                    "SELECT * FROM pending_operations WHERE status = 'armed' AND action = 'redeem' AND expires_at > ? "
                    "ORDER BY armed_at, id",
                    (now,),
                ).fetchall()
            ]
            chosen = None
            best_score = 0
            for row in rows:
                bound_device = str(row.get("bound_device_id") or "")
                bound_token = str(row.get("incoming_account_token") or "")
                bound_low = _safe_int(row.get("incoming_low_id"))
                if bound_device and device_id and bound_device != device_id:
                    continue
                if bound_token and incoming_token and bound_token != incoming_token:
                    continue
                if bound_low and incoming_low_id and bound_low != incoming_low_id:
                    continue
                score = 0
                if source_ip and row.get("bound_ip") == source_ip:
                    score += 50
                if bound_device and device_id and bound_device == device_id:
                    score += 40
                if bound_token and incoming_token and bound_token == incoming_token:
                    score += 30
                if bound_low and incoming_low_id and bound_low == incoming_low_id:
                    score += 20
                if score > best_score:
                    best_score = score
                    chosen = row
            if chosen is None:
                connection.commit()
                return None
            connection.execute(
                "UPDATE pending_operations SET status = 'completing' WHERE id = ? AND status = 'armed'",
                (int(chosen["id"]),),
            )
            pending = self._get_pending(connection, chosen["id"])
            connection.commit()
            return pending
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def release_pending(self, pending_id):
        self.initialize()
        connection = self._connect()
        try:
            connection.execute(
                "UPDATE pending_operations SET status = 'pending', claimed_at = NULL WHERE id = ? AND status = 'claimed'",
                (int(pending_id),),
            )
            connection.commit()
        finally:
            connection.close()

    def release_armed(self, pending_id):
        self.initialize()
        connection = self._connect()
        try:
            connection.execute(
                "UPDATE pending_operations SET status = 'armed' WHERE id = ? AND status = 'completing'",
                (int(pending_id),),
            )
            connection.commit()
        finally:
            connection.close()

    def fail_pending(self, pending_id, error_message):
        self.initialize()
        connection = self._connect()
        try:
            connection.execute(
                "UPDATE pending_operations SET status = 'failed', error_message = ? "
                "WHERE id = ? AND status IN ('pending', 'claimed', 'armed', 'completing')",
                (str(error_message or "The operation could not be completed."), int(pending_id)),
            )
            connection.commit()
        finally:
            connection.close()

    def arm_redeem(self, pending_id, source_ip, expiry_seconds=DEFAULT_EXPIRY_SECONDS):
        self.initialize()
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            pending = self._get_pending(connection, pending_id)
            if pending is None:
                connection.rollback()
                return None
            connection.execute(
                "UPDATE pending_operations SET status = 'armed', armed_at = ?, expires_at = ? "
                "WHERE id = ? AND status = 'claimed'",
                (now, now + max(60, _safe_int(expiry_seconds, DEFAULT_EXPIRY_SECONDS)), int(pending_id)),
            )
            self._touch_user(connection, pending["telegram_user_id"], source_ip)
            result = self._get_pending(connection, pending_id)
            connection.commit()
            return result
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def complete_redeem(self, pending_id, source_ip, source_account_token="", source_low_id=0):
        self.initialize()
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            pending = self._get_pending(connection, pending_id)
            if pending is None:
                connection.rollback()
                return None
            connection.execute(
                "UPDATE pending_operations SET status = 'completed', completed_at = ?, bound_ip = ? "
                "WHERE id = ? AND status = 'completing'",
                (now, str(source_ip or ""), int(pending_id)),
            )
            self._save_login_alias(
                connection,
                str(source_account_token or pending.get("incoming_account_token") or ""),
                _safe_int(source_low_id) or _safe_int(pending.get("incoming_low_id")),
                pending.get("target_account_token"),
                pending.get("target_low_id"),
                pending.get("telegram_user_id"),
                now,
            )
            self._touch_user(connection, pending["telegram_user_id"], source_ip)
            if pending.get("target_saved_account_id"):
                connection.execute(
                    "UPDATE saved_accounts SET updated_at = ? WHERE id = ?",
                    (now, int(pending["target_saved_account_id"])),
                )
            result = self._get_pending(connection, pending_id)
            connection.commit()
            return result
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def complete_registration(self, pending_id, account_token, low_id, account_name, source_ip, reward_summary=""):
        self.initialize()
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            pending = self._get_pending(connection, pending_id)
            if pending is None:
                connection.rollback()
                return None
            existing = connection.execute(
                "SELECT id FROM saved_accounts WHERE telegram_user_id = ? AND account_token = ?",
                (int(pending["telegram_user_id"]), str(account_token)),
            ).fetchone()
            if existing is None:
                connection.execute(
                    "INSERT INTO saved_accounts (telegram_user_id, account_token, low_id, account_name, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        int(pending["telegram_user_id"]),
                        str(account_token),
                        _safe_int(low_id),
                        str(account_name or "Brawler"),
                        now,
                        now,
                    ),
                )
            else:
                connection.execute(
                    "UPDATE saved_accounts SET low_id = ?, account_name = ?, updated_at = ? WHERE id = ?",
                    (
                        _safe_int(low_id),
                        str(account_name or "Brawler"),
                        now,
                        int(existing[0]),
                    ),
                )
            saved = _dict(
                connection.execute(
                    "SELECT * FROM saved_accounts WHERE telegram_user_id = ? AND account_token = ?",
                    (int(pending["telegram_user_id"]), str(account_token)),
                ).fetchone()
            )
            connection.execute(
                "UPDATE pending_operations SET status = 'completed', completed_at = ?, matched_account_token = ?, "
                "matched_low_id = ?, matched_account_name = ?, reward_summary = ? WHERE id = ? AND status = 'claimed'",
                (
                    now,
                    str(account_token),
                    _safe_int(low_id),
                    str(account_name or "Brawler"),
                    str(reward_summary or ""),
                    int(pending_id),
                ),
            )
            self._touch_user(connection, pending["telegram_user_id"], source_ip)
            result = self._get_pending(connection, pending_id)
            connection.commit()
            if result is not None:
                result["saved_account"] = saved
            return result
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _barley_card_id(self):
        try:
            characters_path = self.root_dir / "GameAssets" / "csv_logic" / "characters.csv"
            cards_path = self.root_dir / "GameAssets" / "csv_logic" / "cards.csv"
            with characters_path.open(newline="", encoding="utf-8-sig") as file:
                character_rows = list(csv.reader(file))[2:]
            internal_name = character_rows[BARLEY_ID][0]
            with cards_path.open(newline="", encoding="utf-8-sig") as file:
                card_rows = list(csv.reader(file))[2:]
            for card_id, row in enumerate(card_rows):
                if len(row) > 4 and row[3] == internal_name and row[4].strip() == "0":
                    return card_id
        except Exception:
            pass
        return 24

    def grant_registration_reward(self, account_token):
        self.initialize()
        connection = self._game_connect()
        if connection is None:
            return {"granted": False, "summary": "", "gems": 0, "brawler_granted": False}
        result = {"granted": False, "summary": "", "gems": 0, "brawler_granted": False}
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT data FROM Players WHERE token = ?",
                (str(account_token),),
            ).fetchone()
            if row is None:
                connection.rollback()
                return result
            try:
                data = json.loads(row["data"] or "{}")
            except Exception:
                data = {}
            if not isinstance(data, dict):
                data = {}
            if data.get("ogsaver_registration_reward"):
                connection.rollback()
                result["summary"] = "This game account had already received the OgSaver registration reward."
                return result
            brawlers = data.get("unlocked_brawlers")
            if not isinstance(brawlers, dict):
                brawlers = {}
            normalized = {}
            for key, value in brawlers.items():
                normalized[str(key)] = value if isinstance(value, dict) else {}
            owns_barley = str(BARLEY_ID) in normalized
            gems = _safe_int(data.get("gems"))
            if owns_barley:
                gems_granted = 60
                data["gems"] = gems + gems_granted
                result["summary"] = "Reward received: 60 gems (Barley was already unlocked)."
            else:
                normalized[str(BARLEY_ID)] = {
                    "CardID": self._barley_card_id(),
                    "Skins": [0],
                    "selectedSkin": 0,
                    "Trophies": 0,
                    "HighestTrophies": 0,
                    "PowerLevel": 0,
                    "PowerPoints": 0,
                    "State": 0,
                    "StarPower": 0,
                }
                gems_granted = 30
                data["gems"] = gems + gems_granted
                result["brawler_granted"] = True
                result["summary"] = "Reward received: Barley unlocked + 30 gems."
            data["unlocked_brawlers"] = normalized
            now = _now()
            data["ogsaver_registration_reward"] = {
                "brawler_id": BARLEY_ID,
                "brawler_granted": 0 if owns_barley else 1,
                "gems_granted": gems_granted,
                "granted_at": now,
            }
            connection.execute(
                "UPDATE Players SET data = ? WHERE token = ?",
                (json.dumps(data), str(account_token)),
            )
            connection.commit()
            result["granted"] = True
            result["gems"] = gems_granted
            result["low_id"] = _safe_int(data.get("low_id"))
        except Exception:
            try:
                connection.rollback()
            except Exception:
                pass
            raise
        finally:
            connection.close()
        if result.get("granted"):
            saver = self._connect()
            try:
                saver.execute(
                    "INSERT OR IGNORE INTO registration_rewards "
                    "(account_token, low_id, brawler_granted, gems_granted, granted_at) VALUES (?, ?, ?, ?, ?)",
                    (
                        str(account_token),
                        _safe_int(result.get("low_id")),
                        1 if result.get("brawler_granted") else 0,
                        _safe_int(result.get("gems")),
                        _now(),
                    ),
                )
                saver.commit()
            finally:
                saver.close()
        return result

    def get_notifications(self, limit=20):
        self.initialize()
        now = _now()
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            self._expire(connection, now)
            rows = connection.execute(
                "SELECT * FROM pending_operations WHERE "
                "(status = 'armed' AND armed_notified_at IS NULL) OR "
                "(status IN ('completed', 'failed', 'expired') AND notified_at IS NULL) "
                "ORDER BY COALESCE(completed_at, armed_at, created_at), id LIMIT ?",
                (max(1, _safe_int(limit, 20)),),
            ).fetchall()
            connection.commit()
            notifications = []
            for row in rows:
                item = _dict(row)
                if item.get("status") == "armed":
                    item["kind"] = "redeem_armed"
                elif item.get("status") == "completed" and item.get("action") == "register":
                    item["kind"] = "register_completed"
                elif item.get("status") == "completed":
                    item["kind"] = "redeem_completed"
                elif item.get("status") == "expired":
                    item["kind"] = "expired"
                else:
                    item["kind"] = "failed"
                notifications.append(item)
            return notifications
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def mark_notification(self, pending_id, kind):
        self.initialize()
        now = _now()
        connection = self._connect()
        try:
            if kind == "redeem_armed":
                connection.execute(
                    "UPDATE pending_operations SET armed_notified_at = ? WHERE id = ?",
                    (now, int(pending_id)),
                )
            else:
                connection.execute(
                    "UPDATE pending_operations SET notified_at = ? WHERE id = ?",
                    (now, int(pending_id)),
                )
            connection.commit()
        finally:
            connection.close()
