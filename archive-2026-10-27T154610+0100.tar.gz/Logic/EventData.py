from Files.CsvLogic.Locations import Locations
from Utils.Writer import Writer
from Logic.EventSlots import EventSlots
from Database.DatabaseManager import DataBase
import time

class EventData:
    def getGameModeVariation(self, location):
     variationString = Locations().GetGameModeString(location)
     if variationString == "CoinRush":
        gameModeVariation = 0
     elif variationString == "AttackDefend":
        gameModeVariation = 2
     elif variationString == "BossFight":
        gameModeVariation = 7
     elif variationString == "BountyHunter":
        gameModeVariation = 3
     elif variationString == "Artifact":
        gameModeVariation = 4
     elif variationString == "LaserBall":
        gameModeVariation = 5
     elif variationString == "BattleRoyale":
        gameModeVariation = 6
     elif variationString == "BattleRoyaleTeam":
        gameModeVariation = 9
     elif variationString == "Survival":
        gameModeVariation = 8
     else:
        print("[ERROR] Wrong game mode!")
        gameModeVariation = -1
     return gameModeVariation

    def getGameModeVariationBattleEnd(self, location):
     variationString = Locations().GetGameModeString(location)
     if variationString == "CoinRush":
        gameModeVariation = 0
     elif variationString == "AttackDefend":
        gameModeVariation = 0
     elif variationString == "BossFight":
        gameModeVariation = 4
     elif variationString == "BountyHunter":
        gameModeVariation = 0
     elif variationString == "Artifact":
        gameModeVariation = 0
     elif variationString == "LaserBall":
        gameModeVariation = 0
     elif variationString == "BattleRoyale":
        gameModeVariation = 2
     elif variationString == "BattleRoyaleTeam":
        gameModeVariation = 5
     elif variationString == "Survival":
        gameModeVariation = 4
     else:
        print("[ERROR] Wrong game mode!")
        gameModeVariation = -1
     return gameModeVariation
    def encode(self: Writer, index, state):
         db = DataBase(self.player)
         eventData = db.loadEvents(state)

         event = eventData["info"]["events"][str(index)]
    
         self.writeVInt(index + 1)  # type
         self.writeVInt(index + 1)  # slot index
         self.writeVInt(0)
         self.writeVInt((event["TimeStamp"] - int(time.time())))  # time left
         self.writeVInt(event["Tokens"])  # tokens
         self.writeDataReference(15, event["ID"])
         collected = getattr(self.player, "collected_events", None) or {}
         self.writeVInt(2 if collected.get(str(index + 1)) == event["TimeStamp"] else 0)
         self.writeString()
         self.writeVint(0)
         if index == 4:
            self.player.lastChaosMap = event["ID"]
         self.player.lastEventTimeStamp = event["TimeStamp"]