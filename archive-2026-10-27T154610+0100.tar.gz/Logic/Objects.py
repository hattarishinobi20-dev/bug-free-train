from Logic.Battle import Battle
import math

def getAngle(x, y):
      angleDegress = math.atan2(y, x) * 180 / math.pi
      if angleDegress < 0:
         angleDegress += 360
      return angleDegress

def me(stream, ind, pind, mapIndex):
	# Player 1 Info Start
	stream.writePositiveInt(Battle.x[int(mapIndex)][int(ind)], 13) # X Position
	stream.writePositiveInt(Battle.y[int(mapIndex)][int(ind)], 14) # Y Position
	stream.writePositiveInt(pind, 7)
	'''
	Index Help
	0: Blue Team Player 1
	1: Blue Team Player 2
	2: Blue Team Player 3
	3: Blue Team Player 4
	4: Blue Team Player 5
	5: Blue Team Player 6

	16: Red Team Player 1
	17: Red Team Player 2
	18: Red Team Player 3
	19: Red Team Player 4
	20: Red Team Player 5
	21: Red Team Player 6
	'''
	stream.writePositiveInt(0, 12) # Z Position
	stream.writePositiveInt(10, 4)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 3)
	stream.writePositiveInt(1, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(1, 1)
	stream.writePositiveInt(63, 6)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 2)
	stream.writePositiveInt(0, 7)
	stream.writePositiveInt(0, 5)
	stream.writePositiveInt(3240, 13) # Current HP
	stream.writePositiveInt(3240, 13) # Max HP
	stream.writePositiveInt(Battle.gems[int(mapIndex)][int(ind)], 6) # Collected Gems
	stream.writePositiveInt(0, 13)
	stream.writePositiveInt(100, 11)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(1, 1) # Has Star Power
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(349, 9)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(349, 9)
	stream.writePositiveInt(0, 5)
	stream.writePositiveInt(0, 11)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 12)
	stream.writePositiveInt(3000, 12) # Remaining Ammo
	stream.writePositiveInt(0, 11)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 12)
	# Player 1 Info End

def opp1(stream, ind, pind, mapIndex):
	# Player 2 Info Start
	stream.writePositiveInt(Battle.x[int(mapIndex)][int(ind)], 13) # X Position
	stream.writePositiveInt(Battle.y[int(mapIndex)][int(ind)], 14) # Y Position
	stream.writePositiveInt(pind, 7)
	stream.writePositiveInt(0, 12) # Z Position
	stream.writePositiveInt(10, 4)
	stream.writePositiveInt(450, 9) # Head Rotation
	stream.writePositiveInt(450, 9) # Body Rotation
	stream.writePositiveInt(0, 3)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(1, 1)
	stream.writePositiveInt(63, 6)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 2)
	stream.writePositiveInt(0, 7)
	stream.writePositiveInt(0, 5)
	stream.writePositiveInt(3240, 13) # Current HP
	stream.writePositiveInt(3240, 13) # Max HP
	stream.writePositiveInt(Battle.gems[int(mapIndex)][int(ind)], 6) # Collected Gems
	stream.writePositiveInt(0, 13)
	stream.writePositiveInt(0, 11)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(1, 1) # Has Star Power
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 9)
	stream.writePositiveInt(0, 5)
	stream.writePositiveInt(0, 11)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 12)
	stream.writePositiveInt(3000, 12) # Remaining Ammo
	stream.writePositiveInt(0, 11)
	stream.writePositiveInt(0, 1)
	stream.writePositiveInt(0, 12)
	# Player 2 Info End

def GemSpawner(stream):
    # Gem Spawner Info Start
    stream.writePositiveInt(2550, 13) # X Position
    stream.writePositiveInt(4950, 14) # Y Position
    stream.writePositiveInt(102, 7)
    stream.writePositiveInt(0, 12) # Z Position
    stream.writePositiveInt(10, 4)
    stream.writePositiveInt(460, 14)
    stream.writePositiveInt(320, 14)
    # Gem Spawner Info End

def Gem(stream):
    # Gem Info Start
	stream.writePositiveInt(2054, 13) # X Position
	stream.writePositiveInt(4630, 14) # Y Position
	stream.writePositiveInt(102, 7)
	stream.writePositiveInt(0, 12) # Z Position
	stream.writePositiveInt(10, 4)
	# Gem Info End

def Safe(stream, ind, pind, tick, current_hp):
    # Safe Info Start
    stream.writePositiveInt(2550, 13) # X Position
    stream.writePositiveInt(150, 14) # Y Position
    stream.writePositiveInt(22, 7) # Index
    stream.writePositiveInt(0, 12) # Z position
    stream.writePositiveInt(10, 4)
    stream.writePositiveInt(0, 3)
    stream.writePositiveInt(current_hp, 16) # Current HP
    stream.writePositiveInt(22000, 16) # Max HP
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 9)
    stream.writePositiveInt(0, 5)
    # Safe Info End
