import time
from Utils.Writer import Writer
class EventSlots:
    def encode(self: Writer, slot):
        self.writeVInt(slot)
    Timer = 86399

    maps = [
        # Status = [3 = Nothing, 2 = Star Token, 1 = New Event]
        {
            'ID': 7, # Gem Grab
            'Status': 2,
            'Ended': False,
            'Modifier': 3,
            'Tokens': 10
        },

        {
            'ID': 32,
            'Status': 2,
            'Ended': False,
            'Modifier': 2,
            'Tokens': 10
        },

        {
            'ID': 0,
            'Status': 2,
            'Ended': False,
            'Modifier': 1,
            'Tokens': 10
        },

        {
            'ID': 25,
            'Status': 2,
            'Ended': False,
            'Modifier': 4,
            'Tokens': 10
        },

        {
            'ID': 38,
            'Status': 2,
            'Ended': False,
            'Modifier': 5,
            'Tokens': 10
        },

        {
            'ID': 21, # Duo Showdown
            'Status': 2,
            'Ended': False,
            'Modifier': 5,
            'Tokens': 2
        }

    ]