from Packets.Messages.Server.Battle.StartLoadingMessage import StartLoadingMessage
from Packets.Messages.Server.Battle.UdpConnectionInfoMessage import UdpConnectionInfoMessage
#from Packets.Messages.Server.Battle.VisionUpdateMessage import VisionUpdateMessage
#from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
#from Packets.Messages.Server.Battle.OnlineBattleResultMessage import BattleResultMessage
import time
from Database.DatabaseManager import DataBase
from threading import Thread
import random
from Logic.Battle import Battle
from Logic.GameModes import *
from Logic.VisionUpdater import VisionUpdater

class LogicBattle(Thread):
    def __init__(self, client, player, device):
        Thread.__init__(self)
        self.client = client
        self.device = device
        self.player = player
        self.subTick = 0
        self.tick = 0
        self.started = 0

    def run(self):
        self.startBattle()

    def startBattle(self):
        db = DataBase(self.player)
        db.replaceValue('matchmakeState', 2)
        Battle.battle_ticks[self.player.MapIndex - 1] = 0
        DataBase.loadMMPool(self, self.player.MapIndex)
        Battle.battle_ticks[0] = 0
        Battle.x[self.player.MapIndex - 1][0] = 2550
        Battle.x[self.player.MapIndex - 1][1] = 2550
        Battle.y[self.player.MapIndex - 1][0] = 150
        Battle.y[self.player.MapIndex - 1][1] = 9750
        Battle.Dx[self.player.MapIndex - 1][0] = 2550
        Battle.Dx[self.player.MapIndex - 1][1] = 2550
        Battle.Dy[self.player.MapIndex - 1][0] = 150
        Battle.Dy[self.player.MapIndex - 1][1] = 9750
        Battle.gems[self.player.MapIndex - 1][0] = 0
        Battle.gems[self.player.MapIndex - 1][1] = 0
        for key, x in self.matchmakedata.itmes():
            Battle.brawler[self.player.MapIndex - 1][x] = self.matchmakedata[str(x)]["brawlerID"]
        StartLoadingMessage(self.client, self.player, self.device).send()
        for Player, Info in self.matchmakedata.items():
            VU = VisionUpdater(self.client, self.player, self.device, Player, self.matchmakedata[Player]["lowID"], 0)
            VU.start()
        UdpConnectionInfoMessage(self.client, self.player, self.device).send()
        #while self.started:
            #if self.subTick >= 4:
                #self.tick += 1
                #self.subTick = 0
            #self.process()
            #time.sleep(1 / 20)

    def process(self):
        pass
