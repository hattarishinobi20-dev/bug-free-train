from Logic.Battle import Battle
from Logic.Objects import *
from Logic.MapObjects import *
import math
import random
from Utils.BitStream import BitStream
from Logic.Battles.Objects.LogicGameObjectServer import LogicGameObjectServer

class LogicCharacterServer:

   def encode(stream, player, objectIndex):
     LogicGameObjectServer.encode(stream, player, objectIndex)
     if objectIndex !=6:
      if  objectIndex == 0:
       stream.writePositiveInt(0, 1)# boolean only if you play this object else its angles
      else:
        stream.writePositiveInt(player.playersAngle[objectIndex], 9)
        stream.writePositiveInt(player.playersAngle[objectIndex], 9)
      stream.writePositiveInt(0, 3) # state?
      stream.writePositiveInt(0, 1) 
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(63, 6) # playing anim ????????? what?
      stream.writePositiveInt(0, 1) # rotation related
      stream.writePositiveInt(0, 1) # is stunned
      stream.writePositiveInt(0, 1) # has star power
      stream.writePositiveInt(0, 2) # state?
      stream.writePositiveInt(0, 7) # angle
      stream.writePositiveInt(0, 5)
    
      stream.writePositiveInt(player.playersHp[objectIndex], 13) # actual hps
      stream.writePositiveInt(player.playersMaxHp[objectIndex], 13) #max hps
      stream.writePositiveInt(player.playersItems[objectIndex], 6) # my amount of items
      stream.writePositiveInt(player.hasBall[objectIndex], 1) # has ball
      stream.writePositiveInt(0, 13)
      stream.writePositiveInt(0, 11)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1) # has immunity shield
      stream.writePositiveInt(0, 1) # is spinning? 
      stream.writePositiveInt(0, 1) # is in rage
      stream.writePositiveInt(0, 1) # is aiming ulti?
      stream.writePositiveInt(0, 1) # ulti activated ?
      stream.writePositiveInt(1, 1) # has star power
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(0, 1) # not fully visible ?
      stream.writePositiveInt(0, 9)
      if objectIndex == 0:
        stream.writePositiveInt(1, 1)
        stream.writePositiveInt(0, 9)
      if player.shouldRespawnEverythingState == 1:
        player.playersDamages[objectIndex] = 1
        player.playersDamage[objectIndex] = player.playersHp[objectIndex]
      stream.writePositiveInt(player.playersDamages[objectIndex], 5) # received damages array
      for x in range(player.playersDamages[objectIndex]):
        stream.writePositiveInt(player.playersDamage[objectIndex], 15) # recieved damage xd
        player.playersHp[objectIndex] -= player.playersDamage[objectIndex]
# attack array
      stream.writePositiveInt(0, 11) #  attack active ticks ig
      stream.writePositiveInt(0, 1) # is using it ?
      stream.writePositiveInt(0, 12) # is this charge related?
      stream.writePositiveInt(3000, 12) # attack ammos
# attack end
# ulti start
      stream.writePositiveInt(0, 11) # active attack ticks
      stream.writePositiveInt(0, 1) # is using it?
      stream.writePositiveInt(0, 12) # ulti ammos 💀
# ulti end
     
     else:
      stream.writePositiveInt(player.playersX[objectIndex], 13)
      stream.writePositiveInt(player.playersY[objectIndex], 14)
      stream.writePositiveInt(102, 7)
      stream.writePositiveInt(0, 12)
      stream.writePositiveInt(10, 4)
      stream.writePositiveInt(0, 3)
      if player.ballScoreState == 2:
        player.playersHp[objectIndex]
        player.ballScoreState == 3
      stream.writePositiveInt(player.playersHp[objectIndex], 13)
      stream.writePositiveInt(1, 13)
      stream.writePositiveInt(0, 2)
      stream.writePositiveInt(0, 2)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 9)
      if player.ballScoreState == 1:
        player.playersDamage[objectIndex] = 1
        player.ballScoreState = 3
      stream.writePositiveInt(player.playersDamage[objectIndex], 5)
      for x in range(player.playersDamage[objectIndex]):
            stream.writePositiveInt(1, 15) # should kill the ball