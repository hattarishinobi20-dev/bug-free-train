from Logic.Battle import Battle
from Logic.Objects import *
from Logic.MapObjects import *
import math
import random
from Utils.BitStream import BitStream
from Logic.Battles.Objects.LogicCharacterServer import LogicCharacterServer

class LogicGameObjectManager:

   def encode(stream, low_id, index, client, player, tick, mapIndex, tileMapHeight, tileMapWidth, gameModeVariation):
    stream.writePositiveInt(2000000, 21) # own object global id
    stream.writePositiveInt(0, 15) # battle state?
    stream.writeBoolean(False)
    stream.writeBoolean(False)
    stream.writeBoolean(False)
    stream.writeBoolean(False)
    stream.writeBoolean(False)
    if tileMapWidth < 21:
      stream.writePositiveInt(0, 5)
      stream.writePositiveInt(0, 6)
      stream.writePositiveInt(tileMapWidth, 5)
      stream.writePositiveInt(tileMapHeight, 6)
    else:
      stream.writePositiveInt(0, 6)
      stream.writePositiveInt(0, 7)
      stream.writePositiveInt(tileMapWidth, 6)
      stream.writePositiveInt(tileMapHeight, 7)
    for x in range(165):
      stream.writeBoolean(player.hasAllWallDestroyed)
    for x in range(6):
      stream.writeBoolean(True)
      stream.writeBoolean(True) # has ulti
      if x == 0:
       stream.writePositiveInt(4000, 12) # my ulti charge
    if gameModeVariation == 5:
      stream.writeBoolean(True)
      stream.writePositiveInt(1, 1)
      stream.writePositiveInt(0, 1)
    elif gameModeVariation == 6:
       stream.writePositiveInt(0, 4) # brawlers left
    elif gameModeVariation == 9:
        stream.writePositiveInt(0, 3) # teams left
    elif gameModeVariation == 3:
      stream.writePositiveInt(0, 3) # unk
      stream.writePositiveInt(0, 3) # unk
    elif gameModeVariation == 7:
       stream.writePositiveInt(0, 7) # boss percentage
    for x in range(6):
     stream.writePositiveInt(player.teamScore[x], 7) # my team's score 
     killEntry = 0
     stream.writePositiveInt(killEntry, 4)
     if killEntry >= 1:
      for x in range(killEntry):
         killEntry2 = 0
         stream.writePositiveInt(killEntry2, 3)
         if killEntry2 >= 1:
           for x in range(killEntry2):
              stream.writePositiveInt(0, 4)
    for players in range(6):
     distance = math.sqrt((player.playersX[players] - player.playersX[6]) ** 2 + (player.playersY[players]  - player.playersY[6] ) ** 2)
     if player.gameObjects == 0:
       player.gameObjects = 7
       player.playersX[players] = 1950
       player.playersY[players] = 6450
       player.playersX[6] = 2550
       player.playersY[6] = 4950
     if player.shouldRespawnEverythingState == 1:
          player.gameObjects = 0
          player.shouldRespawnEverythingState = 0
     if player.ballScoreState == 5:
       player.shouldRespawnEverythingState = 1
       player.ballScoreState = 0
     if player.ballScoreState == 4:
       player.ballScoreState = 5
       player.hasBall[players] = 0
     if player.ballScoreState == 3:
       player.gameObjects = 6
       player.ballScoreState = 4
     if distance <= 600 and player.isBallAlone and player.gameObjects == 7:
        player.hasBall[players] = 1
        player.isBallAlone = False
        player.teamScore[players] += 1
        player.ballScoreState = 1
     if player.hasBall[players] == 1:
          player.playersX[6] = player.playersX[players] + 10
          player.playersY[6] = player.playersY[players] + 100
    if player.playersY[6] == 0:
      player.ballScoreState = 1
    stream.writePositiveInt(player.gameObjects, 7) # game objects count
# objects csv ids starts
    for objects in range(player.gameObjects):
     stream.writePositiveInt(player.objectLowID[objects], 5)
     stream.writePositiveInt(player.objectHighID[objects], 8) # my brawla?
# objects csv ids ends
# objects index/id starts
    for index in range(player.gameObjects):
       stream.writePositiveInt(2, 5)
       stream.writePositiveInt(index, 14)
#objects index/id ends
# players entry starts
    for index in range(player.gameObjects):
      if player.gameObjectType[index] == "Character":
        LogicCharacterServer.encode(stream, player, index)
      else:
         pass # unhandled yet