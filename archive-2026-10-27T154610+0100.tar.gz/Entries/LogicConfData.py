from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Logic.EventSlots import EventSlots
from Logic.Shop import Shop
from Entries.LogicArrayVInt import LogicArrayVInt
from Logic.EventData import EventData
class LogicConfData:
    def encode(self: Writer):
        # Shop
        
        self.writeVInt(int(datetime.timestamp(datetime.now())))  # Shop TimeStamp

        self.writeVInt(100) # tokens for brawl box

        self.writeVInt(15) # ad?

        for item in Shop.boxes:
            self.writeVInt(item['Cost'])
            self.writeVInt(item['Multiplier'])
            
        self.writeVInt(Shop.token_doubler['Cost'])
        self.writeVInt(Shop.token_doubler['Amount'])

        self.writeVInt(69746974) # max tokens?
        self.writeVInt(50)
        self.writeVInt(999900)
        # Shop end
        LogicArrayVInt.encode(self, [0, 30, 80, 170, 350, 0]) # guaranteed brawlers boxes array

        self.writeVInt(5)  # Event Slots
        for slot in range(5):
            EventSlots.encode(self, slot + 1)

        # Logic Events
        db = DataBase(self.player)
        eventData = db.loadEvents(1)
        self.writeVInt(len(eventData["info"]["events"]))
        
        for map in range(len(eventData["info"]["events"])):
            EventData.encode(self, map, 1)

        self.writeVInt(len(eventData["info"]["events"]))
        
        for map in range(len(eventData["info"]["events"])):
            EventData.encode(self, map, 1)

        LogicArrayVInt.encode(self, [20, 35, 75, 140, 290, 480, 800, 1250]) # upgrades cost
        LogicArrayVInt.encode(self, [1, 2, 3, 4, 5, 10, 15, 20]) # upgrades powerpoint multiplier or smth
        LogicArrayVInt.encode(self, [10, 30, 80]) # tickets price
        LogicArrayVInt.encode(self, [6, 20, 60]) # tickets amount
        LogicArrayVInt.encode(self, [20, 50, 140])
        LogicArrayVInt.encode(self, [150, 400, 1200])

        self.writeVInt(2)

        self.writeVInt(621)
        
        for x in self.milestones.array:
            self.writeVInt(x)
            
        self.writeVInt(int(self.player.settings.get("DailyTokens", 400)))
        self.writeVInt(20)
        self.writeVInt(8640)
        self.writeVInt(10)