from Utils.Writer2 import Writer
from Entries.BattleLogPlayerEntry import BattleLogPlayerEntry
class BattleLogEntry:
    
    def encode(ByteStream: Writer, battle):
        ByteStream.writeVInt(0) # index
        ByteStream.writeVInt(6) # battle was 6s ago
        ByteStream.writeVInt(1) # battle log type
        ByteStream.writeVInt(69) # trophies got
        ByteStream.writeVInt(6974) # battle time
        ByteStream.writeBoolean(True) # is friendly
        ByteStream.writeDataReference(15, 0) # map
        ByteStream.writeVInt(1) # 0 = victory 1 = defeat
        ByteStream.writeVInt(1)
        ByteStream.writeInt(1)
        ByteStream.writeInt(1)
        ByteStream.writeVInt(1) #players entry
        for player in range(1):
            BattleLogPlayerEntry.encode(ByteStream, player)
        #ByteStream.writeVInt(6)
