from Utils.Writer import Writer

class LogicCommand:
    
    def encode(ByteStream: Writer):
        ByteStream.writeVInt(0) # hmm what
        ByteStream.writeVInt(0) # hmm what
        ByteStream.writeLogicLong(0, 0) # funny