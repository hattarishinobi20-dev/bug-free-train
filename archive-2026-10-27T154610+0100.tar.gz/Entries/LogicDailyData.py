from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
from Entries.LogicOfferBundle import LogicOfferBundle
from Logic.Shop import Shop

class LogicDailyData:
    def encode(self: Writer):
        db = DataBase(self.player)
        self.writeVInt(int(datetime.timestamp(datetime.now()))) # timestamp
        self.writeVInt(0) # club timeout
        self.writeVInt(self.player.trophies)  # Player Trophies
        self.writeVInt(self.player.highest_trophies)  # Player Max Reached Trophies
        trophy_rank = 1
        try:
            trophy_road = int(getattr(self.player, "trophyRoad", 1) or 1)
        except (TypeError, ValueError):
            trophy_road = 1
        try:
            milestones = self.milestones.array
            highest_trophies = int(getattr(self.player, "highest_trophies", 0) or 0)
            completed = 0
            expected = 0
            index = 5698
            limit = len(milestones) - 63
            while index < limit and expected < 94:
                if milestones[index] == 6 and milestones[index + 1] == expected and milestones[index + 4] == 0:
                    if highest_trophies >= milestones[index + 2] + milestones[index + 3]:
                        completed += 1
                    expected += 1
                    index += 6
                else:
                    index += 1
            if expected == 94:
                trophy_rank = min(completed + 1, 94)
                trophy_road = min(max(trophy_road, 1), completed + 1)
                self.player.trophyRoad = trophy_road
        except Exception:
            trophy_road = max(trophy_road, 1)
        self.writeVInt(trophy_rank)

        self.writeVInt(trophy_road)      # Trophy Road Reward
        self.writeVInt(self.player.player_experience)  # Starting Level (exp points)

        self.writeDataReference(28, self.player.profile_icon if 0 <= self.player.profile_icon <= 36 else 0)  # Icon ID

        self.writeVInt(9)       # played gamemodes array
        for gamemode in range(9):
            self.writeVInt(gamemode)
        non_zero_skins = []

        for brawler in self.player.unlocked_brawlers.values():
            if brawler["selectedSkin"] != 0 and brawler["selectedSkin"] <= 49:
                non_zero_skins.append(brawler["selectedSkin"])
        self.writeVInt(len(non_zero_skins))
        for skin in non_zero_skins:
            self.writeDataReference(29, skin)

        # Unlocked Skins array
        non_zero_skins = []

        for brawler in self.player.unlocked_brawlers.values():
            for skin in brawler["Skins"]:
                if skin != 0 and skin <= 49:
                    non_zero_skins.append(skin)
        self.writeVInt(len(non_zero_skins))
        for skin in non_zero_skins:
            self.writeDataReference(29, skin)

        self.writeBoolean(False) # Timer Required For Create a New Band
        self.writeVInt(0) # leaderboard region
        self.writeVInt(self.player.key_reward) # animation keys
        self.writeVInt(self.player.trophy_reward) # animation trophies
        self.writeVInt(self.player.star_key_reward) # animation star keys
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeBoolean(False) # token limit reached message
        self.writeVInt(1)
        self.writeBoolean(True) # battle hints

        self.writeVInt(self.player.tokensdoubler)
        self.writeVInt(734974) # Season End Timer (i think thats more coins boosted time)
        self.writeByte(0)
        self.writeVint(0) # shopt offer
        self.writeBoolean(False)

        self.writeVInt(0) # idk
        self.writeVInt(0) # idk
        self.writeVInt(30) # Change Name Cost in Gems
        self.writeVInt(0) # Timer For the next name change
        if not db.load_offers(self.player.token):
            db.initialize_player_offers(self.player.token)
        offers = db.load_offers(self.player.token)
        offer = offers["info"]
        self.writeBoolean(False)
        count = len(Shop.offers)
        visible_keys = db.visible_offer_keys(offers)
        self.writeVint(len(visible_keys))
        for key in visible_keys:
         LogicOfferBundle.encode(self, offer[key])

        self.writeVInt(1) # 1 ??
        for x in range(1):
            self.writeVInt(0)
            self.writeVInt(1)
            self.writeVInt(10)

        self.writeVInt(db.refresh_tokens())
        self.writeVInt(-64)
        self.writeVInt(0)
        for x in range(0):
            self.writeVint(x)

        self.writeVint(self.player.tickets)
        self.writeVInt(0)
        

